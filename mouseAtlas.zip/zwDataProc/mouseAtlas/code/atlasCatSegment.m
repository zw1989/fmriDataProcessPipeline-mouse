clear; close all; clc
%% Load Cat Atlas
% Info about cat atlas: README.txt in CatMRI_prereqs folder

atlasPath='/home/ibrain-raid2/weizhu-data/zwDataProc/brainAtlas/CatMRI_prereqs';

nii = load_untouch_nii(fullfile(atlasPath,'CATLAS.nii'));
atlas = nii.img;
atlas = permute(atlas,[3,1,2]);

% figure; imshow(fColorize_Morphological_Image(makeMontage(atlas,0,0,'xy')))

% Make ROI_Name_List
roiList = fileread(fullfile(atlasPath,'CATLAS.txt'));
roiList = strsplit(roiList,' ');

% Save the new atlas in atlasPath
saveSdt(rot90(atlas,-1), 'AtlasCat', 0.5, 0.5, 0.5)


