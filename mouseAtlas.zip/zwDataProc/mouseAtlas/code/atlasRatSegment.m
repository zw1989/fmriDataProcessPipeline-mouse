clear; close all; clc

%% Load Rat Atlas
% brain.nii is the T1 weighted image; labels.nii is the labeled atlas;
% priors.nii is the segmented gray matter, white matter and csf image;
% mask.nii is the brain mask. Here we load labels.nii

atlasPath='/home/ibrain-raid2/weizhu-data/zwDataProc/brainAtlas/rat';

nii = load_nii(fullfile(atlasPath,'labels.nii'));
atlas = nii.img;
%atlas = rot90(permute(atlas(:,:,:),[3,1,2]),-2);
% Atlas0=rot90(permute(Atlas0,[3,1,2]),-2);

figure; imshow(fColorize_Morphological_Image(makeMontage(atlas,0,0,'xy'))); truesize
%figure; imshow(makeMontage(atlas,0,0,'xy'),[]); truesize


%% Load roi info from label.xlsx
% Basically, this file contains all the segmentation information about brain.
roiInfo = readtable(fullfile(atlasPath,'label.xlsx'));



%% %%%%%%%%%%%%%%%%%%%%%%%%%%% Brain Region Combination %%%%%%%%%%%%%%%%%%
%  Use Brain Explorer to check the brain hierarchy.

% 1. Combine brain regions with level 1000
roiListTmp = table;
roiListNew = roiList;
n=1;
while ~isequal(roiListTmp, roiListNew)
    roiListTmp = roiListNew;
    parentRange = unique(roiListTmp.parent);
    parentRange(isnan(parentRange)) = [];

    for iParent = 1:length(parentRange)
        tmpIdx = roiListTmp.parent==parentRange(iParent);
        tmp = roiListTmp(tmpIdx,:);

        tmpLevel = unique(tmp.level);
        tmpLabelMin = min(tmp.label);
        % If regions with the same parent have the same level with that of the
        % region with one smaller label, assign these regions with the one
        % with a smaller label
        if min(tmpLevel)>200 && abs(roiListTmp.level(roiListTmp.label==tmpLabelMin-1) - tmp.level(tmp.label==tmpLabelMin)) <= 1
            roiListNew(tmpIdx,[1:2,4:5]) = repmat(roiListTmp(roiListTmp.label==tmpLabelMin-1,[1:2,4:5]), [size(tmp,1) 1]);   
        end
    end
    n=n+1;
end

% Check the new parent range
parentRange = unique(roiListNew.parent);
parentRange(isnan(parentRange)) = [];

for iParent = 1:length(parentRange)
    tmpIdx = roiListTmp.parent==parentRange(iParent);
    tmp = roiListTmp(tmpIdx,:);
    
    tmpLevel = unique(tmp.level);
    
    if ismember(1000, tmpLevel) 
        if length(tmpLevel) > 1 
            tmp.level(tmp.level==1000) = min(tmpLevel);
            roiListNew(tmpIdx,:) = tmp;
        else
        % If regions with the same parent are in level 1000 and the level is
        % different from that of the region with one smaller label than the
        % minimum label of these regions, assign them in an upper level region;
        % if not, keep the original values.
            tmpLabelMin = min(tmp.label);
            priorLabelIdx = roiListTmp.label==tmpLabelMin-1;
            if roiListTmp.level(priorLabelIdx) ~= tmp.level(tmp.label==tmpLabelMin)
                roiListNew(tmpIdx,[1:2,4:5]) = repmat(roiListTmp(priorLabelIdx,[1:2,4:5]), [size(tmp,1) 1]);   
            end
        end
    end
end

%% 2. Combine brain regions with level 200
n=1;
while ~isequal(roiListTmp, roiListNew)
    roiListTmp = roiListNew;
    parentRange = unique(roiListTmp.parent);
    parentRange(isnan(parentRange)) = [];

    for iParent = 1:length(parentRange)
        tmpIdx = roiListTmp.parent==parentRange(iParent);
        tmp = roiListTmp(tmpIdx,:);

        tmpLevel = unique(tmp.level);
        tmpLabelMin = min(tmp.label);
        % If regions with the same parent have the same level with that of the
        % region with one smaller label, assign these regions with the one
        % with a smaller label
        if min(tmpLevel)>100 && abs(roiListTmp.level(roiListTmp.label==tmpLabelMin-1) - tmp.level(tmp.label==tmpLabelMin)) <= 1
            roiListNew(tmpIdx,[1:2,4:5]) = repmat(roiListTmp(roiListTmp.label==tmpLabelMin-1,[1:2,4:5]), [size(tmp,1) 1]);   
        end
    end
    n=n+1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %% 1. First level brain region combination 
% % Check the parent range
% parentRange = unique(roiList.parent);
% parentRange(isnan(parentRange)) = [];
% 
% roiList.acronym1=cell(size(roiList,1),1);
% roiList.fullName1=roiList.acronym1;
% roiList.parent1=0*roiList.parent;
% roiList.level1=roiList.parent1;
% 
% for iParent = 1:length(parentRange)
%     tmpIdx = roiList.parent==parentRange(iParent);
%     tmp = roiList(tmpIdx,:);
%     
%     tmpLevel = unique(tmp.level);
%     % If regions with the same parent are in same level and the level is
%     % 1000, assign them in an upper level region name; if not, keep the
%     % original name.
%     if length(tmpLevel) == 1 && tmpLevel == 1000 
%         tmpLabelMin = min(tmp.label);
%         n = 1;
%         while roiList.level(roiList.label==tmpLabelMin-n) - tmp.level(tmp.label==tmpLabelMin)==0
%             n = n+1;
%         end
%         % roiList.acronym1(tmpIdx,:) = roiList.acronym(roiList.label==tmpLabelMin-n);
%         % roiList.fullName1(tmpIdx,:) = roiList.fullName(roiList.label==tmpLabelMin-n);
%         roiList(tmpIdx,7:10) = repmat(roiList(roiList.label==tmpLabelMin-n,[1:2,4:5]), [size(tmp,1) 1]);  
%     else
%         roiList(tmpIdx,7:10) = tmp(:,[1:2,4:5]);  
%     end
% end
% 
% %% 2. Second level brain region combination
% % Check the parent1 range
% parent1Range = unique(roiList.parent1);
% parent1Range(isnan(parent1Range)) = [];
% 
% roiList.acronym2=cell(size(roiList,1),1);
% roiList.fullName2=roiList.acronym2;
% roiList.parent2=0*roiList.parent;
% roiList.level2=roiList.parent2;
% 
% for iParent = 1:length(parent1Range)
%     tmpIdx = roiList.parent1==parent1Range(iParent);
%     tmp = roiList(tmpIdx,:);
%     
%     tmpLevel = unique(tmp.level1);
%     % If regions with the same parent are in same level and the level is
%     % 200, assign them in an upper level region name; if not, keep the
%     % original name.
%     if length(tmpLevel) == 1 && tmpLevel == 200 
%         tmpLabelMin = min(tmp.label);
%         n = 1;
%         while roiList.level1(roiList.label==tmpLabelMin-n) == tmp.level(tmp.label==tmpLabelMin)
%             n = n+1;
%         end
%         % roiList.acronym1(tmpIdx,:) = roiList.acronym(roiList.label==tmpLabelMin-n);
%         % roiList.fullName1(tmpIdx,:) = roiList.fullName(roiList.label==tmpLabelMin-n);
%         roiList(tmpIdx,11:14) = repmat(roiList(roiList.label==tmpLabelMin-n,[1:2,4:5]), [size(tmp,1) 1]);  
%     else
%         roiList(tmpIdx,11:14) = tmp(:,7:10);  
%     end
% end
% 
% %% 3. Third level brain region combination
% % Check the parent1 range
% parent2Range = unique(roiList.parent2);
% parent2Range(isnan(parent2Range)) = [];
% 
% roiList.acronym3=cell(size(roiList,1),1);
% roiList.fullName3=roiList.acronym3;
% roiList.parent3=0*roiList.parent;
% roiList.level3=roiList.parent3;
% 
% for iParent = 1:length(parent2Range)
%     tmpIdx = roiList.parent2==parent2Range(iParent);
%     tmp = roiList(tmpIdx,:);
%     
%     tmpLevel = unique(tmp.level2);
%     tmpLabelMin = min(tmp.label);
%     % If regions with the same parent have the same level with that of the
%     % region with one smaller label, assign these regions with the one
%     % with a smaller label
%     if min(tmpLevel)>100 && abs(roiList.level2(roiList.label==tmpLabelMin-1) - tmp.level(tmp.label==tmpLabelMin)) <= 1
%         roiList(tmpIdx,15:18) = repmat(roiList(roiList.label==tmpLabelMin-1,[1:2,4:5]), [size(tmp,1) 1]);  
%     else
%         roiList(tmpIdx,15:18) = tmp(:,11:14);  
%     end
% end


%% Filter out brain regions based on labels in the nifti file
% Check the labels in the nifti image
imgLabel = unique(atlas);
roiListNew.imgLabel = ismember(roiListNew.label, imgLabel);
roiListImg = roiListNew(roiListNew.imgLabel~=0,:);

% Filter out high level brain regions which usually appear as the region outline 
roiListImg(roiListImg.level<=100,:) = [];

% Sort roiListImg in a-z based on the acronym
roiListImg = sortrows(roiListImg, {'acronym'});

% Store the acronym and fullName of the brain regions in another table
roiName = roiListImg(:,1:2);
roiName = unique(roiName);
roiName.label = (1:size(roiName,1))';
roiName = roiName(:, [3 1 2]);

%% Combine ROIs in the nifti file and assign the index of each region in roiName as label
atlasNew = 0*atlas;
for iRoi=1:size(roiListImg,1)
    atlasNew(atlas==roiListImg.label(iRoi)) = find(strcmp(roiName.acronym, roiListImg.acronym{iRoi}));
end

figure; imshow(fColorize_Morphological_Image(fDisplay_EPI(permute(atlasNew,[1,2,3]),0,0,'xy')))

% Save the new atlas in atlasPath as well as the label-name information
saveSdt(rot90(atlasNew,-1), fullfile(atlasPath,'AtlasMouse60'), 0.05, 0.05, 0.05)
writetable(roiName, fullfile(atlasPath, 'AtlasMouse60.txt'), 'Delimiter', ' ')


