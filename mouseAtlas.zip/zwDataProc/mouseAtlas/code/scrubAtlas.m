function [atlas, roiListScrubbed] = scrubAtlas(atlas, roiList, structLevelCut, voxNumCut,layerFlag)

% <atlas> is the 3D atlas annotation image obtained from Allen
%   institute. Note that for now we have processed the annotation data a
%   bit, such as combining the white matter, and CSF areas. Those processes
%   could be also included in this function in the future.
% <roiList> is a table including the necessary information about each parcellated
%   brain area that is read from the structures.csv provided from Allen
%   institute associated with the annotation data. Some columns have been
%   removed from the original file.
% <structLevel> (optional) is a scalar indicating to which struct level we can scrub
%   the annotation data. The range of the structure levels can be find in
%   the stuctures.cvs. [] means keeping the current parcellation.
% <voxNumCut> (optional) is a scaler indicating the minimum voxel number
%   that a roi needs to recover to avoid being disgarded.

if ~exist('structLevelCut','var') || isempty(structLevelCut)
  structLevelCut = max(unique(roiList.st_level));
end

if ~exist('voxNumCut','var') || isempty(voxNumCut)
  voxNumCut = 0;
end
if ~exist('layerFlag','var') || isempty(layerFlag)
  layerFlag = 0;
end

% Structure levels: level 10 and 11 are the layer-level structures. One
% might be interested in group them together to the upper level.
strLevel = unique(roiList.st_level);

% Get the levels in descending order that we need to combine. 
strLevelToBeScrubbed = sort(strLevel(strLevel>structLevelCut),'descend');

% For fiber tracts and ventricular systems, there are not many structure
% levels (1,2,7,8,9,10). We may want to combine them when the
% structLevelCut is set to be less than 5. The way we do it is to change
% the st_level=1 or 2 in the roiList to be 5 or 6.
tmpidx = ismember([roiList.acronym],{'fiber tractsr','fiber tractsl','VSr','VSl'});
roiList.st_level(tmpidx) = 5;

tmpLowerIdx = find(contains(roiList.structure_id_path, roiList.structure_id_path(tmpidx))...
  & roiList.st_level < 5);
roiList.st_level(tmpLowerIdx)=5+1;

% Get the scrubbed atlas annotation data. Note that we have to scrub the
% data level by level, starting from the deepest level (level 11)
for istr = 1:length(strLevelToBeScrubbed)
    % The potential list that needs to be removed
    tmpList = roiList(ismember(roiList.st_level,strLevelToBeScrubbed(istr)),:); 
    
    % Remove values that are not in the atlas
    tmpList = tmpList(ismember(tmpList.id,unique(atlas(:))),:);
    
    for iroi = 1:size(tmpList,1)
        % Get the struct path from the upper level roi
        tmpStructPath = stripfile(tmpList.structure_id_path{iroi});
        
        % Get the indices of the current roi and its upper level roi from
        % roiList
        roiListIdx = find(roiList.id==tmpList.id(iroi));
        roiListUpperIdx = find(strcmp(roiList.structure_id_path,tmpStructPath),1);

        % Change the value in the atlas image if the upper struct level is
        % equal or larger than the set structLevelCut. Else, keep the value in
        % the atlas
        if roiList.st_level(roiListUpperIdx)>=structLevelCut || tmpList.st_level(iroi)==11

            % Change the st_level if necessary
            if roiList.st_level(roiListUpperIdx)<structLevelCut
                roiList.st_level(roiListUpperIdx)=structLevelCut;
            end    
            
            if layerFlag
                % Replace the roi name for each layer
                if contains(tmpList.name(iroi), {'layer ', 'Layer '}) 
                    layerNum = char(regexp(tmpList.acronym{iroi},'\d+','match'));
                    switch layerNum
                        case {'1','2','3','4','5','6'}
                            roiList.acronym(roiListIdx) = {[roiList.acronym{roiListUpperIdx},layerNum]};
                            roiList.name(roiListIdx) = {[roiList.name{roiListUpperIdx},[', layer ',layerNum]]};
                        case ['2';'3']
                            roiList.acronym(roiListIdx) = {[roiList.acronym{roiListUpperIdx},'2/3']};
                            roiList.name(roiListIdx) = {[roiList.name{roiListUpperIdx},[', layer ','2/3']]};
                        otherwise 
                            
                    end

                    % Change the atlas value if the same roi name is found
                    tmpIdx = find(strcmp(roiList.name(roiListIdx), roiList.name));
                    if length(tmpIdx)>1
                        atlas(atlas==tmpList.id(iroi)) = roiList.id(tmpIdx(1));
                        roiList(tmpIdx(2),:) = [];
                    else
                        roiList(roiListIdx,4:6) = roiList(roiListUpperIdx,4:6);
                    end

                else%if ~contains(tmpList.name(iroi), {'CA'}) % Special case: we want separate CA1,CA2,CA3
                    % Change the value in atlas
                    atlas(atlas==tmpList.id(iroi)) = str2double(stripfile(tmpStructPath,1));
                end

            else % Don't want layer analysis

                % Change the value in atlas
                atlas(atlas==tmpList.id(iroi)) = str2double(stripfile(tmpStructPath,1));
            end
            
        
        end
    end
end

% Get the scrubbed roiList based on the atlas intensities
roiListScrubbed = roiList(ismember(roiList.id,unique(atlas(:))),:);

% Remove rois in the roiListScrubbed whose st_level is less than the
% min[structLevelCut,6]. These areas are unsigned or leftover regions that we are not
% interested in. Note that we only removed the those roi info from the list
% but not from the atlas!!!!  
roiListScrubbed(roiListScrubbed.st_level<min(6,structLevelCut),:) = [];

% Counts the voxel number for each roi in the atlas
roiListScrubbed.voxCounts = cellfun(@(x) sum(atlas(:)==x,'omitnan'), num2cell(roiListScrubbed.id));

% Plot voxel number for each roi
% figure; histogram('Categories', roiListScrubbed.acronym, 'BinCounts', roiListScrubbed.voxCounts, 'BarWidth',0.8);
% hold on
% line(xlim, [voxNumCut voxNumCut],'Linewidth', 2, 'Color', 'r', 'LineStyle','--')
% hold off

% Remove the rois that have too few voxel numbers
roiListScrubbed(roiListScrubbed.voxCounts<voxNumCut,:) = [];




