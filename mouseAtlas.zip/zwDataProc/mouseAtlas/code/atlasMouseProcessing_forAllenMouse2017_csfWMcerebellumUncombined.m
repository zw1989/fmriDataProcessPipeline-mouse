clear; close all; clc

%% Load Allen Mouse Atlas
% The mouse Atlas is a nifti label file where each brain regions is
% labelled by a number, or an index. The assigned indices for brain regions
% can be found in file 'structures.csv'.

atlasPath='/home/ibrain-raid2/weizhu-data/zwDataProc/brainAtlas/AllenMouse2017ConvertedToNifti/annotation2017';
nii = load_nii(gunziptemp(fullfile(atlasPath,'annotation_100.nii.gz')));
atlas = nii.img;
% atlas = rot90(permute(atlas,[3,1,2]),-2);
% figure;imshow(makeMontage(atlas,0,0,'xy'),[0,2000])

% Read structure info
roiList = readtable(fullfile(atlasPath,'structures.csv'));

% Remove some rows and columns in the table that we don't need
roiList = roiList(2:end,[1,3,4,5,10,13]);

%% %%%%%%%%%%%%% Process the top hierarchical structures
% Find the top hierarchical structures. These include the groove class,
% ventricular system, and the fiber tracts
s1 = roiList(roiList.depth==1,:);

%% Remove the grooves and retina (sinus and fissures). These id numbers are not included in the atlas
% Get the grooves index in the roiList
grooveIdx = contains(roiList.structure_id_path,s1.structure_id_path{4}); 
retinaIdx = contains(roiList.structure_id_path,s1.structure_id_path{5});

% Remove the grooves class in the roiList
roiList(grooveIdx|retinaIdx,:)=[];

%% Combine the ventricular system. These can be used as the CSF mask
% % Get the ventricular system index in the roiList
% venIdx = contains(roiList.structure_id_path,s1.structure_id_path{3});
% 
% % Assign the id of the top ventricular system in the atlas image
% atlas(ismember(atlas,roiList.id(venIdx))) = s1.id(3);
% 
% % Remove the lower level ventricular system class in the roiList
% % roiList(venIdx,2:5) = repmat(s1(3,2:5),sum(venIdx),1);
% roiList(venIdx,:)=[]; roiList = [roiList; s1(3,:)];


%% Combine the white matter class. These can be used as the white matter mask
% % Get the ventricular system index in the roiList
% wmIdx = contains(roiList.structure_id_path,s1.structure_id_path{2});
% 
% % Assign the id of the top ventricular system in the atlas image
% atlas(ismember(atlas,roiList.id(wmIdx))) = s1.id(2);
% 
% % Remove the lower level ventricular system class in the roiList
% %roiList(wmIdx,2:5) = repmat(s1(2,2:5),sum(wmIdx),1);
% roiList(wmIdx,:)=[]; roiList = [roiList; s1(2,:)];


%% %%%%%%%%%%%%%%%%%% Process the second top hierarchical structures
% % Find the second top hierarchical structures. It will include the
% % Cerebrum, brain stem, and cerebellum
% s2 = roiList(roiList.depth==2,:);
% 
% %% Combine the cerebellum class. 
% % Get the brain stem index in the roiList
% cerebellumIdx = contains(roiList.structure_id_path,s2.structure_id_path{3});
% 
% % Assign the id of the top brain stem in the atlas image
% atlas(ismember(atlas,roiList.id(cerebellumIdx))) = s2.id(3);
% 
% % Remove the lower level brain stem class in the roiList
% roiList(cerebellumIdx,:)=[]; roiList = [roiList; s2(3,:)];

%% %%%%%%%%%%%%% Deal with some special cases
% Check the voxel intensity range
valRange = unique(atlas(:)); % 0 is the background

% Find out intensity values that are not in the list. Usually these are
% areas that have not been assigned to a region or it is controversial in
% the literature. We need to deal with these areas.
unsignedVal = valRange(~ismember(valRange,roiList.id)); 
unsignedList = roiList(~ismember(roiList.id,valRange),:); % Note some areas have been divided into finer structures, but the IDs for the older and larger areas have been kept

% 1. we see 997 as the background
atlas(atlas==997) = 0;

% 2. There are some upper level areas such as hippocampal formation having
% a value in the atlas, which usually are unsigned or edge areas. We can
% just keep an eye on them.

% Save the modified annotation atlas and the correponding structure info
nii.img = atlas;
save_nii(nii,fullfile(atlasPath,'annotation_100_modified_csfWMcerebellumUncombined.nii'));
writetable(roiList, fullfile(atlasPath, 'structures_modified_csfWMcerebellumUncombined.csv'))








