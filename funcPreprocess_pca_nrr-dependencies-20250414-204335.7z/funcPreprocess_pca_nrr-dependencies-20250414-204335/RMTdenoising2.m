% function [dataDenoised,R,sigma] = RMTdenoising2(data, winsize, shift,
% wantRankWeighting, wantGaussWeighting, k0) denoises data based on RMT-based
% PCA. It is implemented using patch processing based on glhosvd.m provided
% by Xinyuan Zhang but modified to enable parfor. This version only works
% for 4D data with the fourth dimesion the repetative measurement. 
%
% Inputs:
% <data> of 4D dimension but assume the last dimension the repetitive dimension
% <winsize>: (optional)  is an integer array indicting the window size for
%   segmentation. When specified, winSizeHalf should be either a scalar
%   (isotropic for 3 dimesions) or a vector mirror the dimension of data.
%   The default value is 5 for each dimension if it is []. 
% <shift> (optional) is a scalar or array indicating how much elements the
%   window advances. If it is a scalar, it assumes all dimensions that need
%   to be segmented bear the same shift; if it is an array, it should
%   mirror winsize, indicating different shift for different dimensions.
%   Default is [], meaning one sample shift per segment.
% <wantRankWeighting> (optional) is either 0 or 1. If 1, window weighting
%  based on the estimated rank will be applied. Default is 0, equivalent to
%  no rank weighting. 
% <wantGaussWeighting> (optional) can be a scaler or a 2-element vector. If
%   the first element is 0, no Gaussian weighting on patches. If 1,
%   Gaussian weighting with the second element indicating the width of the
%   Gaussian kernel. Default is 400, equivalent to delta weighting.
% <k0> (optional) is the moments that will be considered when performing
%   RMT PCA denoising. Default is 1:4, the first 4 moments.
%
% Outputs:
% <dataDenoised> is the denoised matrix
% <R> is the estimated rank
% <sigma> is the estimated noise standard deviation
%
% See also: ssvd.m
%
% Copyright (C) 2021 CMRR at UMN
% Author: Wei Zhu (zhuwei.umn) and Xiaoping Wu <xpwu@cmrr.umn.edu>
% Created: Jul. 28 2021

function [dataDenoised,R,sigma] = RMTdenoising2(data, winsize, shift, wantRankWeighting, wantGaussWeighting, k0)

if ~exist('winsize','var') || isempty(winsize)
    winsize = 1;
end
if isscalar(winsize)
    winsize = repmat(winsize,1,ndims(data)-1); % block size
end
if ~exist('shift','var') || isempty(shift)
    shift = 1;
end
if ~exist('wantRankWeighting','var') || isempty(wantRankWeighting)
  wantRankWeighting = 1;
end
if ~exist('wantGaussWeighting','var') || isempty(wantGaussWeighting)
  wantGaussWeighting = 1;
end
if length(wantGaussWeighting)==1
  wantGaussWeighting = [wantGaussWeighting 400]; % Corresponding to delta-weigthting
end

if ~exist('k0','var') || isempty(k0)
  k0 = 1:4;
end

fprintf('--------start denoising--------\n');

% Get initial time vector
time0 = clock;

% Window size 
winx = winsize(1);
winy = winsize(2);
winz = winsize(3);

% The local denoising stage
[sx,sy,sz,M] = size(data);
Ys = zeros( size(data) );
W = zeros( size(data) );
R = zeros(sx,sy,sz); % rank
sigma = zeros(sx,sy,sz); % noise standard deviation

% Window index for each dimension
indices_x= [1:shift:sx-winx sx-winx+1];
indices_y= [1:shift:sy-winy sy-winy+1];
indices_z= [1:shift:sz-winz sz-winz+1];

% Segment the data for parfor
disp('-> segment data...')
data0= zeros(winx,sy,sz,M,length(indices_x));
for i  =  1:length(indices_x) 
    data0(:,:,:,:,i)= data(indices_x(i): indices_x(i)+winx-1, :, :, :);
end

% denoise
disp('-> denoise...')
Ys0= zeros(winx,sy,sz,M,length(indices_x));
W0= Ys0;
R0= zeros(sy,sz,length(indices_x));
S0= R0;

parfor  i = 1:length(indices_x)
    fprintf('--- denoising: i=%i (%i total) --- \n',i, length(indices_x))
    
    iB1= data0(:, :, :, :,i);
    iYs = zeros(winx,sy,sz,M);
    iW = iYs;
    iR = zeros(sy,sz);
    iS = zeros(sy,sz);
    
    for j = indices_y
        for k = indices_z
            
            B1=iB1(:, j:j+winy-1, k:k+winz-1, :);
            
            [Ysp, Wp, Rp, Sigmap] = Low_rank_SSC(double(B1), wantRankWeighting, wantGaussWeighting, k0);
            
            iYs(:,j:j+winy-1,k:k+winz-1,:)=iYs(:,j:j+winy-1,k:k+winz-1,:)+ Ysp;
            iW(:,j:j+winy-1,k:k+winz-1,:)=iW(:,j:j+winy-1,k:k+winz-1,:)+ Wp;
            iR(j,k)= Rp;
            iS(j,k)= Sigmap;
            
        end
    end
    
    Ys0(:,:,:,:,i)= iYs;
    W0(:,:,:,:,i)= iW;
    R0(:,:,i)= iR;
    S0(:,:,i)= iS;
    
end

% aggregate data
disp('-> aggregate segmented results...')
for i  =  1:length(indices_x)
    
    Ys(indices_x(i):indices_x(i)+winx-1, :, :, :)= Ys(indices_x(i):indices_x(i)+winx-1, :, :, :)+ Ys0(:,:,:,:,i);
    W(indices_x(i):indices_x(i)+winx-1, :, :, :)= W(indices_x(i):indices_x(i)+winx-1, :, :, :)+ W0(:,:,:,:,i);
    R(indices_x(i),:,:)= R0(:,:,i);
    sigma(indices_x(i),:,:)= S0(:,:,i);
    
end

% Denoised data
dataDenoised  =  Ys./W;

fprintf('Total elapsed time = %f min\n\n', (etime(clock,time0)/60) );

end

function  [X, W, R, sigma] = Low_rank_SSC(Y, wantRankWeighting, wantGaussWeighting,k0)

[X, R, sigma]= ssvd(Y,'svs1','ssvd',k0);

if wantRankWeighting
    wei = 1/(1+R);
else
    wei = 1;
end

if wantGaussWeighting(1)
    % Weighting changes as ws changes
    wei = wei.*repmat(windowN(@gausswin,sizefull(X,3),wantGaussWeighting(2)),1,1,1,size(X,4));
    
    % weighting fixed for all ws, near to the delta function
    %wei =   wei.*repmat(padarray(windowN(@gausswin,[3 3 3],4),([sx sy sz]-[3 3 3])/2),1,1,1,M);
end

W   =   wei.*ones( size(X) );
X   =   X.*wei;
end






