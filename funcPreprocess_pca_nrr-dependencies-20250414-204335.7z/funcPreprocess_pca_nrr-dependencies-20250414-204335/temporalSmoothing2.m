% cutoff is in Hz

function img4D=temporalSmoothing2(img4D,mask,tr,cutoff,order,mode)

imgdim = sizefull(img4D,ndims(img4D)-1); % img size
n = size(img4D,ndims(img4D)); % time point

if ~exist('mask','var') || isempty(mask)
    mask = ones(imgdim);
end
if ~exist('cutoff','var') || isempty(cutoff)
    cutoff = 0;
end
if ~exist('order','var') || isempty(order)
    order = 5;
end
if ~exist('mode','var') || isempty(mode)
    mode = 0;
end


img2D = reshape2D(img4D,ndims(img4D))';
img2D = img2D(mask>0,:);
img2Dbase = mean(img2D,2);

cutoff = cutoff*n*tr; % from Hz to cycles per field-of-view, i.e. (cycles per sec) * (points per fov) * (sec per point)

% construct butter filter
flt = constructbutterfilter1D(n,cutoff,order);

% filter data
img2D = tsfilter(img2D,flt,mode);

% Recover the data
img4D = zeros([imgdim,n]);
tmp = reshape2D(img4D,ndims(img4D))';
tmp(mask>0,:) = img2D + repmat(img2Dbase,1,n); % Add mean value to the filtered signal
img4D = reshape2D_undo(tmp',ndims(img4D),[imgdim,n]);

end