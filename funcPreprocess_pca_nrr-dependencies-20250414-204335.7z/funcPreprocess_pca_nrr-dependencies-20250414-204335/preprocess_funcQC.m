% Fmri data quality control
%
% Input:
% <func>, one 4D time series or a cell array
% 
% 1. The overlay image of the first and last volume of the EPI images
% 2. tSNR map for whole brain or segemented brain tissues
% 3. Voxplot, a flattened 2D image with the horizontal axis the volume
% number and the vertical axis the brain voxels in an organized or
% unorganized fashion
% 4. Framewise displacement plot (Power, et al. 2012)

function outliers = preprocess_funcQC(intermPath, epis, masks, mparam, species, imgrotate, figvisible,figname)

% inputs
% make cell if necessary
if ~iscell(epis)
  epis = {epis};
end
nepis = length(epis);

if ~iscell(intermPath)
  intermPath = {intermPath}; 
end
if length(intermPath)==1
    intermPath = repmat(intermPath,1,nepis);
end


if ~exist('masks','var') || isempty(masks)
  masks = cellfun(@(x) automask(x,0.2,0),epis,'UniformOutput',0);
  %figure; imshow(makeMontage(masks,0,0,'xy'),[])
elseif ~iscell(masks)
    masks = repmat({masks},1,nepis);
end
% Note that the first row of mparam is the reference parameter 
if ~exist('mparam','var') || isempty(mparam)
  try
    [~,mparam,~] = motioncorrectvolumes(epis,[1 1 1 1]); % Here the voxel size doesn't matter?
  catch 
     warning('\n Motion estimation not run');
     mparam = cellfun(@(x) zeros(size(x,4)+1,6), epis, 'UniformOutput',0);
  end

elseif ~iscell(mparam)
    mparam = {mparam};
end
if ~exist('species','var') || isempty(species)
  species = 'human';
end
if ~exist('imgrotate','var') || isempty(imgrotate)
  imgrotate = 0;
end
if ~exist('figvisible','var') || isempty(figvisible)
  figvisible = 0;
end
if ~exist('figname','var') || isempty(figname)
  figname = 'funcQC';
end

if isequal(species, 'mouse')
    brainRadius = 3; % mm
elseif isequal(species, 'rat')
    brainRadius = 6; % mm
elseif isequal(species, 'cat')
    brainRadius = 10; % mm
elseif isequal(species, 'human')
    brainRadius = 50;
elseif isnumeric(species)
    brainRadius = species;
else
    fprintf('Unknown species or brain size')
end

% Do it
outliers = cell(1,nepis);
for p=1:nepis
  outliers{p} = funcQC_helper(intermPath{p},epis{p},masks{p}, mparam{p}, brainRadius, imgrotate,figvisible,figname);
end

% Helper function
function outliers = funcQC_helper(intermPath, epi, masks, mparam, brainRadius, imgrotate, figvisible,figname) 
[nx,ny,nz,nt] = size(epi);

% 1. Overlay image of the first and last volume of the EPI scan
% Make montage images for the first and last epi volumes
func1 = makeMontage(epi(:,:,:,1),imgrotate,0,'xy');
if size(func1,1) > size(func1,2)
    imgrotate = 1;
    func1 = makeMontage(epi(:,:,:,1),imgrotate,0,'xy');
end
funcend = makeMontage(epi(:,:,:,end),imgrotate,0,'xy');

% Composite the two images
C = imfuse(func1, funcend, 'falsecolor', 'Scaling', 'joint');

% 2. Create tSNR map and draw
[itsnr,mn,mad] = computetemporalsnr(double(epi));
tsnr = 100./itsnr; % Note itsnr is percentage
tsnr = tsnr.*automask(mn);

% figure; imshow(makeMontage(mn,0,0,'xy'),[0,max(mn(:)/1.2)])
% figure; imshow(makeMontage(mad,0,0,'xy'),[0,max(mad(:)/1.2)])
% figure; imshow(makeMontage(log10(itsnr),0,0,'xy'),[],'colormap',jet)
% figure; imshow(makeMontage(snr,imgrotate,0,'xy'),[0,max(snr(:)/1.2)],'colormap',jet)
% colorbar

% 3. Voxplot

% Flatten the 4D data to 2D, with the last dimension the time dimension
func2D = reshape(double(epi), [nx*ny*nz,nt]);

% Calculate percent signal change
func2D_psc = 100*(func2D./repmat(mean(func2D,2),1,size(func2D,2),1)-1);
func2D_psc(isnan(func2D_psc))=0;

% Detrend (mean and linear) and mask
nTissue = size(masks,4);
func2D_psc_detrended_masked = [];
for ii = 1:nTissue
    func2D_psc_detrended_masked = [func2D_psc_detrended_masked, detrend(func2D_psc(masks(:,:,:,ii)>0,:)',1)]; % time X voxels
end

% Draw it, voxels X time
% figure; imagesc(func2D_psc_detrended_masked',[-6,6]); colormap(gray)
% ylabel('Voxels')
% xlabel('fMRI volumes')

% % Identify limits between the different tissue compartments
% hold on
% linePos = squeeze(cumsum(sum(masks, 1:3)));
% straightline(linePos,'h','w-');
% hold off


% 4. Framewise displacement plot
% Only the translation and rotation for rigid transformation and detrend
% the parameters
mparam = detrend(mparam(2:end,1:6)-repmat(mparam(1,1:6),size(mparam,1)-1,1)); 
mparam(:,4:6) = mparam(:,4:6)*brainRadius; % mm

% Calculate framewise displacement
D = diff(mparam,1,1); % 1st order derivatives
D = [zeros(1,6); D]; % Set first row to 0
FD = sum(abs(D),2); % Framewise displacement
outliers = outlierDetection(FD,'Carling');

% Percent of volumes passed the FD
outlierPct = 100*sum(outliers)/nt;

% figure; plot(0:nt,FD);
% xlim([0,nt]);
% grid; axis tight
% % set(ax2,'Xticklabel',[]);
% title('FD')
% ylabel('mm')

% Plot



figureprep([0 0 1 1],figvisible);

ax1 = subplot(8,2,[1,3,5,7]);
imshow(C); title('Composite img of 1st and last images');

ax2 = subplot(8,2,[2,4,6,8]);
imshow(makeMontage(tsnr,imgrotate,0,'xy'),[0,max(tsnr(:)/1.2)],'colormap',jet)
colorbar; title('SNR map');

ax3 = subplot(8,2,[9,10]);
plot(1:nt,FD,find(outliers),FD(outliers),'v'); grid; axis tight
xlim([1,nt]); ylabel('FD (mm)'); title(sprintf('Framewise Displacement (outlier percentage: %%%0.2f)',outlierPct))
set(ax3,'Xticklabel',[]);

ax4 = subplot(8,2,[11:16]);
imagesc(ax4, func2D_psc_detrended_masked',[-6,6]); %colorbar %colormap(gray)
ylabel('Voxels'); xlabel('fMRI volumes')

% Identify limits between the different tissue compartments
hold on
linePos = squeeze(cumsum(sum(masks, 1:3)));
straightline(linePos,'h','w-');
hold off

h = findobj(gcf); % Get the handles associated with the current figure
allLines = findall(h, 'Type', 'line'); set(allLines, 'Linewidth',2)
allAxes = findall(h, 'Type', 'axes'); set(allAxes, 'Linewidth',2.5, 'FontWeight','bold', 'FontSize',16, 'Box', 'off')
allText = findall(h, 'Type', 'text'); set(allText, 'FontWeight','bold', 'FontSize',20)

if ~isempty(intermPath)
figurewrite(figname,[],[],intermPath,figvisible);

end

%% To do: place the plots in a better way
% pos = get(gcf, 'Position'); %// gives x left, y bottom, width, height
% width = pos(3);
% height = pos(4);
% 
% width/2 * size(C,1)/size(C,2)/height
% 
% 
% height*0.5*size(C,2)/size(C,1)/width
% 
% figureprep([0 0 1 1],1)
% posImg1 = [0.05 0.5 0.36 0.4]; % [left bottom width height]
% subplot('Position',posImg1);
% imshow(C); title('Composite img of 1st and last images');

