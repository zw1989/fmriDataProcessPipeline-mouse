% function [corrMap,ss,cmax] = calcPhaseCorr(img, refImg, smoothSigma, w,
% maxshift, subpixel) calculates the spatial correlation (corrMap) between
% img and refImg by mutiplying their phase maps in Fourier domain.
% Pixel(voxel) shifts (ss) are calculated based on the maximum phase
% correlation. Option to output pixel(voxel) shift (ss), maximum
% correlation value (cmax), and corrected image (img).
% 
% Inputs
% <img> is a series or cell of images in any dimensions. The spatial
%   dimension is the same as refImg. 
% <refImg> is the reference image with whom we calculate the spatial
%   correlation of <img>. It should have the same spatial dimension with <img>.
% <smoothSigma> is the standard deviation of the Gaussian distribution
%   controlling how much smoothing is applied to refImg in Fourier domain.
%   Low-pass filter is constructed based on the desired resolution in
%   voxels (FWHM = 2*sqrt(2*log(2))*smoothSigma~2.355*smoothSigma) using
%   butter filter. It also controls the width of the taper function <w> if
%   <w> is empty. Default is 1.2. It can also be a vector with the same
%   length as the dimension of refImg.Special case is a matrix with the
%   same size as <refImg>, i.e. a smoothing kernel in Fourier domain.
% <w> is the taper (window) function used to weight <img> to reduce
%   artifacts, edge leakage. Special case is w = 1, meaning do nothing
%   special.
% <maxshift> controls the maximum pixel(voxel) shifts between <img> and
%   <refImg>. It can either be a scaler or a vector with the same length as
%   the <img> dimension number. Elements that are less than one is regarded
%   as percentage. Default is [], i.e. don't estimate pixel shifts.
% <subpixel> is a scaler indicating the interpolation number for each
%   pixel(voxel). Default is [], meaning no subpixel estimation.
% <skipCorrection> is either 0 or 1(Default), indicating whether translation
%   correction should be skipped.
% 
% Hisotry:
% 2024/01/23 - created
% 
% TO DO:
% * Batch processing? This could be useful when the img repetition is large


function [corrMap,ss,cmax,img] = calcPhaseCorr(img, refImg, smoothSigma, w, maxshift, subpixel, skipCorrection)

ndim = ndims(refImg); % The number of img dimensions 
imgdim = size(refImg); % image size

% Inputs:
if ~exist('smoothSigma','var') || isempty(smoothSigma)
  smoothSigma = 1.0; % unit: pixel/voxel 
end
if isvector(smoothSigma) && length(smoothSigma)<=ndim
  % Get smoothing filter for refImg
  volsize = ones(1,ndim); % No meaning for now. Should we use real volsize?
  fwhm = 2.355*smoothSigma.*volsize; 
  wr = constructbutterfilterND(imgdim,{volsize, fwhm},10); % Smooth function for refImg
  %figure;imshow(makeMontage(fftshift(wr),1,0,'xy'),[]);
else
  wr = smoothSigma;
  smoothSigma = 1.0;
end
if ~exist('w','var') || isempty(w)
  sig = 3*smoothSigma;
  w = windowN(@sigmoidwin, imgdim, normalizemax(imgdim).*sig); 
end
if ~exist('maxshift','var') || isempty(maxshift)
  maxshift = [];
end
if ~exist('subpixel','var') || isempty(subpixel)
  subpixel = []; 
end
if ~exist('skipCorrection','var') || isempty(skipCorrection)
  skipCorrection = 1; 
end

isbare = ~iscell(img);
if isbare
  % Change data to cells 
  img = squeeze(num2cell(reshape(nanreplace(img),[imgdim,numel(img)/prod(imgdim)]),1:ndim));
end


% Flags
wantPixShiftEst = ~isempty(maxshift);
wantSubPixelEst = ~isempty(subpixel);


%% Do it

%%%%%%%%%%% Deal with refImg

% Get complex conjugate of the fourier transformed refImg and normalized to their magnitude(padded for speed?)
cfRefImg = fftn(refImg);
cfRefImg = cfRefImg./(eps + abs(cfRefImg)) .* wr;

% % Gaussian filter version
% wr = windowN(@mygausswin, imgdim, smoothSigma);
% cfRefImg = fftn(refImg);
% cfRefImg = cfRefImg./(eps + abs(cfRefImg)) .* real(fftn(ifftshift(wr))); % Only leave the phase information
% figure;imshow(makeMontage(fftshift(real(fftn(ifftshift(wr)))),1,0,'xy'),[]);

%%%%%%%%%%% Deal with img

% Get phase map on windowed data
wOff = mean(refImg(:))*(1-w); % Get offsets
cfImg = cellfun(@(x) fftn(x.*w+wOff), img,'UniformOutput',0);
cfImg = cellfun(@(x) x./(eps + abs(x)), cfImg,'UniformOutput',0);

% Calculate phase correlation map
corrMap = cellfun(@(x) real(fftshift(ifftn(x.*conj(cfRefImg)))), cfImg,'UniformOutput',0);

%% Obtain shift information along each dimension
ss = [];
cmax = [];
if wantPixShiftEst
  % Deal with single value case
  if length(maxshift) == 1
    maxshift = ones(1,ndim)*maxshift;
  end
  
  % Deal with any elements that are Percentage
  maxshift(maxshift<1) = ceil(maxshift(maxshift<1).*imgdim(maxshift<1));
  maxshift = min(maxshift,ceil(imgdim/2-1)); % voxels
  
  % Get index range along each dimension
  idxtmp = cellfun(@(x,y) (-x:x)+ceil((y+1)/2), num2cell(maxshift),num2cell(imgdim),'UniformOutput',0);
  
  % Get substitutes and convert them to indices
  indtmp = sub2ind2(imgdim,idxtmp);
  
  % Get sub-blocks with size (2*maxshift+1) and get the index of maximum 
  [cmax,idx] = cellfun(@(x) max(x(indtmp(:))), corrMap);
  sub = ind2sub2(2*maxshift+1,idx);
  
  % Get voxel shifts
  ss = catcell(2,cellfun(@(x,y) x-y-1, sub, num2cell(maxshift),'UniformOutput',0)); % Get shift number;

  %% Kriging interpolation (subpixel estimation)
  if wantSubPixelEst
  
    % Sub-block size (2*lpad+1) centered at maximum cc point 
    lpad = min(3, ceil(imgdim/2-1)-maxshift); % No larger than 3
    
    % Upsampling kernel (Kriging)
    lpadUp = lpad*subpixel;
    Kmat = upsamplingKernel(lpad,lpad,[1,1]) \ upsamplingKernel(lpad,lpad,[1,1/subpixel]);
    
    ssk = 0*ss;
    parfor ii = 1:size(ss,1)
      % Get index range along each dimension
      idxtmp = cellfun(@(x,y,z) (-x:x)+ceil((y+1)/2)+z, num2cell(lpad),num2cell(imgdim),num2cell(ss(ii,:)),'UniformOutput',0);
      
      % Get subscripts and convert them to indices
      indtmp = sub2ind2(imgdim,idxtmp);
      
      % Get sub-blocks with size (2*lpad+1) 
      ccmat = flatten(corrMap{ii}(indtmp(:)));
      
      % Kriging interpolation (subpixel prediction)
      cck = ccmat * Kmat;
      [cmax(ii),idx] = max(cck,[],2);
      sub = ind2sub2(2*lpadUp+1,idx);
      ssk(ii,:) = cellfun(@(x,y) (x-y-1)/subpixel, sub, num2cell(lpadUp)); % Get shift number;
    end
    
    % Total shift
    ss = ss + ssk; % voxel + sub-voxel
  end % wantSubPixelEst
  
  %% Apply translation
  
  if ~skipCorrection
    if wantSubPixelEst % This only works on 3D data for now
      % See ss as a uniform shift map
      % sstmp = repmat(reshape(ss,[ones(1,ndim),size(ss)]),[imgdim,1,1]);
      % [newvols1,voloffset,validvol] = undistortvolumes2(img,volsize,sstmp,1:ndim,[]);
      % figure;imshow(makeMontage(newvols1,1,0,'xy'),[]);
      
      % See ss as rigid motion (This is faster)
      % Create motion parameter in spm format
      volsize = ones(1,ndim);
      sstmp = repmat(spm_imatrix(createspmmatrix(imgdim,volsize)),size(ss,1),1);
      sstmp(:,1:3) = sstmp(:,1:3) + ss*diag([1,-1,-1]);
      [img,~,validvol] = undistortvolumes2(catcell(ndim+1,img),volsize,[],[],sstmp);
    %   figure;imshow(makeMontage(img,1,0,'xy'),[]);
    %   figure;imshow(makeMontage(validvol,1,0,'xy'),[]);
  
      if ~isbare
        img = squeeze(num2cell(img,1:ndim));
      end
      
    else
      img = cellfun(@(x,y) circshift(x,-y), img,num2cell(ss,2),'UniformOutput',0);
  
      if isbare
        img = catcell(ndim+1,img);
      end
    end
  
  end % Img registration
end % wantPixelShiftEst







