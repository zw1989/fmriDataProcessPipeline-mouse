


function w = sigmoidwin(N,sig)


% Create a mean-centered grid
x = (1:N)-1;
x = abs(x - mean(x));

% Get center value
xx = N/2-2*sig;

% get a mask along each dimension and combine them. This is constructed
% based on the sigmoid function
w = 1./(1 + exp((x - xx)/sig));

