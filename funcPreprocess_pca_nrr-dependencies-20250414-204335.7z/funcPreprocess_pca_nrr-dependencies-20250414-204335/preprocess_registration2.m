% This function estimates (and corrects) motion (only translations) by
% calculating the maximum phase correlation shift from map center. The
% phase correlation map is calculated by multiplying phase images between
% reference image and target images in Fourier domain. It can also estimate
% the non-rigid voxel shift maps by calculating the block-wise maximum
% phase correlation shift. In this nonrigid estimation mode, images are
% efficiently divided into blocks and go through the rigid processing.
%
% Path inputs:
% <intermPath> is the intermediate directory or a one-level cell vector
%   of directories to write intermediate figures and results to. [] means do
%   not output figures and results. 
%
% Necessary data inputs:
% <data> is 
%   (1) a time-series of 3D volumes, X x Y x Z x T. The volumes should be
%       suitable for interpretation as int16.
%   (2) a cell vector of one or more things like (1). The first three
%       dimensions (X, Y, Z) must be the same across the various cases.
% <ref> (optional) indicates which data volume should be used
%   as the reference for motion correction. The format is [g h] where g
%   indicates the index of the data run and h indicates the index of the
%   volume within that run. Special case is 1) h = 0, meaning to take the
%   average of that run directly, and 2) h = -1, meaning to obtain the ref
%   by averaging the top 20 most correlated volumes and then iteratively
%   refine it. Can also be the 3D volume itself (we use this case if
%   ~isvector(<ref>)). default: [1 1], meaning the first volume of the
%   first run as a reference. 
% <smoothSigma> is the standard deviation of the Gaussian distribution
%   controlling how much smoothing is applied to refImg in Fourier domain.
%   Low-pass filter is constructed based on the desired resolution in
%   voxels (FWHM = 2*sqrt(2*log(2))*smoothSigma~2.355*smoothSigma) using
%   butter filter. It also controls the width of the taper function.
%   Default is 0.5. It can also be a vector with the same length as the
%   dimension of refImg.
% 
% Non-rigid estimation inputs:
% <blockShift> is a vector of integers with the same length as the dimensions of ref.
%   It indicates the distance between neighbor blocks. If it has the same
%   size as referece image, only one block, i.e. the whole image, is used
%   for registration, which is equivalent to the rigid registration.
%   Special case [] means don't do non-rigid estimation. Example:
%   blockShift = [4,4,1], neighboring blocks has a distance of [4,4,1]
%   along each dimension, respectively.
% <blockSize> is a vector of integers with the same length as blockShift.
%   It is the size of the blocks. If it has the same
%   size as referece image, only one block, i.e. the whole image, is used
%   for registration, which is equivalent to the rigid registration.
%   Special case [] means blockSize is the spatial data size. Example:
%   blockSize = [32,32,1], [8,8,6], or [64,48,12]. Note [24,10,1] causes
%   regisration problems?
% <maxRegShift> controls the maximum pixel(voxel) shifts between data blocks and
%   ref blocks. It can either be a scaler or a vector with the same length as
%   the ref dimension number. Elements that are less than one is regarded
%   as percentage. Default is 0.1, i.e. 10% of the block size. Example,
%   maxRegShift = [2,2,1];
% <snrThresh> is a scaler controling the correlation SNR. The idea behind is that if a block
%   doesn't contain too much information, the correlation coefficient will be
%   small, i.e. maximum cc/surrounding cc will be small, and thus the shift
%   calculated for such a block will not be accurate. Gaussian smoothing of
%   the phase correlation map of such a block will be applied to enhance
%   the SNR and reduce shift bias (i.e. no shift for noise blocks).
% <subpixel> is a scaler indicating the interpolation number for each
%   pixel(voxel). A large number can dramatically increase running time and
%   the estimation accuracy may not increase. subpixel = 10 is a reasonable
%   choice. Default is [], meaning no subpixel estimation.  
% <skipCorrection> is either 0(Default) or 1, indicating whether data
%   correction should be skipped.
%
% Hisotry:
% 2024/01/26 - created
% 
% TO DO:
% * More tests should be done on 2D cases

function [data,rigidEst,nonrigidEst,nonrigidMap,refImg] = preprocess_registration2(intermPath,... 
                                                    data,ref,smoothSigma,...
                                                    blockShift,blockSize,maxRegShift,snrThresh,subpixel,...
                                                    skipCorrection)
dbstop if error;
if isempty(gcp); parpool(16); end

% inputs
if ~exist('intermPath','var') || isempty(intermPath)
  intermPath = [];
end
if ~exist('ref','var') || isempty(ref)
  ref = [1 1];
end
if ~exist('smoothSigma','var') || isempty(smoothSigma)
  smoothSigma = 0.5; 
end
if ~exist('blockShift','var') || isempty(blockShift)
  blockShift = [];
end
if ~exist('blockSize','var') || isempty(blockSize)
  blockSize = []; 
end
if ~exist('maxRegShift','var') || isempty(maxRegShift)
  maxRegShift = 0.1; % Better to be small for small block processing, e.g. [2,2,1]
end
if ~exist('snrThresh','var') || isempty(snrThresh)
  snrThresh = 2.0; 
end
if ~exist('subpixel','var') || isempty(subpixel)
  subpixel = []; 
end
if ~exist('skipCorrection','var') || isempty(skipCorrection)
  skipCorrection = 0; 
end

isbare = ~iscell(data);
if isbare
  data = {data};
end

% figure out reference volumes
if isvector(ref) 
  if ref(2) == 0 % Deal with special motion reference vol
    refImg = mean(data{ref(1)},ndims(data{ref(1)}));
  elseif ref(2) == -1 % Deal with special motion reference vol
    refImg = pick_ref2(double(data{ref(1)}),smoothSigma); % Pick reference image
  else
    refImg = reshape(data{ref(1)},[],size(data{ref(1)},ndims(data{ref(1)})));
    refImg = reshape(refImg(:,ref(2)),sizefull(data{ref(1)},ndims(data{ref(1)})-1));
  end
else
  refImg = ref;
end

if ~iscell(intermPath)
  intermPath = {intermPath};
end
if length(intermPath)==1
  intermPath = repmat(intermPath,[1 length(data)]);
end

% make figuredir if necessary
if ~isempty(intermPath)
  cellfun(@mkdirquiet,intermPath);
end

if length(subpixel)==1
  subpixel = ones(1,3)*subpixel;
end

% Flags
wantfigs = ~isempty(intermPath{1});
wantNonrigidEst = ~isempty(blockShift);
wantSubPixelEst = ~isempty(subpixel);

% Addtional params
batchSize = 500; % Reserved for future use
volsize = [1,1,1]; % unit: voxel. 

%% Calc
ndata = length(data);
datadim = size(refImg);
ndim = length(datadim)+1; % The number of data repetitions 

% Normalize reference image???
rmin = round(prctile(refImg(:),1));
rmax = round(prctile(refImg(:),99));
refImg = normalizerange(refImg,rmin,rmax);

% Window function
w = windowN(@sigmoidwin, datadim, 3*smoothSigma.*normalizemax(datadim)); % Taper function for data

%% Non-rigid preparation
if wantNonrigidEst
  fprintf('Non-rigid preparation...');
  %% Block information
  % Make blocks, cblocks contains the substitutes of each block center
  [cblocks, blockdim, indCblocks] = make_blocks(datadim, blockSize, blockShift);
  
  % Block number
  nb0 = prod(blockdim); 
  
  % Get brain mask. Expand the mask out by ceil(max(block_size)/8 voxels 
  refMask = automask(refImg,0.1,4,4+ceil(max(blockSize)/8)); 
  indMask = find(refMask);
  
  % Check whether the block center is in the mask
  indValid = find(ismember(indCblocks,indMask)).'; % The valid linear index of the blocks
  
  % Valid block number. 
  nb = length(indValid); 
  
  % Window function for each block
  wb = windowN(@sigmoidwin, blockSize, 2*smoothSigma.*normalizemax(blockSize));
  fwhm = 2.355*smoothSigma*volsize;
  wrb = constructbutterfilterND(blockSize,{volsize fwhm},10); % Smooth function (low-pass filter) for refImg
  
  % Initiate
  indBlock = cell(nb,1);
  wBlock = indBlock;
  refBlocks = wBlock;
  % Index for each block (center at 0)
  idxBlock = cellfun(@(x) (1:x)-(x+1)/2, num2cell(blockSize),'UniformOutput',0);
  for ib = 1:nb 
  
    indBlockTmp = indValid(ib);
    
    % Get index range for each block
    idxtmp = cellfun(@(x,y) ceil(x(indBlockTmp)+y), cblocks, idxBlock,'UniformOutput',0);
  
    % Deal with non-positive values and larger than data matrix values
    % (i.e. those lie outside of the data matrix). Here we try to symmetric the
    % matrix values along the borders. [Should we zero them??]
    idxtmp = cellfun(@(x,y) [flip(x(~(x>0)))+sum(~(x>0)),...
                             x(x>0 & x<(y+1)),...
                             flip(x(x>y))-sum(x>y)], idxtmp, num2cell(datadim),'UniformOutput',0);
  
    % Get subscripts for each point in the block
    indtmp = sub2ind2(datadim,idxtmp);
    indBlock{ib} = indtmp;
    
    % Get reference image block
    refBlocks{ib} = refImg(indtmp);
    
    % Get block window function
    wbn = wb.*w(indtmp);
    %wbn = wb;
    wBlock{ib} = wbn;
    
  end 
  
  %% Pixel/voxel shift limit for nonrigid registration
  % Deal with single value maxRegShift
  if length(maxRegShift) == 1
    maxRegShift = ones(1,ndim-1)*maxRegShift;
  end
  
  % Deal with any elements that are Percentage
  maxRegShift(maxRegShift<1) = ceil(maxRegShift(maxRegShift<1).*blockSize(maxRegShift<1));
  maxRegShift = min(maxRegShift,ceil(blockSize/2-1)); % voxels

  % Shift voxels +/- lpad. This is the half window size for subpixel
  % estimation
  lpad = min(3, ceil(blockSize/2-1)-maxRegShift); % No larger than 3

  %% Construct gaussian radial basis function for cSNR enhancement
  R = gaussianRadialBasisFunctionD2(blockdim).';
  R = R(indValid,indValid);
  R2 = R*R;

  %% Plot overlaped blocks
  if wantfigs
    imgBlock = zeros(datadim);
    for ii = 1:nb
      imgBlock(indBlock{ii}) = imgBlock(indBlock{ii}) + 1;
    end
    % Get block centers
    imgBlock2 = zeros(datadim);
    imgBlock2(indCblocks) = 1; 
    imgBlock2(indCblocks(indValid)) = 2; % Block centers inside the brain
    % Get an example block
    iblock = round(nb/2);
    imgBlock2(indCblocks(indValid(iblock))) = 3; % Chosen block center
    imgBlock2(indBlock{iblock}([1,end],:)) = 4;
    imgBlock2(indBlock{iblock}(:,[1,end])) = 4;
    
    % Plot
    figName = 'blockSamplingPlot';
    afigure(aconfig('Name',figName,'Width',1600,'Height',650,'FontSize',8,'Visible','off')); 
    imagecombo(imgBlock,[],{1,0,'xy'},refImg,imgBlock2,[],jet(256),[],'overlapped',[1,0],'point'); 
    colorbar('off')
    legend({'','Valid block centers','','An example block'},'Location','southwest','Orientation','horizontal');
    figurewrite(figName,[],[],stripfile(intermPath{1}));
    % figure;imshow(makeMontage(imgBlock,1,0,'xy'),[]); colormap(brewermap([],"-YlGnBu"))

    clear imgBlock imgBlock2
  end

  fprintf('done! \n');

end

%% Process each time-series
% Init
rigidEst = cell(1,ndata);
nonrigidEst = cell(1,ndata);
nonrigidMap = cell(1,ndata);

fprintf('processing %d time-series...\n',ndata);
for id = 1:ndata
  % The number of image repetitions, may vary across data
  nt = size(data{id}, ndim); 
  
  % Change data to cells here. Note we replace NAN to 0 and hide spatial
  % dimension information 
  datatmp = squeeze(num2cell(nanreplace(double(data{id})),1:ndim-1));

  % Initiate 
  rigidEstTmp = [];
  nonrigidEstTmp = [];
  nonrigidMapTmp = [];
  % dataAvg = zeros(datadim);
  
  %% Batch processing
  for k = 1:batchSize:nt
    fprintf(' processing %d of %d batches ...',1+(k-1)/batchSize,ceil(nt/batchSize));
    %% Data preprocessing
    % Get batch data 
    dataBatch0 = datatmp(k:min(k+batchSize-1,nt)); 
    ntBatch = length(dataBatch0);
  
    % Normalize data and change varible name to not change original data???
    dataBatch = cellfun(@(x) normalizerange(double(x),rmin,rmax), dataBatch0,'UniformOutput',0);
    
    % Spatial smoothing??
    % dataBatch = smoothvolumes(dataBatch,volsize,[2,2,0.01].*volsize);
  
    %% Rigid registration (translation in pixel/voxel only)
    fprintf('   Rigid estimation ...');
    rigidMaxshift = 0.1;
    [~,ss,cmax,dataBatch] = calcPhaseCorr(dataBatch, refImg, smoothSigma, w, rigidMaxshift,[],0);

    %% Nonrigid registration: phase correlation for each block
    if wantNonrigidEst
      fprintf(' Nonrigid estimation ...');
      corrMap = cell(ntBatch,nb);
      parfor ib = 1:nb

        % Get data blocks
        dataBlock = cellfun(@(x) x(indBlock{ib}), dataBatch,'UniformOutput',0);
    
        % Calculate phase correlation map
        corrMap(:,ib) = calcPhaseCorr(dataBlock, refBlocks{ib}, wrb, wBlock{ib});
    
      end
      clear dataBatch dataBlock
    
      %% Calculate enhanced correlation map <ccsm> from <corrMap>
    
      % Get subscripts for a sub block in the center 
      lhalf = maxRegShift + lpad;
    
      % Get subscripts of the central matrix with size of 2*maxshift+1 and convert them to indices
      idxMaxShift = cellfun(@(x,y) (-x:x)+y+1, num2cell(maxRegShift),num2cell(lhalf),'UniformOutput',0);
      % idxtmp = cellfun(@(x,y) (x+1):(2*y+1-x), num2cell(lpad),num2cell(lhalf),'UniformOutput',0); % Equivalent to the above calculation in this case 
      indMaxShift = sub2ind2(2*lhalf+1,idxMaxShift);
    
       % Get index range along each dimension
      idxHalf = cellfun(@(x,y) (-x:x)+ceil((y+1)/2), num2cell(lhalf),num2cell(blockSize),'UniformOutput',0);
      
      % Get subscripts of the central matrix with size of 2*lhalf+1 and convert them to indices
      indHalf = sub2ind2(blockSize,idxHalf);
    
      % Get sub-blocks
      cc1 = cellfun(@(x) x(indHalf(:)), corrMap,'UniformOutput',0);
      clear corrMap
    
      % Rearrange the matrix to make the block dimension the first
      cc1 = reshape(catcell(2,cc1.').',nb,[]);
    
      % Gaussian enhancement
      cc3 = {cc1, R*cc1, R2*cc1}; 
      clear cc1
    
      % Reshape
      cc3 = cellfun(@(x) reshape(x,nb,ntBatch,[]), cc3,'UniformOutput',0);
      
      % Get enhanced ccsm based on block cc SNR
      ccsm = cc3{1};
      for ib = 1:nb
        snr = ones(ntBatch,1);
    
        for jj = 1:length(cc3)
          ism = snr < snrThresh;
          nt0 = sum(ism(:));
    
          if nt0==0
            break
          end
          cc = shiftdim(cc3{jj}(ib,:,:),1);
          cc = cc(ism,:);
    
          if jj > 1
            ccsm(ib,ism,:) = cc;
          end
          
          % Get subscripts of the maximum cc point
          [ccmax,idx] = max(cc(:,indMaxShift(:)),[],2); 
          submax = ind2sub2(2*maxRegShift+1,idx);
    
          % Set 0 to all points +-lpad from max point
          for ii = 1:nt0
            % Get subscripts of the matrix centered at maximum cc point and convert them to indices
            idxPad = cellfun(@(x,y) x(ii)+(0:2*y), submax,num2cell(lpad),'UniformOutput',0);
            indPad = sub2ind2(2*lhalf+1,idxPad);
           
            cc(ii,indPad(:)) = 0;
          end
          
          % Calculate SNR of the correlation matrix
          snr(ism) = ccmax ./ max(eps,max(cc,[],2));
          % figure; plot(snr)
          
        end
      end
      clear cc3
    
      %% Calculate pixel/voxel shifts
      
      % Init
      cmaxb = zeros(ntBatch,nb0);
      ssb = zeros(ntBatch,nb0,ndim-1);
    
      % Get sub-blocks with size (2*maxshift+1) and get the index of maximum 
      [cmaxb(:,indValid),idx] = cellfun(@(x) max(x(indMaxShift(:))), num2cell(permute(ccsm,[2,1,3]),3));
      submax = ind2sub2(2*maxRegShift+1,idx);
    
      % Get voxel shifts
      ssb(:,indValid,:) = catcell(3,cellfun(@(x,y) x-y-1, submax, num2cell(maxRegShift),'UniformOutput',0)); % Get shift number;
    
      
      %% Kriging interpolation (subpixel estimation)
      if wantSubPixelEst
        fprintf('Sub-pixel estimation ...');
        % Upsampling kernel (Kriging)
        lpadUp = lpad.*subpixel;
        Kmat = upsamplingKernel(lpad,lpad,{1,1}) \ upsamplingKernel(lpad,lpad,{1,1./subpixel});
        
        % Do it
        ssbk = 0*ssb;
        parfor it = 1:ntBatch
          ccmat = zeros([nb,prod(2*lpad+1)]);
          ccsmtmp = squeeze(ccsm(:,it,:));
          for ib = 1:nb
            % Get subscripts of the matrix centered at maximum cc point and convert them to indices
            idxtmp = cellfun(@(x,y) x(it,ib)+(0:2*y), submax,num2cell(lpad),'UniformOutput',0);
            indtmp = sub2ind2(2*lhalf+1,idxtmp);
        
            % Get central cc matrix
            ccmat(ib,:) = flatten(ccsmtmp(ib,indtmp));
          end
      
          % Kriging interpolation (subpixel prediction)
          cck = ccmat * Kmat;
          [cmaxb(it,indValid),idx] = max(cck,[],2);
          sub = ind2sub2(2*lpadUp+1,idx);
          ssbk(it,indValid,:) = catcell(2,cellfun(@(x,y,z) (x-y-1)/z, sub, num2cell(lpadUp),num2cell(subpixel),'UniformOutput',0)); % Get shift number; 
        end
        clear ccsm
        
        % Calculate nonrigid shifts
        ssb = ssb + ssbk; % voxel + sub-voxel
        clear ssbk
      
      %     % Plot
      %     tmp2 = zeros([nb0,nup]);
      %     tmp2(indValid,:,:) = reshape(cck,[nb,nup]);
      %     tmp2 = squeeze(num2cell(permute(tmp2,[2,3,1]),[1,2]));
      %     tmp2 = cell2mat(reshape(tmp2,blockdim));
      %     figure;imshow(makeMontage(tmp2,1,0,'xy'),[]);colormap(jet)
      
      end % wantSubPixelEst
    
      %% Upsampling block shift maps <ssb>
      % Upsample blocks of shifts (ssb) into full pixel-wise maps (datasize) for shifting
        
    %     %%% Kriging (Works but slow)
    %     % The function stk_sampling_regulargrid() does the job of creating the grid
    %     BOX = [0*datadim+1;datadim];
    %     BOX(:,BOX(1,:)==BOX(2,:)) = [];
    %     DIM = size(BOX,2);
    %     xt = stk_sampling_regulargrid (datadim, DIM, BOX); % points where value to be interpolated 
    %     %xi = stk_sampling_regulargrid (blockdim, DIM, BOX); % points where we sample
    %     xi = ceil(catcell(2,cblocks)); xi = xi(indValid,:);
    %     
    %     
    %     ssb1up = cell(nt,DIM);
    %     parfor it = 1:nt
    %       tic; fprintf(sprintf('Processing %d/%d ... \n',it,nt))
    %       for id = 1:DIM
    %         % Compute an initial guess for the parameters of the Matern covariance (param0)
    %         model = stk_model (@stk_gausscov_aniso, DIM); % Initialize model
    %         % model = stk_model (@stk_materncov_aniso, DIM);
    %         model.lognoisevariance = 2 * log (1e-4);  % Noise std = 1e-4 (small), "regularization noise"
    %         zi = squeeze(ssb1(it,indValid,id)).';
    %         if sum(zi)==0
    %           ssb1up{it,id} = zeros(datadim);
    %           continue
    %         end
    %         param0 = stk_param_init(model, xi, zi, BOX);
    %     %         SIGMA2 = var (zi);
    %     %         RHO1   = (BOX(2,1) - BOX(1,1)) / 10;
    %     %         RHO2   = (BOX(2,2) - BOX(1,2)) / 10;
    %     %         RHO3   = (BOX(2,3) - BOX(1,3)) / 10;
    %     %         param0 = log ([SIGMA2; 1/RHO1; 1/RHO2; 1/RHO3]);
    %     %         %model.lognoisevariance = 2 * log (1e-5);
    %         model.param = stk_param_estim(model, xi, zi, param0);
    %         % Here, we compute the kriging prediction on each point of the grid
    %         zp = stk_predict(model, xi, zi, xt);
    %         ssb1up{it,id} = reshape(zp.mean,datadim);
    %     
    %       end; toc
    %     end

    fprintf('Upsmapling shift maps ...');
      
      % Here we use for-loop to avoid large memory usage here 
      %if all(blockdim ~= 1)
        % padsize = floor(blockShift/2).*blockShift;
        % datadimPadded = datadim+padsize*2;
        % ssbup = cellfun(@(x) nanreplace(changevolumeres(padarray(reshape(x,blockdim),floor(blockShift/2),'replicate','both'),volsize.*blockShift,datadimPadded)),squeeze(num2cell(ssb,2)),'uniformoutput',0);

        % % Remove padded elements
        % idxData = cellfun(@(x,y) (x+1):(y-x), num2cell(padsize),num2cell(datadimPadded),'UniformOutput',0); % Equivalent to the above calculation in this case 
        % indData = sub2ind2(datadimPadded,idxData);
        % ssbup = cellfun(@(x) x(indData), ssbup,'uniformoutput',0);

        ssbup = cell(ntBatch*(ndim-1),1);
        ssbtmp = reshape(permute(ssb,[2 1 3]),nb0,[]);
        parfor ii = 1:size(ssbtmp,2)
          ssbup{ii} = nanreplace(changevolumeres(reshape(ssbtmp(:,ii),blockdim),volsize.*blockShift,datadim));
        end
 
      % else
      %   tmp = ones(1,ndim-1);
      %   tmp(blockdim==1) = datadim(blockdim==1);
      %   ssbup = cellfun(@(x) repmat(reshape(x,blockdim),tmp),squeeze(num2cell(ssb,2)),'uniformoutput',0);
      % end

      % Change it to matrix
      ssbup = reshape(catcell(ndim,ssbup),[datadim,ntBatch,ndim-1]);

      

    end % wantNonrigidEst
    fprintf('done!\n');

    %% Correct data
    if ~skipCorrection
      fprintf(' Correct data ...');
      % Correct original data <dataBatch0>. Note that as we only perform pixel
      % estimation and shift data, no interpolation-induced blurring occur.
      dataBatch0 = cellfun(@(x,y) circshift(x,-y), dataBatch0,num2cell(ss,2),'UniformOutput',0);
      if wantNonrigidEst
        [dataBatch0,~,validvol] = undistortvolumes2(catcell(ndim,dataBatch0),volsize,ssbup,1:ndim-1,[]);
        %save_nii(make_nii(newvols, volsize),'epiCorrected.nii');
        dataBatch0 = squeeze(num2cell(dataBatch0,1:ndim-1));
      end
      fprintf('done! \n');
    end
  
    %% Combine results from batch processing
    rigidEstTmp = cat(1,rigidEstTmp, cat(2,ss,cmax));
    if wantNonrigidEst
      nonrigidEstTmp = cat(1,nonrigidEstTmp, cat(3,ssb,cmaxb));
      nonrigidMapTmp = cat(ndim,nonrigidMapTmp, ssbup);
    end
    % dataAvg = dataAvg + sum(dataBatch0,ndim)/nt;
    if ~skipCorrection
      datatmp(k:min(k+batchSize-1,nt)) = dataBatch0;
    end
  
  end % Batch processing

  %% Update corrected data and parameters
  data{id} = catcell(ndim, datatmp);
  rigidEst{id} = rigidEstTmp;
  nonrigidEst{id} = nonrigidEstTmp;

  % For the voxel shift map, we add both rigid and nonrigid shift
  if wantNonrigidEst
    nonrigidMap{id} = nonrigidMapTmp + shiftdim(repmat(rigidEstTmp(:,1:ndim-1),[1,1,datadim]),2);
    %nonrigidMap{id} = nonrigidMapTmp;
  end

  %% Plot 
  if wantfigs && wantNonrigidEst
    % [~,ccIdx] = sort(rigidEstTmp(:,4),'ascend'); 
    % 
    % itSelect = ccIdx(1);
    % 
    % %% Plot shift maps (ssb)
    % 
    % [ssb1,imgdim] = cellfun(@(x) makeMontage(reshape(x,blockdim),1,0,'xy') ,num2cell(squeeze(nonrigidEstTmp(itSelect,:,1:ndim-1)),1),'uniformoutput',0);
    % [X,Y] = ndgrid(size(ssb1{1},1):-1:1,1:size(ssb1{1},2));
    % 
    % p1 = [Y(:),X(:)];
    % dp = [ssb1{1}(:),ssb1{2}(:)];
    % m = abs(ssb1{2}+1i*ssb1{1});
    % % figure;imshow(m,[]); colormap(jet)
    % 
    % % Plot
    % figName = 'voxelShiftPlot';
    % afigure(aconfig('FontSize',8,'Width',1600,'Height',650,'Colormap',brewermap(256,"-Spectral") ,'Name',figName,'Visible','off')); 
    % fig = gcf;
    % ax1 = axes('Parent',fig); set(ax1,'Visible','off'); % Background axes
    % imshow(makeMontage(refImg,1,0,'xy'),[],'Parent',ax1,'InitialMagnification','fit');
    % ax2 = axes('Parent',fig); set(ax2,'Visible','off'); % Main image axes
    % 
    % % q = quiver(Y,X,ssb11{2},ssb11{1},'LineWidth',2); axis image; axis off
    % hold on; daspect([max(p1(:)),max(p1(:)),ones(1,3-ndims(Y))]);
    % %hold on; daspect([1,1,1]);
    % scale = 0.01/(prctile(m(m~=0),99)/norm(max(p1))); % It seems 0.01 is a good ratio between arrow length and axis limit
    % ww = 0.4*m(:)/max(m(:));
    % arrow3(p1, p1+scale*(dp+eps), '|1.2', ww, 1.2*ww); hold off; 
    % hc = colorbar; set(hc,'YTickLabel',num2str(str2double(get(hc,'YTickLabel'))/scale));
    % axis image; axis off
    % 
    % % Link axes
    % linkprop([ax2,ax1], 'position'); % Link ax2 position to ax1
    % 
    % % Draw slice borders
    % vslice = (1:(size(ssb1{1},2)/imgdim{1}(2)-1))*imgdim{1}(2) + 0.5;
    % hslice = (1:(size(ssb1{1},1)/imgdim{1}(1)-1))*imgdim{1}(1) + 0.5;
    % h1 = straightline(hslice,'h','w-'); set(h1, 'LineWidth', 2)
    % h2 = straightline(vslice,'v','w-'); set(h2, 'LineWidth', 2)
    % 
    % figurewrite(figName,[],[],intermPath{id});
    % 
    % %% Plot interpolated shift maps (ssbup)
    % ssbupTmp = squeeze(num2cell(nonrigidMapTmp,1:ndim-1));
    % [ssbup1,imgdim] = cellfun(@(x) makeMontage(x.*refMask,1,0,'xy') ,squeeze(ssbupTmp(itSelect,:)),'uniformoutput',0);
    % [X,Y] = ndgrid(size(ssbup1{1},1):-1:1,1:size(ssbup1{1},2));
    % 
    % dispSpacing = 4; % For better visualization, use a larger spacing.
    % xRange = 1:dispSpacing:size(X,1);
    % yRange = 1:dispSpacing:size(X,2);
    % X = X(xRange,yRange);
    % Y = Y(xRange,yRange);
    % ssbup1 = cellfun(@(x) x(xRange,yRange), ssbup1, 'uniformoutput',0);
    % p1 = [Y(:),X(:)];
    % dp = [ssbup1{1}(:),ssbup1{2}(:)];
    % m = abs(ssbup1{2}+1i*ssbup1{1});
    % % figure;imshow(m,[]); colormap(jet)
    % 
    % % Plot
    % figName = 'voxelShiftInterpPlot';
    % afigure(aconfig('FontSize',8,'Width',1600,'Height',650,'Colormap',brewermap(256,"-Spectral") ,'Name',figName,'Visible','off')); 
    % 
    % fig = gcf;
    % ax1 = axes('Parent',fig); set(ax1,'Visible','off'); % Background axes
    % imshow(makeMontage(refImg,1,0,'xy'),[],'Parent',ax1,'InitialMagnification','fit');
    % ax2 = axes('Parent',fig); set(ax2,'Visible','off'); % Main image axes
    % 
    % % q = quiver(Y,X,ssb11{2},ssb11{1},'LineWidth',2); axis image; axis off
    % hold on; daspect([max(p1(:)),max(p1(:)),ones(1,3-ndims(Y))]);
    % scale = 0.01/(prctile(m(m~=0),99)/norm(max(p1))); % It seems 0.01 is a good ratio between arrow length and axis limit
    % ww = 0.4*m(:)/max(m(:));
    % arrow3(p1, p1+scale*(dp+eps), '|1.2', ww, 1.2*ww); hold off; 
    % h = colorbar; set(h,'YTickLabel',num2str(str2double(get(h,'YTickLabel'))/scale));
    % axis image; axis off
    % 
    % linkprop([ax2,ax1], 'position'); % Link ax2 position to ax1
    % 
    % % Draw slice borders
    % vslice = (1:(size(ssbup1{1},2)*dispSpacing/imgdim{1}(2)-1))*imgdim{1}(2) + 0.5;
    % hslice = (1:(size(ssbup1{1},1)*dispSpacing/imgdim{1}(1)-1))*imgdim{1}(1) + 0.5;
    % h1 = straightline(hslice,'h','w-'); set(h1, 'LineWidth', 2)
    % h2 = straightline(vslice,'v','w-'); set(h2, 'LineWidth', 2)
    % 
    % figurewrite(figName,[],[],intermPath{id});

  end


end % Total dataset
fprintf('done.\n');

% prepare output
if isbare
  data = data{1};
  rigidEst = rigidEst{1};
  nonrigidEst = nonrigidEst{1};
  nonrigidMap = nonrigidMap{1};
end


% %% Plot averaged shifts along time for each slice
% 
% ssb1norm = reshape(cellfun(@(x) norm(x(:)) ,num2cell(ssb,3)), nt,[],blockdim(3));
% 
% ssb1normSliceAvg = squeeze(cellfun(@(x) mean(x(x~=0)) ,num2cell(ssb1norm,2)));
% ssb1normSliceStd = squeeze(cellfun(@(x) std(x(x~=0)) ,num2cell(ssb1norm,2)));
% 
% ssb1normAvg = squeeze(cellfun(@(x) mean(x(x~=0)) ,num2cell(ssb1norm,[2,3])));
% ssb1normStd = squeeze(cellfun(@(x) std(x(x~=0)) ,num2cell(ssb1norm,[2,3])));
% 
% % Plot
% afigure(aconfig('FontSize',8,'Width',1600,'Height',250,'LineWidth',1 ,'Name','Voxel shift dynamics')); 
% islice = [4:8];
% [h1,hp] = boundedline(1:nt, ssb1normAvg, ssb1normStd, 'k', ...
%                       1:nt, ssb1normSliceAvg(:,islice), permute(ssb1normSliceStd(:,islice),[1,3,2]),'alpha');
% xlim([0,nt])
% title('Voxel shift dynamics for each slice'); 
% xlabel('Volumes')
% ylabel('Shift (voxels)')
% 
% %% Plot example images with least correlation
% [~,ccIdx] = sort(nonrigidEstTmp(:,:,4));
% 
% 
% img1 = data(:,:,:,ccIdx(1));
% img2 = data(:,:,:,ccIdx(end));
% 
% filename = 'test.gif';
% imwrite(im2uint8(normalizerange(makeMontage(img1,1,0,'xy'),0,1)),filename,'gif','LoopCount',Inf,'DelayTime',0.1);
% imwrite(im2uint8(normalizerange(makeMontage(img2,1,0,'xy'),0,1)),filename,'gif','WriteMode','append','DelayTime',0.1);
% 
% 
% filename = 'test2.gif';
% imwrite(im2uint8(normalizerange(makeMontage(datatmp{ccIdx(1)},1,0,'xy'),0,1)),filename,'gif','LoopCount',Inf,'DelayTime',0.1);
% imwrite(im2uint8(normalizerange(makeMontage(datatmp{ccIdx(end)},1,0,'xy'),0,1)),filename,'gif','WriteMode','append','DelayTime',0.1);


   
%% Bilinear interpolation (2D only, test only)
% yb = unique(cblocks{1});
% xb = unique(cblocks{2});
% iy = interp1(yb,1:numel(yb),1:datadim(1),'linear','extrap');
% ix = interp1(xb,1:numel(xb),1:datadim(2),'linear','extrap');
% 
% [mshx,mshy] = meshgrid(ix,iy);
% 
% ymax1 = reshape(ssb1(:,:,1),[nt,blockdim]);
% xmax1 = reshape(ssb1(:,:,2),[nt,blockdim]);
% 
% yup = zeros([nt,datadim]);
% xup = yup;
% 
% 
% for t = 1:nt
%   for islice = 1:12
%     ymax1tmp = squeeze(ymax1(t,:,:,islice));
%     xmax1tmp = squeeze(xmax1(t,:,:,islice));
% 
%     yup(t,:,:,islice) = map_coordinate(ymax1tmp,mshy,mshx);
%     xup(t,:,:,islice) = map_coordinate(xmax1tmp,mshy,mshx);
% 
%   end
% end
% 
% 
% % Use shifts and do bilinear interpolation
% [mshx,mshy] = meshgrid(1:datadim(2),1:datadim(1));
% 
% 
% dataNew = zeros([datadim,nt]);
% 
% for t = 1:nt
%   for islice = 1:12
%     dataNew(:,:,islice,t) = map_coordinate(data(:,:,islice,t),mshy+squeeze(yup(t,:,:,islice)),mshx+squeeze(xup(t,:,:,islice)));
%   end
% end
% 
% niinew = nii;
% niinew.img = double(dataNew);
% save_nii(niinew,'epiCorrected.nii');





















