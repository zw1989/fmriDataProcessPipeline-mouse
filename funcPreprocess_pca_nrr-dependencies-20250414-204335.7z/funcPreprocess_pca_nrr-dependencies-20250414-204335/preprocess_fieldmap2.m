% Script for fieldmap processing.
% Usage:
% function [finalfieldmaps] = preprocess_fieldmap2(fieldmapIntermPath, ...
%     fieldmapData, fieldmapbrains, fieldmapsizes, fieldmapdeltate, ...
%     fieldmapunwrapOpt, fieldmapsmoothfwhm, nepis, epidim, episizes, epifieldmapasst, ...
%     fieldmaptimeinterp)
%
% Inputs:
% <fieldmapIntermPath> is the directory or a one-level cell vector of directories to write
%   figures and results to. [] or {} means do not write figures and results.
% <fieldmapData> is a 4D phase values with the fourth dimention representing
%   at least two different echo times or a single, real 3D fieldmap image
%   showing the field inhomogeneity in each voxel. It can also be a cell vector  
%   of such volumes or {A B} where A is a cell vector of one or more such
%   volumes and B is a vector of time values to associate with the volumes. 
%   if B is omitted or given as [], we default to 1:N where N is the number of
%   volumes supplied.  <fieldmapData> can be {}, which indicates that no 
%   undistortion is to be applied. If it is the 3D fieldmap image, the
%   fieldmap unwrapping is skipped. 
% <fieldmapbrains> is a 3D volume of magnitude brains or a cell vector
%   of such volumes.  can be {}.  should mirror <fieldmapData>.
% <fieldmapsizes> is a 3-element vector with the voxel size in mm
%   or a cell vector of such vectors.  can be {}.  should mirror <fieldmaps>.
%   if a single vector, we automatically repeat that vector for multiple
%   <fieldmaps>.
% <fieldmapdeltate> is the difference in TE that was used for the fieldmap
%   or a vector of such differences.  should be in seconds.  can be [].
%   should mirror <fieldmaps>.  if a single value, we automatically repeat that 
%   value for multiple <fieldmaps>.
% <fieldmapunwrapOpt> is whether to attempt to unwrap the fieldmap.  can be:
%   (1) 0 means no.
%   (2) 1 means yes and use the '-s -t 0' flags in prelude.
%   (3) a string with the specific flags to use (e.g. '', '-f').
%   can be a cell vector of things like (1)-(3).  should mirror <fieldmaps>.  
%   if a single element, we automatically repeat that element for multiple <fieldmaps>.
% <fieldmapsmoothfwhm> is a 3-element vector with the size of the
%   bandwidth in mm to use in the local linear regression or a cell vector
%   of such vectors.  can be {}.  should mirror <fieldmaps>.  if a single vector, we 
%   automatically repeat that vector for multiple <fieldmaps>.  the bandwidth 
%   along each dimension must be greater than the voxel size of the fieldmap 
%   along that dimension (this is because we need more than one data point along each 
%   dimension in order to perform local linear regression).  also, bandwidths
%   can be Inf (this results in pure linear regression along the corresponding 
%   dimension).  also, instead of a 3-element vector, you can supply NaN 
%   which means to omit smoothing.  for details on the meaning of the bandwidth,
%   see localregression3d.m, but here is an example: if <fieldmapsmoothing> is
%   [7.5 7.5 7.5], this means that the smoothing kernel should fall to 0 when
%   you are 7.5 mm away from the center point.  finally, a special case is
%   to specify [X Y Z 1] which means to impose extra regularization of the fieldmap
%   values towards 0 (for regions of the fieldmap with very low magnitude values).
% <epidim> is a 3-element or 4-element vector indicating the epi matrix
%   size. if it has 3 elements, the forth element, i.e. the number of volumes
%   is 1.
% <episize> is a 3-element or 4-element vector with the first 3 the voxel
% size in mm and the fourth element the epitr in seconds.
% <epifieldmapasst> indicates which fieldmaps to apply to which EPI runs.  
%   matters only if fieldmap(s) are provided.  if NaN, that means do not 
%   apply any fieldmaps to any run.  should be a cell vector of the 
%   same length as <epis>.  each element should either be a non-negative
%   integer or a sorted two-element vector [G H].  for a given element, if 
%   it is a positive integer, that indicates the index of the fieldmap to use; 
%   if it is 0, that indicates do not apply a fieldmap for that EPI run; if
%   it is a two-element vector, that indicates to interpolate from time value
%   G to time value H in order to figure out the fieldmap values to use
%   for that EPI run (in this case, each volume within the run gets a different
%   fieldmap correction).  if you pass in a vector of non-negative integers,
%   we automatically convert that to a cell vector.  there are some special
%   cases for your convenience.  if <epifieldmapasst> is passed in as [], 
%   that means (1) if there is one fieldmap then apply that fieldmap to all 
%   EPI runs, (2) if there are as many fieldmaps as EPI runs then apply fieldmaps
%   1-to-1 to the EPI runs, (3) if there is one more fieldmap than EPI runs, then
%   interpolate between each successive fieldmap to obtain the fieldmap to use
%   for each EPI run, and (4) otherwise, give an error.
% <nepis> (optional) is the epi data number, and can be []. If [], nepis =
%   length(fieldmaps) 
% <fieldmaptimeinterp> (optional) is 'linear' or 'cubic' indicating the type of
%   interpolation to use for the [G H] cases in <epifieldmapasst>.  note that
%   to perform interpolation, we use the interp1.m function and in particular we 
%   use 'extrap' (thus, it is possible to use values for G and H that are outside 
%   the range of the original fieldmap time values).  default: 'cubic'.
%
% Output:
% <finalfieldmaps> is a cell array of preprocessed 3D fieldmaps for each
% epi run.


function [finalfieldmaps] = preprocess_fieldmap2(fieldmapIntermPath, ...
    fieldmapData, fieldmapbrains, fieldmapsizes, fieldmapdeltate, ...
    fieldmapunwrapOpt, fieldmapsmoothfwhm, epidim, episize, nepis, ...
    epifieldmapasst, fieldmaptimeinterp)

% Internal Setup
fmapdiffrng = [-50 50];  % range for fieldmap difference volumes

% Input defaults
if ~exist('fieldmaptimeinterp','var') || isempty(fieldmaptimeinterp)
  fieldmaptimeinterp = 'cubic';
end


% make cell if necessary
if ~iscell(fieldmapIntermPath)
  fieldmapIntermPath = {fieldmapIntermPath}; 
end
if ~iscell(fieldmapData)
  fieldmapData = {fieldmapData};  % now, it is either {vol}, {vol1 vol2 vol3...}, {A B}, or {}
end
if ~iscell(fieldmapbrains)
  fieldmapbrains = {fieldmapbrains};
end
if ~iscell(fieldmapsizes)
  fieldmapsizes = {fieldmapsizes};
end
if ~iscell(fieldmapsmoothfwhm)
  fieldmapsmoothfwhm = {fieldmapsmoothfwhm};
end
if ~isempty(fieldmapData)  % disregard the {} case...
  if ~iscell(fieldmapData{1})
    fieldmapData = {fieldmapData};  % now, everything is {A B}, but B could be omitted or []
  end
  if length(fieldmapData) < 2
    fieldmapData{2} = [];  % insert B if necessary
  end
  if isempty(fieldmapData{2})
    fieldmapData{2} = 1:length(fieldmapData{1});  % handle [] case for B
  end
  fieldmaptimes = fieldmapData{2};  % split off B part into <fieldmaptimes>
  fieldmapData = fieldmapData{1};      % <fieldmaps> is now just the A part
  % ok, now, it is the case that either:
  % (1) fieldmaps is {} (which is the no undistortion case) and fieldmaptimes is not defined
  % (2) fieldmaps is A (cell vector of fieldmaps) and fieldmaptimes is fully specified
end

% Calc flags
wantfigs = ~isempty(fieldmapIntermPath{1});
wantundistort = ~isempty(fieldmapData);

% If don't want to undistort epis, stop and return finalfieldmaps empty
if ~wantundistort
    finalfieldmaps = {};
    fprintf('No fieldmap is processed. \n');
    return
end

fprintf('Preprocessing fieldmaps... \n');

% fieldmap number
nfieldmap = length(fieldmapData);

% automatically repeat
if length(fieldmapsizes)==1
  fieldmapsizes = repmat(fieldmapsizes,[1 nfieldmap]);
end
if length(fieldmapdeltate)==1
  fieldmapdeltate = repmat(fieldmapdeltate,[1 nfieldmap]);
end
if (isnumeric(fieldmapunwrapOpt) && length(fieldmapunwrapOpt)==1) || ischar(fieldmapunwrapOpt)
  fieldmapunwrapOpt = repmat({fieldmapunwrapOpt},[1 nfieldmap]);
end
if length(fieldmapsmoothfwhm)==1
  fieldmapsmoothfwhm = repmat(fieldmapsmoothfwhm,[1 nfieldmap]);
end

% convert fieldmapunwrapOpt for prelude
for p=1:length(fieldmapunwrapOpt)
  if size(fieldmapData{p},4) == 1 % If it is the fieldmap image, unwrapping will be skipped.
      fieldmapunwrapOpt{p} = 0;
  end

  switch fieldmapunwrapOpt{p}
  case 1
      % '-s' means run in slice, which is about 30 times faster than the 3D
      % mode. '-t 0' means set image intensity threshold to 0; if not set,
      % prelude will generate a mask based on the 98% intensity range
      fieldmapunwrapOpt{p} = ''; % Default value in prelude
      %fieldmapunwrapOpt{p} = '-s -t 0'; 
  end
end

% deal with massaging epifieldmapasst [after this, epifieldmapasst will either be NaN or a fully specified cell vector]
if ~exist('nepis','var') || isempty(nepis)
  nepis = nfieldmap;
end
if ~exist('epifieldmapasst','var') || isempty(epifieldmapasst)
    if nfieldmap == 1  % if one fieldmap, use it for all
      epifieldmapasst = ones(1,nepis);
    elseif nfieldmap == nepis  % if equal number, assign 1-to-1
      epifieldmapasst = 1:nfieldmap;
    elseif nfieldmap == nepis+1  % if one more fieldmap, then interpolate between successive
      epifieldmapasst = splitmatrix(flatten([1:nfieldmap-1; 2:nfieldmap]),2,2*ones(1,nepis));
    else
      error('<epifieldmapasst> cannot be [] when the number of fieldmaps is not one NOR the same as the number of EPI runs NOR the same as the number of EPI runs plus one');
    end
end
if ~iscell(epifieldmapasst) && ~isequalwithequalnans(epifieldmapasst,NaN)
    epifieldmapasst = num2cell(epifieldmapasst);
end
assert(isequalwithequalnans(epifieldmapasst,NaN) || (length(epifieldmapasst)==nepis));

% Deal with episize
if length(epidim) == 3
    epidim(4) = 1;
end
if length(episize) == 3
    episize(4) = 1; % epitr = 1s
end


% fieldmap scaling factor, the bandwidth of the deviated frequency
fmapsc = 1./fieldmapdeltate/2; % Vector of values like 250 (meaning +/- 250Hz)

% make intermediate figure and result dir
if wantfigs
  cellfun(@mkdirquiet, fieldmapIntermPath); 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DO IT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Write out fieldmap inspections
if wantfigs
    fprintf('writing out fieldmap inspections...');
    
    % Write out fieldmaps, fieldmapbrains, and histogram of fieldmap
    parfor p=1:nfieldmap
        
        if size(fieldmapData{p},4)>1
            fieldmapraw = mean(circulardiff(fieldmapData{p}(:,:,:,2:end), fieldmapData{p}(:,:,:,1:end-1), 2*pi)/pi*fmapsc(p),4); % in Hz
        else
            fieldmapraw = fieldmapData{p}/pi*fmapsc(p);
        end

        % write out fieldmap
        imwrite(uint8(255*makeimagestack(fieldmapraw,[-1 1]*fmapsc(p))),jet(256),fullfile(fieldmapIntermPath{p},'fieldmapraw.png'));
        save_nii(make_nii(fieldmapraw, fieldmapsizes{p},[],16),fullfile(fieldmapIntermPath{p},'fieldmapraw.nii'));

        % write out fieldmap brain and save file
        imwrite(uint8(255*makeimagestack(fieldmapbrains{p},1)), gray(256), fullfile(fieldmapIntermPath{p},'fieldmapbrain.png'));
        save_nii(make_nii(fieldmapbrains{p}, fieldmapsizes{p},[],16),fullfile(fieldmapIntermPath{p},'fieldmapbrain.nii'));

%         % write out fieldmap brain cropped to EPI FOV
%         imwrite(uint8(255*makeimagestack(processmulti(@imresizedifferentfov,fieldmapbrains{p},fieldmapsizes{p}(1:2), ...
%           epidim(1:2),episize(1:2)),1)),gray(256),sprintf('%s/fieldmapbraincropped%02d.png',figuredir,p));

        % write out fieldmap histogram        
        figureprep; hold on;
        vals = prctile(fieldmapraw,[25 75]);
        hist(fieldmapraw,100);
        straightline(vals,'v','r-');
        xlabel('Fieldmap value (Hz)'); ylabel('Frequency');
        title(sprintf('Histogram of raw fieldmap; 25th and 75th percentile are %.1f Hz and %.1f Hz',vals(1),vals(2)));
        figurewrite('fieldmaphistogram%02d',[],[],fieldmapIntermPath{p});
  
    end
    fprintf('done.\n'); reportmemoryandtime;
 
end


% Unwrap fieldmaps
fieldmapunwrapped = cell(1,nfieldmap);
fprintf('unwrapping fieldmaps ... \n');
parfor p = 1:nfieldmap

    if ~isequal(fieldmapunwrapOpt{p},0)
        
        %%%%%%%%%%%% Unwrap the raw fieldmaps directly which could lead to problems ??? %%%%%%%
        % get temporary filenames
        tmp1 = tempname; tmp2 = tempname; %tmp3 = tempname;
        
        % make a complex fieldmap and save to tmp1
        save_nii(make_nii(repmat(fieldmapbrains{p},1,1,1,size(fieldmapData{p},4)).*exp(1i*fieldmapData{p}), fieldmapsizes{p},[],32),tmp1);
        %save_nii(make_nii(fieldmapmasks{p}, fieldmapsizes{p},[],2),tmp3);
        
        % use prelude to unwrap, saving to tmp2
        unix_wrapper(sprintf('prelude -c %s -o %s %s; gunzip %s.nii.gz',tmp1,tmp2,fieldmapunwrapOpt{p},tmp2),0);
        %unix_wrapper(sprintf('prelude -c %s -o %s -m %s %s; gunzip %s.nii.gz', tmp1, tmp2, tmp3, '-s -t 0', tmp2)); % if you have a mask 
        %unix_wrapper(sprintf('prelude -c %s -o %s %s; gunzip %s.nii.gz', tmp1, tmp2, '', tmp2)); % Let prelude generate a mask for calculation
        
        % load in the unwrapped phase images
        temp = load_nii(sprintf('%s.nii', tmp2));
        temp.img = double(flip(temp.img,1)); % Note prelude flips the first image dimension and now flip back

        % convert from radians centered on 0 to actual Hz, this is the B0
        % map!! Here we also take the average if multiple maps are acquired
        fieldmapunwrapped{p} = circulardiff(temp.img(:,:,:,2:end), temp.img(:,:,:,1:end-1), 2*pi)/pi*fmapsc(p);
        fieldmapunwrapped{p} = mean(fieldmapunwrapped{p},4);
    else

        % convert from [-pi,pi] to actual Hz
        fieldmapunwrapped{p} = fieldmapData{p}/pi*fmapsc(p);

    end

    %figure; imshow(makeMontage(fieldmapunwrapped,0,0,'xy'),[]); truesize([400,800])

end
fprintf('done.\n'); reportmemoryandtime;


% write out inspections of the unwrapping and additional fieldmap inspections
if wantfigs
  fprintf('writing out inspections of the unwrapping and additional inspections...');
  
  % write inspections of unwraps
  for p=1:nfieldmap
    imwrite(uint8(255*makeimagestack(fieldmapunwrapped{p},[-1 1]*fmapsc(p))),jet(256),fullfile(fieldmapIntermPath{p},'fieldmapunwrapped.png'));
    save_nii(make_nii(fieldmapunwrapped{p}, fieldmapsizes{p},[],16),fullfile(fieldmapIntermPath{p},'fieldmapunwrapped.nii'));
  end

  % write slice-mean inspections
    % this is fieldmaps x slice-mean with the (weighted) mean of each slice in the fieldmaps:
  fmapdcs = catcell(1,cellfun(@(x,y) sum(squish(x.*abs(y),2),1) ./ sum(squish(abs(y),2),1),fieldmapunwrapped,fieldmapbrains,'UniformOutput',0));
  figureprep; hold all;
  set(gca,'ColorOrder',jet(nfieldmap));
  h = plot(fmapdcs');
  legend(h,mat2cellstr(1:nfieldmap),'Location','NorthEastOutside');
  xlabel('Slice number'); ylabel('Weighted mean fieldmap value (Hz)');
  title('Inspection of fieldmap slice means');
  figurewrite('fieldmapslicemean',[],[],fieldmapIntermPath{p});

  fprintf('done.\n'); reportmemoryandtime;
end

%% Fieldmap processing (smoothing) 

% use local linear regression to smooth the fieldmaps
fieldmapsmoothed = cell(1,nfieldmap);
fprintf('Smooth the fieldmaps ...')
parfor p = 1:nfieldmap % Parfor
    
    if isnan(fieldmapsmoothfwhm{p})
        fieldmapsmoothed{p} = processmulti(@imresizedifferentfov,fieldmapunwrapped{p},fieldmapsizes{p}(1:2),epidim(1:2),episize(1:2));
    else
        fsz = sizefull(fieldmapData{p},3);
        [xx,yy,zz] = ndgrid(1:fsz(1),1:fsz(2),1:fsz(3));
        [xi,yi] = calcpositiondifferentfov(fsz(1:2),fieldmapsizes{p}(1:2),epidim(1:2),episize(1:2));
        [xxB,yyB,zzB] = ndgrid(yi,xi,1:fsz(3));
        
        if length(fieldmapsmoothfwhm{p}) > 3 && fieldmapsmoothfwhm{p}(4)

            % Generate a mask based on the intensity threshold
            mask = automask(fieldmapbrains{p},0.15);
            
%             % regularize the fieldmap values based on intensity of the magnitude component (below a threshold, we rapidly bias towards 0)
%             t0 = prctile(fieldmapbrains{p}(:),99.9)*0.1;
%             mask = fieldmapbrains{p};
%             mask(mask > t0) = t0;
%             mask = (mask / t0) .^ 2;  % at this point, the mask is a squaring function from 0 to 1 and then always 1 after that
            
            % Write out fieldmapmask for inspection
            imwrite(uint8(255*makeimagestack(mask,[0,1])), gray(256), fullfile(fieldmapIntermPath{p},'fieldmapmask.png'));

            % Write out inspections of the masked unwrapped fieldmap
            imwrite(uint8(255*makeimagestack(fieldmapunwrapped{p}.*mask,[-1 1]*fmapsc(p))), jet(256), fullfile(fieldmapIntermPath{p},'fieldmapunwrappedmasked.png'));   
        else
            mask = 1;
        end

        % Proceed to smoothing
        fieldmapsmoothed{p} = nanreplace(localregression3d(xx,yy,zz,fieldmapunwrapped{p}.*mask, ...
                xxB,yyB,zzB,[],[],fieldmapsmoothfwhm{p}(1:3)./fieldmapsizes{p}, fieldmapbrains{p},1),0,3);

        % Write out figures for inspection and save smoothed masked fieldmap files
        imwrite(uint8(255*makeimagestack(fieldmapsmoothed{p},[-1 1]*fmapsc(p))), jet(256), fullfile(fieldmapIntermPath{p},['fieldmapsmoothed.png']));
    
    end
end

% Clean up
clear mask
fprintf('done. \n'); reportmemoryandtime;


%% Deal with epifieldmapasst

finalfieldmaps = cell(1,nepis);  % we need this to exist in all epi cases

fprintf('deal with epi fieldmap assignment and time interpolation...');

% calculate the final fieldmaps [we use single to save on memory]
if ~isequalwithequalnans(epifieldmapasst,NaN)
    for p=1:length(epifieldmapasst)
      if epifieldmapasst{p} ~= 0
        fn = epifieldmapasst{p};

        % if scalar, just use as-is, resulting in X x Y x Z
        if isscalar(fn)
          finalfieldmaps{p} = single(fieldmapsmoothed{fn});

        % if two-element vector, do the interpolation, resulting in X x Y x Z x T     [[OUCH. THIS DOUBLES THE MEMORY USAGE]]
        else
          finalfieldmaps{p} = single(permute(interp1(fieldmaptimes,permute(catcell(4,fieldmapsmoothed),[4 1 2 3]), ...
                                                     linspace(fn(1),fn(2),epidim(4)),fieldmaptimeinterp,'extrap'),[2 3 4 1]));
        end

      end
      
      % Save the final fieldmaps for further usage
      save_nii(make_nii(finalfieldmaps{p}, fieldmapsizes{p},[],16),fullfile(fieldmapIntermPath{p},'finalfieldmap.nii'));

    end
end

fprintf('done.\n'); reportmemoryandtime;
    



