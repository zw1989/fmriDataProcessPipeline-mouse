function f = constructdctmatrix2(n,ks)

% function f = constructdctmatrix(n,ks)
%
% <n> is the number of points
% <ks> is a vector of nonnegative integers (in the range [0,<n>-1])
%
% return a matrix of dimensions <n> x length(<ks>)
% with DCT-II basis functions in the columns. 
%
% example:
% figure; imagesc(constructdctmatrix(100,0:3));

% NOTE: this is hard edged.  sinc in the space domain?  use a butter filter?
%    use polynomials instead?
%
%
% 20200619--Add coefficient sqrt(1/n) for the first and sqrt(2/n) for all
% other terms to make it orthorgonal. 

f = [];
temp = linspacecircular(0,1,n)' + 1/(2*n);
for p=1:length(ks)
    if ks(p) == 0
        f = cat(2,f,sqrt(1/n)*cos(ks(p)*pi*temp));
    else
        f = cat(2,f,sqrt(2/n)*cos(ks(p)*pi*temp));
    end

end
