% This function creates a N-dimensional window for a sample image, it takes
% the dimensions of the window and applies the 1D window function. It is
% simply an extenstion of the function window in matlab.
% 
% Usage: w = windowN(wfunc,winSize)
%
% Inputs: 
% <winSize> is an integer array with the size of a window you created, the
%   length of which is the window dimension. The window can be any dimension.
% <wfunc> is the functional handle the same as the input for window
%   function. For example, if you want to construct a hamming window, set
%   wfunc = @hamming
% <winopt> is the optional input (either numeric or string) for a window
%   function. For example, for wfunc = @gausswin, winopt can be a numeric
%   indicating the width of the gaussin function. The length of winopt
%   should be 1 or mirror the winSize
%
% Output:
% <w> is the constructed multi-dimensional window
% 
% Example1:
% w = windowN(@hamming, [30,40]);
% figure; imagesc(w)
%
% Example2:
% w = windowN({@hamming,@gausswin}, [30,40]);
% figure; imagesc(w)


function w = windowN(wfunc, winSize, winopt,varargin)

% Dimension of the window
ndim = length(winSize);

if ~exist('winopt','var') || isempty(winopt)
  winopt = cell(1,ndim);
end

% Check input
if ~iscell(wfunc)
    wfunc = {wfunc};
end
if length(wfunc)==1
    wfunc = repmat(wfunc,1,ndim); 
end
if ~iscell(winopt)
  if isvector(winopt)
    if length(winopt) ==1
      winopt = repmat(num2cell(winopt),1,ndim);
    else
      winopt = num2cell(winopt);
    end
  else
    winopt = repmat({winopt},1,ndim);
  end
end

% Construct windows along each dimension, the size may vary
wtmp = cellfun(@(x,y,z) window(x,y,z,varargin{:}), wfunc, num2cell(winSize),winopt,'UniformOutput',0);

% Create N-dimensional meshgrid
masktmp = cell(1,ndim);
[masktmp{:}] = ndgrid(wtmp{:}); 

% Final window
w = 1;
for idim = 1:ndim
    w = w.*masktmp{idim};
end

end