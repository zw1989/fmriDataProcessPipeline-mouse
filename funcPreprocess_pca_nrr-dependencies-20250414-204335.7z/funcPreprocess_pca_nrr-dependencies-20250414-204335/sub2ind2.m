


function ind = sub2ind2(sz,sub)

isbare = ~iscell(sub);
if isbare
  sub = num2cell(sub);
end

ndim = length(sub);
subtmp = cell(1,ndim);
[subtmp{:}] = ndgrid(sub{:});
ind = sub2ind(sz,subtmp{:});