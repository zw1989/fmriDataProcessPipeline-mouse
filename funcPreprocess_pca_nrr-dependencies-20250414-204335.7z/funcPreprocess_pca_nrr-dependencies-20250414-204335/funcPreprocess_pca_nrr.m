clear; close all; clc;

%% Data path

projectPath = '/home/ibrain-raid2/weizhu-data/data/9-laminarFmriPipeline-mouse-9T';

% Raw functional data path
rawDataPath = fullfile(projectPath, 'raw-data');

%%%%%%%%%%% Raw func data list
rawFunList = searchAndSortFiles(rawDataPath, ...             % File path
                                 '\d+.nii', ...              % File name pattern, regular expression
                                 {{'type', {{'control',1}, {'mutant',1},{'treated',1}}}, {'sex', {{'M',1}, {'F',1}}},...
                                 {'month', 6}, {'mouse',7},{'run',8}}, ... % Data structure information
                                 1);                         % Functional data indicator
                                                      
% Subject number
subLabelFunc = cellfun(@(x,y,z,k) [x,y,num2str(z),'-m',num2str(k)], {rawFunList.type}, {rawFunList.sex}, {rawFunList.month},{rawFunList.mouse} ,'UniformOutput',0);
subIDfunc = unique(subLabelFunc)';


%%%%%%%%%% Raw fieldmap data list
fieldmapList = searchAndSortFiles(rawDataPath, ...             % File path
                                 'fid', ...              % File name pattern, regular expression
                                 {{'type', {{'control',1}, {'mutant',1},{'treated',1}}}, {'sex', {{'M',2}, {'F',2}}},...
                                 {'month', 6}, {'mouse',7},{'run',8}}, ... % Data structure information
                                 0);  
% Subject number
subLabelFmap = cellfun(@(x,y,z,k) [x,y,num2str(z),'-m',num2str(k)], {fieldmapList.type}, {fieldmapList.sex}, {fieldmapList.month},{fieldmapList.mouse} ,'UniformOutput',0);
subIDfmap = unique(subLabelFmap);

%% We run preprocessfmri for each subject
for isub = 1:length(subIDfunc)

    funcList = rawFunList(contains(subLabelFunc,subIDfunc(isub)));
    fmapList = fieldmapList(contains(subLabelFmap,subIDfunc(isub)));

    % funcList = funcList([1,4]); % for Test
    % fmapList = fmapList([1,4]);

    %% %%%%%%%%%%%%%%%%%%%%%%% Load EPI Data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Load all (?) data to cells where data size can vary. Is this a good and efficient way?
    % Load functional data
    fprintf(sprintf('loading functional data of the %dth subject ... ',isub))
    epifilenames = {funcList.fullPath}; nrun = length(epifilenames);
    epis = cell(1,nrun); episize = [];
    for p=1:nrun
        nii = load_untouch_nii(gunziptemp(epifilenames{p}));
        
        if min(nii.img(:)) < intmin('int16') || max(nii.img(:)) > intmax('int16')
            epis{p} = nii.img/ceil((max(nii.img(:))/double(intmax('int16'))));
        else
            epis{p} = nii.img;     
        end
        
        if funcList(p).month==8 % Orientation correction
            epis{p} = flip(epis{p},2); % Flip the phase, hack   
        end
        
        if contains(funcList(p).imgName, 'treatedM8-m2_run35') % Hack
            epis{p} = epis{p}(:,:,:,1:275); % Gradient failure near the end of the scan
        end
        
        % Some essential parameters
        if p==1
            episize = nii.hdr.dime.pixdim(2:5); % The voxel sizes should be the same and the last parameter tr can vary
            epidim = nii.hdr.dime.dim(2:5);
        end
    end
    
    clear nii
    fprintf('done! \n');
    
    
    %% Load fieldmap data
    
    fprintf(sprintf('Loading fieldmap data and obtain raw fieldmaps (B0 maps) for the %d subject ... ',isub)); 
    fieldmapnames = {fmapList.fullPath};
    nfmap = length(fieldmapnames);
    fieldmapphas = cell(1,nfmap); fieldmapsize = []; 
    fieldmapbrains = cell(1,nfmap); 
    fieldmapdeltate = 0;
    
    for p = 1:nfmap
    % Load fieldmap data
    fid = aedes_readfid(fieldmapnames{p},'return',3, 'DCcorrection','on');
    kspaceImg = fid.KSPACE;    
    
    % Fieldmap volsize, better to be the same as epi. 
    if p==1
        fieldmapsize = [fid.PROCPAR.lro*20/fid.PROCPAR.np, fid.PROCPAR.lpe*10/fid.PROCPAR.nv, fid.PROCPAR.thk]; % in mm
    end
    % Phase ramp the kspace data to correct for phase encode offset ppe.
    % If there is a FOV offset during data acquisition, the kspace data
    % need to be phase shifted to compensate the spatial shift.
    % aedes_readfid doesn't consider this. Refer to the Varian xrecon.
    kPhaseRampFactor = (-2*pi * fid.PROCPAR.ppe/fid.PROCPAR.lpe) * (0:(fid.PROCPAR.nv-1));
    kspaceImgMag = abs(kspaceImg);
    theta = angle(kspaceImg) + repmat(kPhaseRampFactor, size(kspaceImg,1), 1 , size(kspaceImg,3), size(kspaceImg,4));
    kspaceImg = kspaceImgMag .* exp(1i*theta);
    
    %figure; imshow(makeMontage(angle(kspaceImg(:,:,:,2)),2,0,'xy'),[]); truesize([400,800])
    
    te = fid.PROCPAR.te; % TE in s, what is the best TE for field map generation?
    fieldmapdeltate = diff(te,[],2); % Delta TE between te = 0.003s and all the others
    
    % Fourier transform the kspaceData
    fieldmapData = fliplr(fftshift(fft2(ifftshift(kspaceImg)))); % Complex data
    
    % Magnitute image, average of all magnitude image along the 4th
    % dimension. This can be used for brain mask creation for epi, but need
    % to pay attention to the brain displacement (why?? motion?)
    fieldmapbrains{p} = mean(abs(fieldmapData),4);
    
    % Save magnitute images for Mask generation and write out figures for
    % inspection
    % save_nii(make_nii(fieldmapbrains{p}, fieldmapsizes{p},[],64),fullfile(fieldmapIntermPath{p},'fieldmapbrain.nii'));
    % imwrite(uint8(255*makeimagestack(fieldmapbrains{p},1)), gray(256), fullfile(fieldmapIntermPath{p},'fieldmapbrain.png'));
    
    % Phase image (wrapped), if the image is the checkerboard, it indicates the phase is
    % incorrectly shifted.
    fieldmapphas{p} = angle(fieldmapData); % radians
    end
    
    if isempty(fieldmapphas)
        fprintf('No fieldmap data were found! \n');
    else
        fprintf('done! \n'); 
    end
    
    reportmemoryandtime
    %% Prepare inputs ... Pls check the parameters below
    
    %%%%% Paths
    epiIntermPath = cellfun(@(x,y) fullfile(strrep(x,'raw-data',['derivatives-nrr',filesep,'intermediate-data',filesep,'pca']),y), {funcList.dir},{funcList.imgName},'UniformOutput',0);
    cellfun(@mkdirquiet, epiIntermPath); % Target folder
    
    fieldmapIntermPath = cellfun(@(x) fullfile(strrep(x,'raw-data',['derivatives-nrr',filesep,'intermediate-data',filesep,'pca'])), {fmapList.dir},'UniformOutput',0);
    cellfun(@mkdirquiet, fieldmapIntermPath); % Target folder
    
    %%%%% Essential fieldmap inputs
    % should we attempt to unwrap the fieldmaps? (note that 1 defaults to a fast, 2D-based strategy; 
    % see preprocessfmri2.m for details.)  if accuracy is really important to you and the 2D strategy 
    % does not produce good results, consider switching to a full 3D strategy like 
    % fieldmapunwrapOpt = '-f -t 0' (however, execution time may be very long).
    fieldmapunwrapOpt = 1; 
    
    % how much smoothing (in millimeters) along each dimension should we use for the fieldmaps?
    % the optimal amount will depend on what part of the brain you care about.
    % 1.5 or 2 times of the fieldmap resolution is good enough?
    fieldmapsmoothfwhm = 1.5*fieldmapsize; % mm
    
    %%%%% Essential EPI inputs
    % what is the slice order for the EPI runs? Usually 'sequential' or 'interleaved'. 
    % special case is [] which means to omit slice time correction. 
    episliceorder = 'sequential'; 
    
    % what is the phase-encode direction for the EPI runs? (see preprocessfmri2.m for details.)
    epiphasedir = -2; % "-2" means the phase encoding direction is along the 2nd matrix dimention, and from 64->1
    
    % what is the total readout time in milliseconds for an EPI slice?
    % This can be found in the header info or calculated based on echo spacing
    % and phase encoding numbers. For the later case, readout time equals to
    % echo spacing * phase dimension, the recipirical of it is the bandwidth
    % per pixel. If it is read from a header, then check whether epi dimension
    % you set and the output epi dimension matches. If not, zero is padded in
    % the k-space. The readout time read from the header needs to be multiplied
    % by the ratio between the final phase encoding number and the actual phase
    % encoding number you set. If acceleration is used, divide the readout time
    % by the acceleration factor.
    echospacing = 0.568; % ms, from header or scanner
    epireadouttime = echospacing*(epidim(abs(epiphasedir))-1)/1000; % s
    
    %%%%% Optional inputs
    % what fieldmap should be used for each EPI run? ([] indicates default behavior, which is to attempt
    % to match fieldmaps to EPI runs 1-to-1, or if there is only one fieldmap, apply that fieldmap
    % to all EPI runs, or if there is one more fieldmap than EPI runs, interpolate each successive
    % pair of fieldmaps; see preprocessfmri2.m for details.)
    epifieldmapasst = [];
    
    % what kind of time interpolation should we use on the fieldmaps (if applicable)?
    % ([] indicates to use the default, which is cubic interpolation.)
    fieldmaptimeinterp = [];
    
    % how many volumes should we ignore at the beginning of each EPI run 
    numepiignore = 5;
    
    % what volume should we use as reference in motion correction? ([] indicates default behavior which is
    % to use the first volume of the first run; see preprocessfmri2.m for details.  set to NaN if you
    % want to omit motion correction.)
    motionreference = [nrun -1];
    % motionreference = [nrun 0];
    % motionreference = [1 1];
    
    % how much smoothing (in millimeters) along each dimension should we use for the epis?
    % 1.5 or 2 times of the epi resolution is good enough?
    epismoothfwhm = 1.2*episize(1:3); % mm
    
    % Which denoising method should be used? Now either 'gauss' (Gaussian
    % filtering) or 'pca' (RMT-based PCA) is available
    epidenoisemethod = 'pca';
    
    % Which species do you acquire the data on? ['mouse','rat','cat','human'].
    % This is used to determine the brain size which is used to calculate
    % framewise displacement
    species = 'mouse';
    
    % Do you have a tissue mask with the same voxelsize and dimension as EPI
    % and coregistered to EPI?
    tissuemasks = [];
    
    % what extra transformation should we use in the final resampling step? ([]
    % indicates do not perform an extra transformation.) 
    epiVoxelScale = [1.045 1.0216 1]; % Gems image and EPI (ax90) images have different streches along row and column, this is to roughly correct the distortion
    extratrans = diag([epiVoxelScale,1]);
    %extratrans = [];
    
    % what is the desired resolution (number of voxels in each dimension) for
    % the resampled volumes? ([] indicates to just use the original EPI resolution.) 
    targetres = fix(episize(1:3).*epidim(1:3)./[0.1,0.1,0.5]); %mm
    
    % How should we perform temporal filtering? [0.01, 1] means remove
    % freqeuncy components below 0.01Hz, and regress the motions out from the
    % timecourses.
    % tfilterMode = {[0.008,0.1], 1};
    tfilterMode = {0.01, 1};

    wantRemoveOutlier = 1;
    wantGSregress = 0;
    
    % Parameters for non-rigid registration
    blockShift = [4,4,1];
    blockSize = [32,32,1];
    maxRegShift = [3,3,0];

%     blockShift = [3,3,1];
%     blockSize = [27,27,1];
    
    % want slice motion correction?
    want2Dreg = 1;
    
    % Want to rerun some parts of the pipeline? {PA, fieldmap, epipca,
    % reg2dMap, mparams, nonrigidMap} 
    pa = epiIntermPath;
    wantpushalt = {pa, 1, 1, 0, 0, 0};
    % wantpushalt = [];
    
    
    %% func Preprocess starts ...
    % Do it!
    preprocessfmri3(epiIntermPath,fieldmapIntermPath, ...
        fieldmapphas, fieldmapbrains, fieldmapsize, fieldmapdeltate(1), fieldmapunwrapOpt, fieldmapsmoothfwhm,...
        epis, episize, episliceorder, epiphasedir, epireadouttime, ...
        epifieldmapasst, fieldmaptimeinterp, numepiignore, motionreference, ...
        epismoothfwhm, epidenoisemethod, species, tissuemasks, extratrans, targetres,...
        tfilterMode,wantRemoveOutlier,wantGSregress,...
        want2Dreg,blockShift,blockSize,maxRegShift,...
        wantpushalt);


end





% % Get refimage (avg or MIP?) and save it
% testPath = fullfile('/home/ibrain-raid2/weizhu-data/test','epi.tif');
% stackwrite2(single(squeeze(epis{3}(:,:,6,:))),testPath,episize(1:2),0,1);

