% function epis = preprocess_volumedrop2(epiIntermPath, epis, numepiignore, sliceSelection)
% Drop the first (and last) few EPI volumes, and/or select slices for
% analysis
% 
% Inputs:
% <epiIntermPath> is the directory or a one-level cell vector of directories to write
%   figures and results to. [] or {} means do not write figures and results.
% <epis> is a 4D volume or a cell vector of 4D volumes.
%   these volumes should be double format but should be suitable for 
%   interpretation as int16.  there must be at least one EPI run.  
%   the first three dimensions must be consistent across cases.
% <numepiignore> (optional) is a non-negative integer indicating number of volumes
%   at the beginning of the EPI run to ignore or a vector of such integers.  
%   should mirror <epis>.  if a single integer, we automatically repeat that 
%   integer for multiple <epis>.  default: 0.  can also be {[A1 A2] [B1 B2] ... [N1 N2]}
%   where the length of this cell vector is the same as the number of <epis>,
%   and where A1, B1, ..., N1 are non-negative integers indicating number of
%   volumes at the beginning of the EPI runs to ignore, and A2, B2, ..., N2 are
%   non-negative integers indicating number of volumes at the end of the EPI runs
%   to ignore.
% <sliceSelection> (optional) is a non-negative integer array indicating
%   the slices selected or a cell vector of the such array that mirror
%   <epis>. Can be [], meaning select all slices.
%
% TO DO:
% 1. May add image selection to remove area outside of the brain
% 2. May make it more general: crop the data in all dimensions based on
% prior knowledge!
% 3. tsnr display is not optimal for all cases.


function epis = preprocess_volumedrop2(epiIntermPath, epis, numepiignore, sliceSelection)

% make cell if necessary
if ~iscell(epis)
  epis = {epis};
end
nepis = length(epis);

if ~iscell(epiIntermPath)
  epiIntermPath = {epiIntermPath}; 
end
if length(epiIntermPath) == 1
    epiIntermPath = repmat(epiIntermPath,1,nepis);
end

wantfigs = ~isempty(epiIntermPath{1});

% input defaults
if ~exist('numepiignore','var') || isempty(numepiignore)
  numepiignore = 0;
end
if ~exist('sliceSelection','var') || isempty(sliceSelection)
  sliceSelection = 1:size(epis{1},3);
end

% automatically repeat
if length(numepiignore)==1
  numepiignore = [numepiignore,0];
end

% convert to special format
if ~iscell(numepiignore)
  numepiignore = repmat({numepiignore},[1 nepis]);
end
if ~iscell(sliceSelection)
    sliceSelection = num2cell(repmat(sliceSelection, [nepis, 1]),2)';
end

% make intermediate figure and result dir
if wantfigs
  cellfun(@mkdirquiet, epiIntermPath); 
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Do it
fprintf('--> dropping EPI volumes ...');

epis = cellfun(@(x,y,z) double(x(:,:,y,z(1)+1:end-z(2))), epis, sliceSelection, numepiignore, 'UniformOutput',0);

fprintf('done.\n');


if wantfigs
    fprintf('writing out epi volumes and their tSNRs for inspection...');
    
    % inspect first and last of each run
    cellfun(@(x,y) viewmovie(x(:,:,:,1), fullfile(y,'epiRaw-1'),1),epis, epiIntermPath,'UniformOutput',0); 
    cellfun(@(x,y) viewmovie(x(:,:,:,end), fullfile(y,'epiRaw-end'),1),epis, epiIntermPath,'UniformOutput',0);
    %cellfun(@(x,y) viewmovie(x(:,:,:,1:end), {fullfile(y,'epiRaw-1'),60}),epis, epiIntermPath,'UniformOutput',0); % make moive

    % Compute temporal SNR of raw data
      % this is a cell vector of 3D volumes.  values are percentages representing the median frame-to-frame difference
      % in units of percent signal.  (if the mean intensity is negative, the percent signal doesn't make sense, so
      % we set the final result to NaN.)  [if not enough volumes, some warnings will be reported.]
    temporalsnr = cellfun(@computetemporalsnr,epis,'UniformOutput',0);

    % Write out temporal SNR for each run
    tsnrmx = 5;
    % tsnrmx = median(temporalsnr{1}(:)); % max temporal SNR percentage (used in determining the color range)
    cellfun(@(x,y) imwrite(uint8(255*makeimagestack(tsnrmx-x,[0 tsnrmx])),jet(256),sprintf('%s/tsnrRaw.png',y)),...
        temporalsnr, epiIntermPath, 'UniformOutput',0);

    clear temporalsnr
    fprintf('done.\n');

end

