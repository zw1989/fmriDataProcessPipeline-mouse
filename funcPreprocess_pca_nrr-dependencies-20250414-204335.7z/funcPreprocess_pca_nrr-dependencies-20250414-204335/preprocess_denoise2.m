% function epis = preprocess_denoise2(epiIntermPath, epis, episize, epismoothfwhm, method)
% denoises the epis by Gaussian smoothing or random matrix theory (RMT) based PCA
% with window size (roughly the functional FWHM of the denoised images) in voxel
% defined by epismoothfwhm/episize.  
% 
% Inputs:
% <epiIntermPath> is the directory or a one-level cell vector of directories to write
%   figures and results to. [] or {} means do not write figures and results.
% <epis> is a 4D volume or a cell vector of 4D volumes.
%   these volumes should be double format but should be suitable for 
%   interpretation as int16.  there must be at least one EPI run.  
%   the first three dimensions must be consistent across cases.
% <episize> is a 3 or 4-element vector representing with the first 3
%   dimensions representing the voxel size in mm.
% <epismoothfwhm> (optional) is a 2-element or 3-element vector with the desired FWHM of a Gaussian filter.
%   if supplied, we smooth the EPI volumes right after slice time correction.
%   Default is [] which means do nothing.
%   Special case is [P X Y Z] where P is the integer number of pads to use
%   and X Y Z is the desired simulated voxel size -- in this case we use
%   replication to pad each side of the volumes and then use the <mode>==1 
%   case of smoothvolumes.m to use ideal Fourier filtering to achieve smoothing.
% <method> is a array of character to indicate which denoising method to
%   use. Either 'gauss' or 'pca'

function epis = preprocess_denoise2(epiIntermPath, epis, episize, epismoothfwhm, method)

% input defaults
if ~exist('epismoothfwhm','var') || isempty(epismoothfwhm)
  epismoothfwhm = [];
end
if length(epismoothfwhm)==2
  epismoothfwhm = [epismoothfwhm, 0.001]; % Pad epismoothfwhm a small value (< 0.01) to enable 2D Gaussian smoothing 
end

if length(episize)>3
  episize = episize(1:3); % Only take the voxel size
end

if ~exist('method','var') || isempty(method)
  method = 'gauss';
end

% make cell if necessary
if ~iscell(epis)
  epis = {epis};
end
nepis = length(epis);

if ~iscell(epiIntermPath)
  epiIntermPath = {epiIntermPath}; 
end
if length(epiIntermPath) == 1
    epiIntermPath = repmat(epiIntermPath,1,nepis);
end

wantfigs = ~isempty(epiIntermPath{1});

% make intermediate figure and result dir
if wantfigs
  cellfun(@mkdirquiet, epiIntermPath); 
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Do it
switch method
    case 'gauss' % Gaussian smoothing
      fprintf('smoothing volumes...');
      if length(epismoothfwhm)==3 % Normal Gaussian smoothing

        epis = smoothvolumes(epis,episize,epismoothfwhm); 

      else % Fouier filtering
        for zz=1:length(epis)
          temp = padarray(epis{zz},repmat(epismoothfwhm(1),[1 3]),'replicate','both');
          temp = smoothvolumes(temp,episize,epismoothfwhm(2:4),1);
          epis{zz} = temp(epismoothfwhm(1)+1:end-epismoothfwhm(1), ...
                          epismoothfwhm(1)+1:end-epismoothfwhm(1), ...
                          epismoothfwhm(1)+1:end-epismoothfwhm(1),:);
        end
        clear temp;
      end
      label = 'gauss';
      fprintf('done.\n');  
  
    case 'pca' % RMT-based PCA denoising
        fprintf('--> Denoising volumes using RMT ...');
        
        if length(epismoothfwhm)==4
            fprintf('The length of epismoothfwhm should be less than 4 for PCA denoising');
            return
        end
        
        % Calculate window size (roughly FWHM of the denoised images in voxel)
        winsize = ceil(epismoothfwhm./episize(1:length(epismoothfwhm))); 
        winsize = winsize + 1 - mod(winsize,2); % Make it odd
        winsize = max(winsize,[3 3 1]);
        
        % RMT-based denoising
        [epis, R, sigma] = cellfun(@(x) RMTdenoising2(x, winsize, 1, 0, 1, 1:4), epis, 'UniformOutput',0);

        label = 'pca';
        fprintf('done.\n');
end


if wantfigs
    fprintf('writing out smoothed epi volumes and their tSNRs for inspection...');
    
    % inspect first and last of each run
    cellfun(@(x,y) viewmovie(x(:,:,:,1), fullfile(y,['epi',label,'-1']),1),epis, epiIntermPath,'UniformOutput',0); 
    cellfun(@(x,y) viewmovie(x(:,:,:,end), fullfile(y,['epi',label,'-end']),1),epis, epiIntermPath,'UniformOutput',0);
    %cellfun(@(x,y) viewmovie(x(:,:,:,1:end), {fullfile(y,'epiRaw-1'),60}),epis, epiIntermPath,'UniformOutput',0); % make moive

    % Compute temporal SNR of raw data
      % this is a cell vector of 3D volumes.  values are percentages representing the median frame-to-frame difference
      % in units of percent signal.  (if the mean intensity is negative, the percent signal doesn't make sense, so
      % we set the final result to NaN.)  [if not enough volumes, some warnings will be reported.]
    temporalsnr = cellfun(@computetemporalsnr,epis,'UniformOutput',0);

    % Write out temporal SNR for each run
    tsnrmx = 5;
    % tsnrmx = median(temporalsnr{1}(:)); % max temporal SNR percentage (used in determining the color range)
    cellfun(@(x,y) imwrite(uint8(255*makeimagestack(tsnrmx-x,[0 tsnrmx])),jet(256),sprintf('%s/tsnr%s.png',y,label)),...
        temporalsnr, epiIntermPath, 'UniformOutput',0);

    clear temporalsnr
    
    % Save processed files
    cellfun(@(x,y) save_nii(make_nii(x, episize, [], 16),fullfile(y,['epi',label,'.nii'])), epis, epiIntermPath, 'UniformOutput',0); 
    
    
    fprintf('done.\n'); 

end