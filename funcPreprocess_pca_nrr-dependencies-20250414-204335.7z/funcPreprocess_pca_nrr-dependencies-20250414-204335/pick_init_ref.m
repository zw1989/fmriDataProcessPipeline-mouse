% function refImg = pick_init_ref(data, nc) picks the data volumes that have
% the largest spatial correlations with other volumes and returns the mean of the
% picked volumes with other top correlated volumes as the initial
% registration target volume. 
%
% Inputs:
% <data> is the time series volumes with the last dimension time. The image
%   volumes can be any dimension. 
% <nc> is a numeric indicating how many volumes with the highest
%   correlations will be used to calculate the reference volume. If
%   it is less than 1, interprete it as a percentage. The default value is
%   0.1 if nc is [].

function refImg = pick_init_ref(data, nc)

if ~exist('nc','var') || isempty(nc)
  nc = min(size(data,ndims(data)),20); 
end

% if nc is percentage 
if nc < 1
  nc = ceil(nc * size(data,ndims(data)));
else
  nc = round(nc);
end


data(isnan(data)) = 0;

% % WHITENING???
% fdata = data;
% for idim = 1: (ndims(data)-1)
%   fdata = fft(fdata,[],idim);
% end
% dataNorm = fdata./abs(fdata); % Normalize the FFT data by dividing it the absolute value, which will only leave the phase information
% for idim = 1: (ndims(data)-1)
%   dataNorm = ifft(dataNorm,[],idim); 
% end
% data = real(dataNorm);

% Reshape the data to a 2D matrix
data2D = reshape(data, [], size(data,ndims(data)));

% Correlation coefficient matrix (spatial)
data2Dtmp = data2D - mean(data2D,1); % Remove mean value from each time point
CC = data2Dtmp'*data2Dtmp; 
CC = CC./(diag(CC) * diag(CC)').^.5; 

% CC = corrcoef(data2D); The same as the above calculation

% Sort CC along one dimension and get the best CC for each time point by
% averaging the first 20 largest CCs, then choose the best CC from all time
% points
[CCsort, isort] = sort(CC, 2, 'descend');
bestCC = mean(CCsort(:, 1:nc), 2);
[~, imax] = max(bestCC);

% Obtain data series that give the best nc averaged CC
refImg = mean(data2D(:,isort(imax, 1:nc)),2);

% Reshape the data to original size
refImg = reshape(refImg, sizefull(data,ndims(data)-1));

end
