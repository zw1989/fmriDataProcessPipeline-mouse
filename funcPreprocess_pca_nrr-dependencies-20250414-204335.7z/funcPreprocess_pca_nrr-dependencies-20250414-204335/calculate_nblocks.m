


function nblocks = calculate_nblocks(L, blockSize, blockShift)

if ~exist('blockShift','var') || isempty(blockShift)
  blockShift = 0.4; 
end

% If dShift is percentage change of the block_size
if blockShift < 1
  blockShift = max(1,fix(blockShift .* blockSize));
end

% dShift has a meaning if blockShift is less than L
blockShift = min(L,blockShift);

% 
% if block_size >= L
%   block_size = L;
%   nblocks = 1;
% else
  nblocks = ceil(L/blockShift);
%end



