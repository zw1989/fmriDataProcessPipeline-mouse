% Automatically generate a mask by thresholding the magnitude image
%
% Inputs:
% <img> is a 3D or 4D image
% <tuningParameter> (optional) set the level of the image intensity threshold, it's a
%   sliding button. 
%
% Outputs:
% <imgMask> is the generated mask
% <bgTh> is the intensity value used to threshold the img.


function [imgMask, bgTh] = automask(img, tuningParameter, erodeSize, dilateSize)

if ~exist('tuningParameter','var') || isempty(tuningParameter)
    tuningParameter = 0.2;
end

if ~exist('erodeSize','var') || isempty(erodeSize)
    erodeSize = 4;
end

if ~exist('dilateSize','var') || isempty(dilateSize)
    dilateSize = 4;
end

% if img has dimension larger than 3D, take average
img = mean(img,4);

% Obtain the 2% and 98% intensity range
intensityRange = prctile(img(:), [2 98]);

% Threshold for removing background
bgTh = (intensityRange(1) + tuningParameter*(intensityRange(2)-intensityRange(1)));  

% Generate the mask
imgMask = single(img > bgTh);

% Fill holes and dilate mask for each slice
imgMask = imerode(imgMask, strel('disk', erodeSize )); 
imgMask = imfill(imgMask, 4, 'holes'); % fill in the dark holes in the Mask with smallest connections
imgMask = imdilate(imgMask, strel('disk', dilateSize )); % Dilate each pixel in the Mask by 2 pixels
% figure; imagesc(mask); colormap(gray); axis off; axis equal; title('Brian mask');


