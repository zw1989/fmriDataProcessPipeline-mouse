% function refImg = pick_ref2(data, nc, sig, maxshift) choose the best
% reference image through an iterative process.  
%
% Inputs:
% <data> is a series of images concatenated along the last data dimension.
%   the number of volumes is nt. It is okay if <data> is int16.
% <nc> is a numeric indicating how many volumes with the highest
%   correlations will be used to calculate the reference volume. If
%   it is less than 1, interprete it as a percentage. The default value is
%   0.1 if nc is [].
% <smoothSigma> is the standard deviation of the Gaussian distribution
%   controlling how much smoothing is applied to refImg in Fourier domain.
%   It can also be a vector with the same length as the spatial dimensions
%   of data. Default is 0.5. Refer to the doc in <calcPhaseCorr.m>
% <maxshift> controls the maximum pixel(voxel) shifts between <img> and
%   <refImg>. It can either be a scaler or a vector with the same length as
%   the <img> dimension number. Elements that are less than one is regarded
%   as percentage.
%
% Hisotry:
% 2024/01/23 - created
% 

function refImg = pick_ref2(data, smoothSigma, maxshift)

% Inputs:
if ~exist('smoothSigma','var') || isempty(smoothSigma)
  smoothSigma = 1.0; % unit: pixel/voxel 
end
if ~exist('maxshift','var') || isempty(maxshift)
  maxshift = 0.1;
end

% Basic information about data
ndim = ndims(data); % The number of data dimensions 
nt = size(data, ndim); % The number of repetitions

% Change data to cells 
datatmp = squeeze(num2cell(nanreplace(data),1:ndim-1));

% Select a subset of timepoints
datatmp = datatmp(ceil(linspace(1,nt,min(300, nt))));
nt = length(datatmp);

% Pick initial refImg with top spatial correlated images for registration
refImg = pick_init_ref(catcell(ndim,datatmp)); % Starting with the 20 averages of top correlated data

% Normalize reference image and data???
rmin = round(prctile(refImg(:),1));
rmax = round(prctile(refImg(:),99));
refImg = normalizerange(refImg,rmin,rmax);
datatmp = cellfun(@(x) normalizerange(double(x),rmin,rmax), datatmp,'UniformOutput',0);

% Interatively refine refImg
niter = 8;
for ii = 1:niter
  
  % Motion estimation based on phase correlations
  [~,ss,cmax,datatmp] = calcPhaseCorr(datatmp, refImg, smoothSigma, [], maxshift,[],0);
 
  % Sort cmax and take the first nmax elements
  nmax = max(2,round(nt*ii/(2*niter))); % Take half data at most
  [~, igood] = sort(cmax, 'descend');
  igood = igood(1:nmax); 

  % Update reference image
  refImg = mean(catcell(ndim,datatmp(igood)),ndim);
  refImg = circshift(refImg, round(mean(ss(igood,:)))); % Shift reference image to position of mean shifts

  % figure;imshow(makeMontage(refImg - pick_init_ref(data, nc),1,0,'xy'),[]);
  
end