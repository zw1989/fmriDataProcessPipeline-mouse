function [epis, episize] = preprocessfmri3(epiIntermPath,fieldmapIntermPath, ...
    fieldmapData, fieldmapbrains, fieldmapsizes, fieldmapdeltate, fieldmapunwrapOpt, fieldmapsmoothfwhm,...
    epis, episize, episliceorder, epiphasedir, epireadouttime, ...
    epifieldmapasst, fieldmaptimeinterp, numepiignore, motionreference, ...
    epismoothfwhm, epidenoisemethod, species, tissuemasks, extratrans, targetres,...
    tfilterMode,wantRemoveOutlier,wantGSregress,...
    want2Dreg,blockShift,blockSize,maxRegShift,...
    wantpushalt)

% Inputs include four categories: 1) path variables; 2) necessary fieldmap-related
%   variables; 3) necessary epi-related variables; 4) optional variables
%
% Path inputs:
% <epiIntermPath> is the intermediate directory or a one-level cell vector
%   of directories to write EPI-related figures and results to. [] means do
%   not write figures and results. 
% <fieldmapIntermPath> is the intermediate directory or a one-level cell vector
%   of directories to write fieldmap-related figures and results to. [] means do
%   not write figures and results. 
%
% Necessary fieldmap-related inputs:
% <fieldmapData> is a 4D phase values with the fourth dimention representing
%   at least two different echo times or a single, real 3D fieldmap image
%   showing the field inhomogeneity in each voxel. It can also be a cell vector  
%   of such volumes or {A B} where A is a cell vector of one or more such
%   volumes and B is a vector of time values to associate with the volumes. 
%   if B is omitted or given as [], we default to 1:N where N is the number of
%   volumes supplied. If it is the 3D fieldmap image, the fieldmap
%   unwrapping is skipped. <fieldmapData> can be {}, which indicates that no  
%   undistortion is to be applied.
% <fieldmapbrains> is a 3D volume of magnitude brains or a cell vector
%   of such volumes.  can be {}.  should mirror <fieldmapData>.
% <fieldmapsizes> is a 3-element vector with the voxel size in mm
%   or a cell vector of such vectors. It should mirror <fieldmaps>.
%   if a single vector, we automatically repeat that vector for multiple
%   <fieldmaps>.
% <fieldmapdeltate> is the difference in TE that was used for the fieldmap
%   or a vector of such differences.  should be in seconds. should mirror
%   <fieldmaps>. if a single value, we automatically repeat that value for
%   multiple <fieldmaps>. 
% <fieldmapunwrapOpt> is whether to attempt to unwrap the fieldmap.  can be:
%   (1) 0 means no.
%   (2) 1 means yes and use the '-s -t 0' flags in prelude.
%   (3) a string with the specific flags to use (e.g. '', '-f').
%   can be a cell vector of things like (1)-(3).  should mirror <fieldmaps>.  
%   if a single element, we automatically repeat that element for multiple <fieldmaps>.
% <fieldmapsmoothfwhm> is a 3-element vector with the size of the
%   bandwidth in mm to use in the local linear regression or a cell vector
%   of such vectors.  can be {}.  should mirror <fieldmapData>.  if a single vector, we 
%   automatically repeat that vector for multiple <fieldmaps>.  the bandwidth 
%   along each dimension must be greater than the voxel size of the fieldmap 
%   along that dimension (this is because we need more than one data point along each 
%   dimension in order to perform local linear regression).  also, bandwidths
%   can be Inf (this results in pure linear regression along the corresponding 
%   dimension).  also, instead of a 3-element vector, you can supply NaN 
%   which means to omit smoothing.  for details on the meaning of the bandwidth,
%   see localregression3d.m, but here is an example: if <fieldmapsmoothing> is
%   [7.5 7.5 7.5], this means that the smoothing kernel should fall to 0 when
%   you are 7.5 mm away from the center point.  finally, a special case is
%   to specify [X Y Z 1] which means to impose extra regularization of the fieldmap
%   values towards 0 (for regions of the fieldmap with very low magnitude values).
% 
% Necessary EPI-related inputs:
% <epis> is a 4D volume or a cell vector of 4D volumes.
%   these volumes should be double format but should be suitable for 
%   interpretation as int16.  there must be at least one EPI run.  
%   the first three dimensions must be consistent across cases.
%   if <episliceorder> is used, it must be of the case where it is
%   a cell vector with at least two elements. 
% <episize> is a 3-element or 4-element vector with the first 3 the voxel
%   size in mm and the fourth element the epitr in seconds.
% <episliceorder> is a vector of positive integers (some permutation
%   of 1:S where S is the number of slices in the EPI volumes).  you can 
%   also specify 'sequential' or 'interleaved' or 'interleavedalt' ---
%   'sequential' translates into 1:S, 'interleaved' translates into 
%   [1:2:S 2:2:S], and 'interleavedalt' translates into [2:2:S 1:2:S]
%   when S is even and [1:2:S 2:2:S] when S is odd.  can also be {X} where 
%   X is a vector of positive integers that specify the times at which each 
%   slice is collected.  for example, if X is [1 2 3 1 2 3] this means that 
%   the 1st and 4th slices were acquired first, then the 2nd and 5th slices, 
%   and then the 3rd and 6th slices.  can also be {X NEWTR} which is the same
%   as the {X} case except that we prepare the data at a new TR (NEWTR) and
%   in doing so we use pchip interpolation (and first and last data point padding)
%   (instead of the usual sinc interpolation).  NEWTR can be a vector in which
%   case different runs get different TRs.  can also be {X NEWTR NEWOFFSET} which
%   allows temporal offsets (positive means start in the future) in seconds, where
%   NEWOFFSET can be a scalar or a vector (specifying different values for different
%   runs).  you can also set <episliceorder> to [] which means do not perform slice 
%   time correction.
% <epiphasedir> is an integer indicating the phase-encode direction or
%   a vector of such integers.  should mirror <epis>.  if a single integer,
%   we automatically repeat that integer for multiple <epis>.
%   this input matters only if <fieldmaps> and/or <sliceshiftband> are provided.
%   valid values are 1, -1, 2, or -2.  a value of 1 means the phase-encode 
%   direction is oriented along the first matrix dimension (e.g. 1->64); 
%   -1 means the reverse (e.g. 64->1).  a value of 2 means the phase-encode
%   direction is oriented along the second matrix dimension (e.g. 1->64);
%   -2 means the reverse (e.g. 64->1).
% <epireadouttime> is the duration of the EPI readout in milliseconds.
%   matters only if fieldmap(s) are provided.
%
% Optional inputs:
% <epifieldmapasst> indicates which fieldmaps to apply to which EPI runs.  
%   matters only if fieldmap(s) are provided.  if NaN, that means do not 
%   apply any fieldmaps to any run.  should be a cell vector of the 
%   same length as <epis>.  each element should either be a non-negative
%   integer or a sorted two-element vector [G H].  for a given element, if 
%   it is a positive integer, that indicates the index of the fieldmap to use; 
%   if it is 0, that indicates do not apply a fieldmap for that EPI run; if
%   it is a two-element vector, that indicates to interpolate from time value
%   G to time value H in order to figure out the fieldmap values to use
%   for that EPI run (in this case, each volume within the run gets a different
%   fieldmap correction).  if you pass in a vector of non-negative integers,
%   we automatically convert that to a cell vector.  there are some special
%   cases for your convenience.  if <epifieldmapasst> is passed in as [], 
%   that means (1) if there is one fieldmap then apply that fieldmap to all 
%   EPI runs, (2) if there are as many fieldmaps as EPI runs then apply fieldmaps
%   1-to-1 to the EPI runs, (3) if there is one more fieldmap than EPI runs, then
%   interpolate between each successive fieldmap to obtain the fieldmap to use
%   for each EPI run, and (4) otherwise, give an error.
% <fieldmaptimeinterp> (optional) is 'linear' or 'cubic' indicating the type of
%   interpolation to use for the cases in <epifieldmapasst>.  note that
%   to perform interpolation, we use the interp1.m function and in particular we 
%   use 'extrap' (thus, it is possible to use values for G and H that are outside 
%   the range of the original fieldmap time values).  default: 'cubic'.
% <numepiignore> (optional) is a non-negative integer indicating number of volumes
%   at the beginning of the EPI run to ignore or a vector of such integers.  
%   should mirror <epis>.  if a single integer, we automatically repeat that 
%   integer for multiple <epis>.  default: 0.  can also be {[A1 A2] [B1 B2] ... [N1 N2]}
%   where the length of this cell vector is the same as the number of <epis>,
%   and where A1, B1, ..., N1 are non-negative integers indicating number of
%   volumes at the beginning of the EPI runs to ignore, and A2, B2, ..., N2 are
%   non-negative integers indicating number of volumes at the end of the EPI runs
%   to ignore.
% <motionreference> (optional) indicates which EPI volume should be used 
%   as the reference for motion correction.  the format is [g h] where g indicates 
%   the index of the EPI run and h indicates the index of the volume within 
%   that run (after ignoring volumes according to <numepiignore>).  can also be the 
%   3D volume itself (we use this case if ~isvector(<motionreference>)).
%   can also be NaN which indicates that no motion correction should be performed.
%   default: [1 1], meaning the first volume of the first run as a
%   reference. Special case is 1) h = 0, meaning to take the
%   average of that run directly, and 2) h = -1, meaning to obtain the ref
%   by averaging the top 20 most correlated volumes and then iteratively
%   refine it. 
% <epismoothfwhm> is a 3-element vector with the desired FWHM of a filter.
%   if supplied, we smooth the EPI volumes right after slice time
%   correction if Gaussian filtering is used or we denoise the EPI volume
%   after the volume drop if RMT-based pca is used. Default is [] which
%   means do nothing. 
% <epidenoisemethod> is an array of characters to indicate which denoising method to
%   use. Either 'gauss' (default) or 'pca'.
% <species> is an array of characters indicating the brain size. Can be
%   'rat', 'mouse', 'cat', 'human' (default). This is an input to calculate
%   framewise displacement.
% <tissueMasks> is a 4D binary image with different tissue masks along the
%   4th dimension. This is an input used in fmriQC.m to draw the voxel
%   plot. It must have already registered to the epi and have the same
%   resolution and matrix size as the epi. Default is [], meaning doing
%   nothing. 
% <extratrans> (optional) is a 4x4 transformation matrix that maps points in the
%   matrix space of the EPI volumes to a new location.  if supplied, then volumes 
%   will be resampled at the new location.  for example, if <extratrans>
%   is [1 0 0 1; 0 1 0 0; 0 0 1 0; 0 0 0 1], then this will cause volumes to be 
%   resampled at a location corresponding to a one-voxel shift along the first
%   dimension.  <extratrans> can also be {X} where X is 4 x vertices, indicating
%   the exact locations (relative to the matrix space of the 3D volume) at which
%   to sample the data.  in this case, <targetres> must be [] and <finalepisize>
%   is returned as [].  <extratrans> can also be {X Y Z} where X, Y, and Z are
%   3D volumes that specify the exact locations (relative to the matrix space
%   of the original 3D volume) at which to sample the data.  in this case,
%   <targetres> must be [] (it is implicitly determined) and <finalepisize>
%   is returned as []. default: eye(4).
% <targetres> (optional) is
%   (1) [X Y Z], a 3-element vector with the number of voxels desired for the final 
%       output.  if supplied, then volumes will be interpolated only at the points 
%       necessary to achieve the desired <targetres>.  we assume that the field-
%       of-view is to be preserved.
%   (2) {[A B C] [D E F] G H}, where [A B C] is a 3-element vector with the number of voxels
%       desired for the final output and [D E F] is the voxel size in mm.  in this case, 
%       we do not assume the field-of-view is preserved; rather, we just assume the 
%       desired grid is ndgrid(1:A,1:B,1:C) (after potentially moving according to
%       <extratrans>).  G is 0/1 indicating whether to tightly crop the output 
%       volumes (see below for more details).  H is 0/1 indicating whether to 
%       save only the <validvol> voxels, and we do so in a flattened format 
%       (A x 1 x 1 x T).
%   default is [] which means to do nothing special.
% <tfilterMode> is a two-element cell array whose first cell is the frequency
%   cutoff. It can be one number for the high-pass filter (i.e. below which
%   is removed) or can be a two-element vector indicating a bandpass
%   frequencies. The second cell can be either 0 or 1, indicating whether
%   to regress motion or not. Default is {0,0}, meaning do nothing.
% <wantGSregress> is 0 or 1, indicating whether to regress out global
%   signal (and its first derivative). Default is 0. 
% <want2Dreg> is 0 or 1, indicating whether to perform motion correction on
%   each slice. Default is 0. 
%
% Non-rigid estimation inputs:
% <blockShift> is a vector of integers with the same length as the dimensions of ref.
%   It indicates the distance between neighbor blocks. If it has the same
%   size as referece image, only one block, i.e. the whole image, is used
%   for registration, which is equivalent to the rigid registration.
%   Special case [] means don't do non-rigid estimation. Example:
%   blockShift = [4,4,1], neighboring blocks has a distance of [4,4,1]
%   along each dimension, respectively.
% <blockSize> is a vector of integers with the same length as blockShift.
%   It is the size of the blocks. If it has the same
%   size as referece image, only one block, i.e. the whole image, is used
%   for registration, which is equivalent to the rigid registration.
%   Special case [] means blockSize is the spatial data size. Example:
%   blockSize = [32,32,1], [8,8,6], or [64,48,12]. Note [24,10,1] causes
%   regisration problems?
% <maxRegShift> controls the maximum pixel(voxel) shifts between data blocks and
%   ref blocks. It can either be a scaler or a vector with the same length as
%   the ref dimension number. Elements that are less than one is regarded
%   as percentage. Default is 0.1, i.e. 10% of the block size. Example,
%   maxRegShift = [2,2,1];
%
% <wantpushalt> is either [] which means do nothing special or a cell of paths to
%   the intermediate results obtained from a previous call. The effect of
%   <wantpushalt> is to skip some processing --- specifically, we load in
%   the previous undistorted epis, mparams, and outliers to continue
%   processing. Can also be {PA fieldmap epipca reg2dMap mparams
%   nonrigidMap} where PA is the path and fieldmap, epipca, reg2dMap,
%   mparams, nonrigidMap, is 0/1 indicating whether to load these previous
%   results and use them.

%
% Hisotry:
% 2024/01/27 - created from copying preprocessfmri2.m and added non-rigid
%  motion correction. Replace undistortvolumes.m to undistortvolumes2.m
%  where pixel shift can be maps along three dimensions.
%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DBSTOP

dbstop if error;

if isempty(gcp); parpool(10); end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PREP
% Reformat some inputs
if ~iscell(epis)
  epis = {epis};
end

nepis = length(epis); % scan number
epidim = size(epis{1}); % e.g. [64 64 16 300]

if ~isvector(motionreference)
  epidimRef = size(motionreference); % e.g. [64 64 16]
else
  epidimRef = epidim(1:3);
end

if ~iscell(epiIntermPath)
  epiIntermPath = {epiIntermPath}; 
end
if length(epiIntermPath) == 1
    epiIntermPath = repmat(epiIntermPath,1,nepis);
end

if contains(epiIntermPath,'intermediate-data')
    preprocessedPath = cellfun(@(x) stripfile(strrep(x,'intermediate-data','preprocessed-data')), epiIntermPath,'UniformOutput',0);
    preprocessedName = cellfun(@(x) [stripfile(strrep(x,'intermediate-data','preprocessed-data'),1),'.nii'], epiIntermPath,'UniformOutput',0);
else
    preprocessedPath = epiIntermPath;
    preprocessedName = repmat({'epipreprocessed.nii'},1,nepis);
end
cellfun(@mkdirquiet, preprocessedPath); % Target folder

% Deal with some optional input default
if ~exist('epifieldmapasst','var') || isempty(epifieldmapasst)
  epifieldmapasst = []; 
end
if ~exist('fieldmaptimeinterp','var') || isempty(fieldmaptimeinterp)
  fieldmaptimeinterp = 'cubic';
end
if ~exist('numepiignore','var') || isempty(numepiignore)
  numepiignore = 0;
end
if ~exist('motionreference','var') || isempty(motionreference)
  motionreference = [1 1];
end
if ~exist('epismoothfwhm','var') || isempty(epismoothfwhm)
  epismoothfwhm = []; % This will skip the denoising process.
end
if ~exist('epidenoisemethod','var') || isempty(epidenoisemethod)
  epidenoisemethod = 'gauss';
end
if ~exist('species','var') || isempty(species)
  species = 'mouse';
end
if ~exist('tissuemasks','var') || isempty(tissuemasks)
  tissuemasks = [];
end
if ~exist('extratrans','var') || isempty(extratrans)
  extratrans = eye(4);
end
if ~exist('targetres','var') || isempty(targetres)
  targetres = [];
end
if ~exist('tfilterMode','var') || isempty(tfilterMode)
  tfilterMode = []; 
end
if ~exist('wantRemoveOutlier','var') || isempty(wantRemoveOutlier)
  wantRemoveOutlier = 1; 
end
if ~exist('wantGSregress','var') || isempty(wantGSregress)
  wantGSregress = 0; 
end

if ~exist('blockShift','var') || isempty(blockShift)
  blockShift = [];
end
if ~exist('blockSize','var') || isempty(blockSize)
  blockSize = []; 
end
if ~exist('maxRegShift','var') || isempty(maxRegShift)
  maxRegShift = 0.1; % Better to be small for small block processing, e.g. [2,2,1]
end
if ~exist('wantpushalt','var') || isempty(wantpushalt)
  wantpushalt = {[],0,0,0,0,0}; 
end

% deal with targetres
if iscell(extratrans)
  targetres = [];
end


if all(catcell(1,wantpushalt(2:end)))
  wantpushaltTF = 1;
else
  wantpushaltTF = 0;
end


% Flags
wantdenoise = ~isempty(epismoothfwhm);
wantundistort = ~isempty(fieldmapData);
wantmotioncorrect = ~isequaln(motionreference,NaN);
wantslicetimecorrect = exist('episliceorder','var')&&(~isempty(episliceorder));
wanttfilter = ~isempty(tfilterMode);
wantNonrigidEst = ~isempty(blockShift);

% if wantundistort && length(epiphasedir)==1
%   epiphasedir = repmat(epiphasedir,[1 nepis]);
% end

switch wantpushaltTF

  case 0

%% I. fieldmap preprocess
if wantundistort
  if wantpushalt{2}==0
    [finalfieldmaps] = preprocess_fieldmap2(fieldmapIntermPath, ...
        fieldmapData, fieldmapbrains, fieldmapsizes, fieldmapdeltate, ...
        fieldmapunwrapOpt, fieldmapsmoothfwhm, epidim, episize, nepis,  ...
        epifieldmapasst, fieldmaptimeinterp);
  else
    % Load undistorted EPIs
    nii = cellfun(@(x) load_nii(fullfile([strrep(x,'func','fmap'),'_fieldMap'],'finalfieldmap.nii')),wantpushalt{1},'UniformOutput',0);
    finalfieldmaps = cellfun(@(x) x.img, nii,'UniformOutput',0);
  end

else
    finalfieldmaps = cell(1,nepis);
end

%% II. EPI preprocess
%% 1. EPI volume drop and raw data inspection
% Here we drop the first and last 5 volumes to account for steady state
% effect and unstability caused by gradient heating, respectively
% numepiignore = [5,5];
sliceSelection = []; % Here we always use all slices
epis = preprocess_volumedrop2(epiIntermPath, epis, numepiignore, sliceSelection);

%% 2. Slice-time correction (related to slice order, variable TR)

if wantslicetimecorrect
% episliceorder = 'sequential'; 
epis = preprocess_slicetimecorrection(epis, episliceorder);

% Save data
cellfun(@(x,y) save_nii(make_nii(x,episize,[],16),fullfile(y,'epiSliceTimeCorrection.nii')), epis, epiIntermPath, 'UniformOutput',0); 
    
end

%% 3. RMT-based PCA denoising (optional)
% epismoothfwhm = [0.5 0.5 0.5]; % mm
% epidenoisemethod = 'pca';

if wantdenoise && strcmp(epidenoisemethod,'pca')

  if isempty(wantpushalt) || wantpushalt{3}==0
    epis = preprocess_denoise2(epiIntermPath, epis, episize, epismoothfwhm, epidenoisemethod);
  else
    % Load denoised EPIs
    nii = cellfun(@(x) load_nii(fullfile(x,'epipca.nii')),wantpushalt{1},'UniformOutput',0);
    epis = cellfun(@(x) x.img, nii,'UniformOutput',0);
  end
end


%% 4. Generate epi mask based on intensity threshold.
% Erode and then dialte masks will make the mask uniform.
tuningParameter = 0.2; % Typically 0.1~0.2 is a good value.
erodeSize = 4; % Erode mask with a disk with radius of 4 pixels
dilateSize = 8; % Dilate mask with a disk with radius of 8 pixels
epimask = automask(catcell(4,epis),tuningParameter,erodeSize,dilateSize);

%% 2D Slice registration (translation only)
if want2Dreg
  if isempty(wantpushalt) || wantpushalt{4}==0
    % undistort temporarily [NOTE: epistemp is int16 but gets converted to double/single]
    if wantundistort
      [epistmp,~,validvoltemp] = cellfun(@(x,y) undistortvolumes2(nanreplace(x),episize(1:3),y*epireadouttime,epiphasedir,[]),...
                                                      epis,finalfieldmaps,'UniformOutput',0);
      % yuck..  we have to explicitly convert to double/single and then set nan voxels to NaN
      for p=1:length(epistmp)
        epistmp{p} = squish(cast(epistmp{p},'double'),3);
        epistmp{p}(~validvoltemp{p},:) = NaN;
        epistmp{p} = reshape(epistmp{p},sizefull(epis{p},4));
      end

      % Save data
      cellfun(@(x,y) save_nii(make_nii(x,episize,[],16),fullfile(y,'epiFmapCorrected.nii')), epistmp, epiIntermPath, 'UniformOutput',0); % Save data
    else
      epistmp = epis;
    end
  
    % Parameters below are kind of general setting for now
    smoothSigma = 0.5;
    snrThresh = 3.0;
    subpixel = 10;
    skipCorrection = 0;
    
    blockShift2D = [epidim(1:2),1];
    blockSize2D = blockShift2D;
    
    % Estimate 2D translation map from the undistorted. Note the estimated
    % "reg2dMap" has included 3D translations in voxels.
    [epistmp,rigidEst,~,reg2dMap,refvol] = preprocess_registration2(epiIntermPath,... 
                                                epistmp,motionreference,smoothSigma,...
                                                blockShift2D,blockSize2D,maxRegShift,snrThresh,subpixel,...
                                                skipCorrection);
    if isvector(motionreference)
      motionreference = refvol;
      save_nii(make_nii(refvol, episize,[],16),fullfile(stripfile(epiIntermPath{1}),'epiMoRef.nii'))
    end
    % Save data
    cellfun(@(x,y) save_nii(make_nii(x,episize,[],16),fullfile(y,'epi2Dreg.nii')), epistmp, epiIntermPath, 'UniformOutput',0); % Save data
    cellfun(@(x,y) save_nii(make_nii(x,episize,[],16),fullfile(y,'epi2DregMap.nii')), reg2dMap, epiIntermPath, 'UniformOutput',0); % Save data
  else
    % Load motion reference
    nii = load_nii(fullfile(stripfile(wantpushalt{1}{1}),'epiMoRef.nii'));
    motionreference = nii.img;

    % Load reg2dMap
    nii = cellfun(@(x) load_nii(fullfile(x,'epi2DregMap.nii')),wantpushalt{1},'UniformOutput',0);
    reg2dMap = cellfun(@(x) x.img, nii,'UniformOutput',0);
  end
else
  % epistmp = epis;
  % rigidEst = cell(1,nepis);
  rigidEst = repmat({zeros([size(epis{1},4),3])},1,nepis);
  reg2dMap = repmat({zeros([size(epis{1}),3])},1,nepis);
end

% Combine fieldmap and reg2dMap here
% Calculate final pixel shift maps
finalPixelShiftMaps = reg2dMap;
if wantundistort
  for ii=1:nepis
      finalPixelShiftMaps{ii}(:,:,:,:,abs(epiphasedir)) = finalPixelShiftMaps{ii}(:,:,:,:,abs(epiphasedir))+...
        repmat(sign(epiphasedir)*finalfieldmaps{ii}*epireadouttime,[1,1,1,choose(size(finalfieldmaps{ii},4)>1,1,size(finalPixelShiftMaps{ii},4))]);
  end
end

%% 5. Motion estimation
if wantmotioncorrect
  if isempty(wantpushalt) || wantpushalt{5}==0

    % undistort temporarily [NOTE: epistemp is int16 but gets converted to double/single]
    [epistmp,~,validvoltemp] = cellfun(@(x,y) undistortvolumes2(nanreplace(x),episize(1:3),y,1:3,[]),...
                                                    epis,finalPixelShiftMaps,'UniformOutput',0);
    % yuck..  we have to explicitly convert to double/single and then set nan voxels to NaN
    for p=1:length(epistmp)
      epistmp{p} = squish(cast(epistmp{p},'double'),3);
      epistmp{p}(~validvoltemp{p},:) = NaN;
      epistmp{p} = reshape(epistmp{p},sizefull(epis{p},4));
    end

    % Specify realignparams for spm motion correction. 'fwhm' is the spatial
    % smoothing size in mm, which should take a small number such as min(episize(1:3)) or 0. Also consider
    % whether spatial smoothing has been done before motion correction. If
    % spatial smoothing has been done, put 0 here. 'sep' is the sampling
    % distance in mm. For a good thumb of rule, sep = max(FOV)/50. 'interp' is
    % the degree of the B-spline interpolation and 7 is the highest.
    realignparams = struct('quality',1,'fwhm',min(episize(1:3)),'sep',max(episize(1:3).*epidim(1:3))/50,'interp',7);
    
    % Motion estimation and correction (can use one reference image for all
    % epis or one reference for each epi) from the undistorted. Only rigid
    % transformation is used. 
    [epistmp,mparams,refvol] = motioncorrectvolumes2(epistmp,episize,epiIntermPath,motionreference,inf,[],0,realignparams,[],epimask);
    
    if isvector(motionreference)
      motionreference = refvol;
      save_nii(make_nii(refvol, episize,[],16),fullfile(stripfile(epiIntermPath{1}),'epiMoRef.nii'))
    end
    % Save data
    cellfun(@(x,y) save_nii(make_nii(x, episize,[],16),fullfile(y,'epiMC.nii')), epistmp, epiIntermPath, 'UniformOutput',0); % Save data
    cellfun(@(x,y) writetable(array2table(y),fullfile(x,'motionParameter.txt'),'WriteVariableNames',0),...
                   epiIntermPath, mparams, 'UniformOutput',0); % Table varibale: {'Tx','Ty','Tz','Rx','Ry','Rz','Zx','Zy','Zz','Sx','Sy','Sz'}
  else
    % Load motion reference
    nii = load_nii(fullfile(stripfile(wantpushalt{1}{1}),'epiMoRef.nii'));
    motionreference = nii.img;

    % Load Motion corrected data
    nii = cellfun(@(x) load_nii(fullfile(x,'epiMC.nii')),wantpushalt{1},'UniformOutput',0);
    epistmp = cellfun(@(x) x.img, nii,'UniformOutput',0);

    % Load motion paramters
    mparams = cellfun(@(x) table2array(readtable(fullfile(x,'motionParameter.txt'))),wantpushalt{1}, 'UniformOutput',0); 
    
  end
  
else
  mparams = cellfun(@(x) repmat(spm_imatrix(createspmmatrix(epidim(1:3),episize(1:3))),size(x,4)+1,1), epis, 'UniformOutput',0);
end

clear epimask

%% 6a. Quality check and outlier detection based on the framewise displacement
% tissuemasks = [];
% species = 'mouse';
imgrotate = 1;
figvisible = 0;
outliers = preprocess_funcQC(epiIntermPath, epistmp, tissuemasks, mparams, species, imgrotate, figvisible);

% Save outlier information
cellfun(@(x,y) writetable(array2table(y),fullfile(x,'outlierInfo.txt'),'WriteVariableNames',0),...
               epiIntermPath, outliers, 'UniformOutput',0);

% If don't want to remove outliers, reset outlier index
if ~wantRemoveOutlier
    outliers = cellfun(@(x) 0*x, outliers,'UniformOutput',0);
end

% For debuging
% epistmp0 = epistmp;

%% Non-rigid registration
if wantNonrigidEst
  if isempty(wantpushalt) || wantpushalt{6}==0

    [epistmp,~,validvoltemp] = cellfun(@(x,y,z) undistortvolumes2(nanreplace(x),episize(1:3), ...
                                                                y,1:3,z(2:end,:)), ...
                                                                epis,finalPixelShiftMaps,mparams,'UniformOutput',0);
    % yuck..  we have to explicitly convert to double/single and then set nan voxels to NaN
      for p=1:length(epistmp)
        epistmp{p} = squish(cast(epistmp{p},'double'),3);
        epistmp{p}(~validvoltemp{p},:) = NaN;
        epistmp{p} = reshape(epistmp{p},sizefull(epis{p},4));
      end
  
  
    % Parameters below are kind of general setting for now
    smoothSigma = 0.5;
    snrThresh = 3.0;
    subpixel = 10;
    %subpixel = ceil(max(targetres./epidim(1:3)));
    skipCorrection = 0;
    
    % Estimate nonrigid map from the motion corrected and undistorted
    [epistmp,~,~,nonrigidMap] = preprocess_registration2(epiIntermPath,... 
                                          epistmp,motionreference,smoothSigma,...
                                          blockShift,blockSize,maxRegShift,snrThresh,subpixel,...
                                          skipCorrection);
    
    % Save data
    cellfun(@(x,y) save_nii(make_nii(x,episize,[],16),fullfile(y,'epiNRreg.nii')), epistmp, epiIntermPath, 'UniformOutput',0); % Save data
    cellfun(@(x,y) save_nii(make_nii(x,episize,[],16),fullfile(y,'epiNRregMap.nii')), nonrigidMap, epiIntermPath, 'UniformOutput',0); % Save data
    
    
    %% 6b. Quality check and outlier detection based on the framewise displacement
    % tissuemasks = [];
    % species = 'mouse';
    imgrotate = 1;
    figvisible = 0;
    figname = 'funcQC_NRreg';
    mparamsTmp = cellfun(@(x) 0*x, mparams, 'UniformOutput',0);
    mparamsTmp = cellfun(@(x,y) x+padarray([zeros(1,3);y(:,1:3)],[0,size(x,2)-3],'post'), mparamsTmp,rigidEst, 'UniformOutput',0);
    preprocess_funcQC(epiIntermPath, epistmp, tissuemasks, mparamsTmp, species, imgrotate, figvisible,figname);

  else
    % Load Motion corrected data
    nii = cellfun(@(x) load_nii(fullfile(x,'epiNRregMap.nii')),wantpushalt{1},'UniformOutput',0);
    nonrigidMap = cellfun(@(x) x.img, nii,'UniformOutput',0);
  end

else
  nonrigidMap = repmat({zeros([size(epis{1}),3])},1,nepis);
end


clear epistmp rigidEst

%% 7. Undistort volumes and resampling once

% temp = cellfun(@(x) load_nii(fullfile([strrep(x,'func','fmap'),'_fieldMap'],'finalfieldmap.nii')), epiIntermPath, 'UniformOutput',0);
% finalfieldmaps = cellfun(@(x) x.img, temp, 'UniformOutput',0); clear temp

% Some information about the sequence
% epiphasedir = -2; % "-2" means the phase encoding direction is along the 2nd matrix dimention, and from 64->1

% echospacing = 0.568; % ms, hack
% epireadouttime = echospacing*epidim(abs(epiphasedir))/1000; % s, this equals to echo spacing * phase dimension, the recipirical of it is the bandwidth per pixel

% extratrans = [];
% targetres = [];

% For debuging
% epis0 = epis;
% episize0 = episize;

% % Motion parameters: mparam + rigidEst
% for ii = 1:nepis
%   mparams{ii}(2:end,1:3) = mparams{ii}(2:end,1:3) + rigidEst{ii}(:,1:3)*diag([1,-1,-1]);
% end

try
%   if ~wantNonrigidEst
%     finalPixelShiftMaps = finalfieldmaps;
%     [epis,voloffset,validvolrun] = cellfun(@(x,y,z,k) undistortvolumes2(x(:,:,:,~k),episize(1:3), ...
%                      y*epireadouttime,epiphasedir,z([false;~k],:),extratrans,targetres,'double'), ...
%                      epis,finalPixelShiftMaps,mparams,outliers,'UniformOutput',0);
%   else
%     % Calculate final pixel shift maps
%     finalPixelShiftMaps = nonrigidMap;
%     if wantundistort
%       for ii=1:nepis
%           finalPixelShiftMaps{ii}(:,:,:,:,abs(epiphasedir)) = finalPixelShiftMaps{ii}(:,:,:,:,abs(epiphasedir))+...
%             repmat(sign(epiphasedir)*finalfieldmaps{ii}*epireadouttime,[1,1,1,choose(size(finalfieldmaps{ii},4)>1,1,size(finalPixelShiftMaps{ii},4))]);
%       end
%     end
%     [epis,voloffset,validvolrun] = cellfun(@(x,y,z,k) undistortvolumes2(x(:,:,:,~k),episize(1:3), ...
%                      y(:,:,:,~k,:),1:3,z([false;~k],:),extratrans,targetres,'double'), ...
%                      epis,finalPixelShiftMaps,mparams,outliers,'UniformOutput',0);
% 
%   end


%   [epis,voloffset,validvolrun] = cellfun(@(x,y,z,k,l) undistortvolumes2(nanreplace(x(:,:,:,~k)),episize(1:3), ...
%                      y*epireadouttime,epiphasedir,z([false;~k],:),extratrans,targetres,'double',[],l(:,:,:,~k,:)), ...
%                      epis,finalfieldmaps,mparams,outliers,nonrigidMap,'UniformOutput',0);

  [epis,~,validvolrun] = cellfun(@(x,y,z,k,l) undistortvolumes2(nanreplace(x(:,:,:,~k)),episize(1:3), ...
                     y(:,:,:,~k,:),1:3,z([false;~k],:),extratrans,targetres,'double',[],l(:,:,:,~k,:)), ...
                     epis,finalPixelShiftMaps,mparams,outliers,nonrigidMap,'UniformOutput',0);


catch
  warning('Undistortvolumes did not run');
  validvolrun = {ones(1,length(epis))};
end

% Update episize and epidim
if ~isempty(targetres)
    episize(1:3) = episize(1:3).*epidim(1:3)./targetres;
    epidimRef = epidimRef./epidim(1:3).*targetres;
    epidim(1:3) = targetres; % From now on, only the space size will be used 
end

% Save data
cellfun(@(x,y) save_nii(make_nii(x, episize,[],16),fullfile(y,'epiUndistorted.nii')), epis, epiIntermPath, 'UniformOutput',0); % Save data
% cellfun(@(x,y) save_nii(make_nii(mean(x,4), episize,[],16),fullfile(y,'epiUndistrotedMean.nii')), epis, epiIntermPath, 'UniformOutput',0); % Save data

% Save the mean EPI of the subject for later registration. Note we put the
% origin of the image to be the geomatric center now
epiref = mean(catcell(4,epis),4,'omitnan'); 
% epiref = epiref.*automask(epiref,0.1); % Should I use the masked version?
epiOrigin =  round(epidimRef/2+1);
save_nii(make_nii(epiref, episize,epiOrigin,16),fullfile(stripfile(epiIntermPath{1}),'epiRef.nii'))

clear epiref nonrigidMap finalfieldmaps finalfieldmaps

  case 1

    % Load undistorted EPIs
    nii = cellfun(@(x) load_nii(fullfile(x,'epiUndistorted.nii')),wantpushalt{1},'UniformOutput',0);
    epis = cellfun(@(x) x.img, nii,'UniformOutput',0);
    episize = nii{1}.hdr.dime.pixdim(2:5); % The voxel sizes should be the same and the last parameter tr can vary
    epidim = nii{1}.hdr.dime.dim(2:5);
    epiOrigin =  round(epidim(1:3)/2+1);

    % Load reg2dMap
    nii = cellfun(@(x) load_nii(fullfile(x,'epi2DregMap.nii')),wantpushalt{1},'UniformOutput',0);
    reg2dMap = cellfun(@(x) x.img, nii,'UniformOutput',0);

    % Load motion paramters
    mparams = cellfun(@(x) table2array(readtable(fullfile(x,'motionParameter.txt'))),wantpushalt{1}, 'UniformOutput',0); 
    
    % Load outlier indices
    outliers = cellfun(@(x) table2array(readtable(fullfile(x,'outlierInfo.txt'))),wantpushalt{1}, 'UniformOutput',0); 
    
    % Some other parameters
    validvolrun = {ones(1,length(epis))};
end


%% 8. Gaussian smoothing (optional)

if wantdenoise && strcmp(epidenoisemethod,'gauss')
% epismoothfwhm = [0.5 0.5 0.5]; % mm
% epidenoisemethod = 'gauss';
epis = preprocess_denoise2(epiIntermPath, epis, episize, epismoothfwhm, epidenoisemethod);
end


%% 9. Nuisance regression (motion, low frequency<=0.01Hz)
if wanttfilter
  cutoffFreq = tfilterMode{1}; % Hz
  mode = 0;
  
  % Motion traces (2D and 3D)
  if tfilterMode{2}
    % mparamsTmp = cellfun(@(x,y,k) cat(2,x([false;~k],1:6)-repmat(x(1,1:6),sum(~k),1),reshape(permute(squeeze(y(1,1,:,~k,1:2)),[2 1 3]),size(y,4)-sum(k),[])), ...
    %                                 mparams,reg2dMap,outliers,'UniformOutput',0);

    mparamsTmp = cellfun(@(x,k) x([false;~k],1:6)-repmat(x(1,1:6),sum(~k),1), ...
                                    mparams,outliers,'UniformOutput',0);

    % mparams2D = cellfun(@(y,k) permute(squeeze(y(1,1,:,~k,1:2)),[2 3 1]), ...
    %                                 reg2dMap,outliers,'UniformOutput',0);

  else
    mparamsTmp = cell(1,nepis);
    % mparams2D = cell(1,nepis);
  end

  
  % epis = cellfun(@(x,y,z,k) preprocess_temporalfiltering(x, y, z, ...
  %     episize(4),cutoffFreq, mode,wantGSregress,k), epiIntermPath,epis,mparamsTmp,mparams2D,'UniformOutput',0);
  epis = cellfun(@(x,y,z) preprocess_temporalfiltering(x, y, z, ...
      episize(4),cutoffFreq, mode,wantGSregress), epiIntermPath,epis,mparamsTmp,'UniformOutput',0);

end

% epistest = cellfun(@(x,y,k) preprocess_temporalfiltering(x, y, [], cutoffFreq, k(4)),...
%     intermPath,epis,episizes,'UniformOutput',0);


%% 10. Quality check and outlier detection based on the framewise displacement
masks = [];
% species = 'mouse';
imgrotate = 1;
figvisible = 0;
figname = 'funcQC_nr';
outliers2= preprocess_funcQC(epiIntermPath, epis, masks, cellfun(@(x,y) x([true;~y],:),mparams,outliers,'UniformOutput',0),...
    species, imgrotate, figvisible, figname);

%% End: Zero out nans and save the preprocessed data
validvol = all(catcell(ndims(epis{1}),validvolrun),ndims(epis{1}));  
for p=1:length(epis)
    epis{p}(repmat(~validvol,[ones(1,ndims(epis{1})-1) size(epis{p},ndims(epis{1}))])) = 0;
end

% Save the preprocessed EPI of the subject. Note we put the origin of the
% image to be the geomatric center now 
cellfun(@(x,y,z) save_nii(make_nii(x, episize,epiOrigin,16),fullfile(y,z)), epis, preprocessedPath, preprocessedName, 'UniformOutput',0); % Save data


reportmemoryandtime;





















