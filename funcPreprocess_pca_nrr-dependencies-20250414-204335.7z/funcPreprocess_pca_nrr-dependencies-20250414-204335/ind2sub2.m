

function sub = ind2sub2(sz,ind)

ndim = length(sz);
sub = cell(1,ndim);
[sub{:}] = ind2sub(sz,ind);
