% function [cblocks, nblocks, indCblocks] = make_blocks(datadim, blockSize, dshift)
% splits data with any length of dimension <datadim> into evenly
% distributed blocks with size <blockSize> and hopping distance <dshift>.
% Return block center coordinates <cblocks>, numer of blocks along each
% dimension, i.e. block dimension <nblocks>, and index of block center
% <indCblocks>. 
%
% Inputs:
% <datadim> is the data dimensions to be splited. It can be any length.
% <blockSize> is a vector of integers with length not larger than
%   <datadim>. One will be padded to match the length of <datadim>. 
% <dshift> is a vector of integers with length and value not larger than
%   <datadim>.  
% 
% Hisotry:
% 2024/01/23 - created
% 
 
function [cblocks, nblocks, indCblocks] = make_blocks(datadim, blockSize, blockShift)
% Number of data dimensions
ndim = length(datadim);

% Inputs:
if ~exist('blockSize','var') || isempty(blockSize)
  % blockSize = ones(1,ndim); 
  blockSize = datadim;
end
if ~exist('blockShift','var') || isempty(blockShift)
  blockShift = ones(1,ndim); 
end

if length(blockSize) > ndim || length(blockShift) > ndim
  warning('block dimension is longer than data dimensions. Please check! \n');
  return
end
blockSize = [blockSize, ones(1,ndim-length(blockSize))];
blockShift = [blockShift, ones(1,ndim-length(blockShift))];

% Change them to cells
datadim = num2cell(datadim);
blockSize = num2cell(blockSize);
blockShift = num2cell(blockShift);

% Calculate number of blocks in each dimension
nblocks = cellfun(@(x,y,z) calculate_nblocks(x,y,z),datadim, blockSize, blockShift,'uniformoutput',0);

% Block center, note in some cases, the block center is at 0.5 voxel
icenter = cellfun(@(x,y,z) (1:x:y)+(y-(z-1)*x-1)/2, blockShift, datadim, nblocks,'UniformOutput',0); % starting from the first element, then shift certain voxels to make the samples in center

% Obtain the block center indices for all blocks
cblocks = cell(1,ndim);
[cblocks{:}] = ndgrid(icenter{:});

% Make a vector for each dimension 
cblocks = cellfun(@(x) x(:), cblocks,'UniformOutput',0);

% Vector of block dimension
nblocks = catcell(2,nblocks);

% Get (ceiled) subsripts of each block center and convert it to index
tmp = cellfun(@(x) ceil(x),cblocks,'UniformOutput',0);
indCblocks = sub2ind(catcell(2,datadim),tmp{:});


%% OLD

% Start index of blocks 
% istart = cellfun(@(x,y,z) fix(linspace(1, x-y+1, z)), datadim, block_size, nblocks,'UniformOutput',0); % round toward 0 by using fix

% Make a vector (start and end index of blocks) for each dimension and add end indices for each block along each dimension
% block = cellfun(@(x,y) [x(:),x(:)+y-1], block, block_size,'UniformOutput',0);






