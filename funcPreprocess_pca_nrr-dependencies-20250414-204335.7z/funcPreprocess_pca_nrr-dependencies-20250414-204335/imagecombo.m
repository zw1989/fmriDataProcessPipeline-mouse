
function [h,imgcombined] = imagecombo(img,displaysetting,montagesetting,...
                                      imgbkg,imghgl,displayType,cmap,cmapunit,...
                                      mode,gridOn,imghglMode)

% <img> is the 2D or 3D image that we want to draw.
% <displaysetting> (optional) is a vector that contains user defined
%   [minImg,maxImg,threshold,clusterSize]. The default is img minimum and
%   maximum with threshold 0 and clusterSize 0.
% <montagesetting> (optional) is a cell vector that contains
%   [rotation,montageSize,orientation] that is used in makeMontage.m. 
% <imgbkg> (optional) is the background image if provided. We assume it has
%   been coregistered with img and has the same resolution and matrix size
%   with img. 
% <imghgl> (optional) is the highlight image if provided. We assume it has
%   been coregistered with img and has the same resolution and matrix size
%   with img. This could be useful as a contour to highlight structure(s).
%   imghgl is better to be a binary image.
% <displayType> (optional) is a string indicating which type of display
%   will be used. Here we think the images can be either displayed as
%   "sequential" (default) or "bipolar". The former works as the voxel values are
%   continuous and contrast mainly is used to distinguish structures. The
%   later emphasizes the negative and positive contrast, which has
%   distinguished meanings. Like cross-correlation coefficient map.  
% <cmap> is the colormap used to colorize images for "sequential" display
%   type. It can be jet, autumn, brewermap(N,'RdBu') or an Nx3 array. It
%   has no influence on "bipolar" type where red-orange is used 
%   for positive value while blue-purple is used for negative value.
% <cmapunit> is the unit of the image intensity that will be shown in the
%   colorbar. Default is ''.
% <mode> is a string indicating how we combine the img and imgbkg.
%   "inserted" (default) means to insert img in imgbkg to become one RGB image.
%   "overlapped" means to display images in two linked axes and with img
%   being shown in certain transparent degree. This could be useful for
%   metabolic images.
% <gridOn> is an addition figure setting of turning on/off the grids. It
%   can be 0 (default) or 1. It can also be a two-element vector with 0 and
%   1 with the second one indicating whether to show x and y labels.
% <imghglMode> is either 'contour' (default) or 'point' indicating how
%   should we highlight the image areas.
 
displaysetting0 = [min(img(~isinf(img(:)))),max(img(~isinf(img(:))))+eps,0,0];
montagesetting0 = {0,0,'xy'};

% inputs
if ~exist('displaysetting','var') || isempty(displaysetting)
  displaysetting = displaysetting0; % [minImg,maxImg,threshold,clusterSize]
end
if ~exist('montagesetting','var') || isempty(montagesetting)
  montagesetting = {0,0,'xy'}; % [rotation,montageSize,orientation]
end
if ~exist('imgbkg','var') || isempty(imgbkg)
  imgbkg = [];
else % Check imgbkg size
  assert(isequal(size(imgbkg),size(img)), 'imgbkg and img should have the same size\n');
end
if ~exist('imghgl','var') || isempty(imghgl)
  imghgl = [];
else % Check imgbkg size
  assert(isequal(size(imghgl),size(img)), 'imghgl and img should have the same size\n');
end

if length(displaysetting) < 4
  displaysetting = [displaysetting, displaysetting0( (length(displaysetting)+1):end )];
end
if length(montagesetting) < 3
  montagesetting = [montagesetting, montagesetting0( (length(montagesetting)+1):end )];
end
if ~exist('displayType','var') || isempty(displayType)
  displayType = 'sequential'; 
end

if ~exist('cmap','var') || isempty(cmap)
  cmap = gray(256); 
end
if ~exist('cmapunit','var') || isempty(cmapunit)
  cmapunit = '';  
end
if ~exist('mode','var') || isempty(mode)
  mode = 'inserted';  
end
if ~exist('gridOn','var') || isempty(gridOn)
  gridOn = [0,0];  
end
if ~exist('imghglMode','var') || isempty(imghglMode)
  imghglMode = 'contour';  
end


% Check the settings for the display range of img
if strcmp(displayType,'bipolar')
  displaysetting = abs(displaysetting);
end
minImg = displaysetting(1);
maxImg = displaysetting(2);
threshold = max(displaysetting(3),minImg);
cluster = displaysetting(4);
assert(minImg<=threshold && maxImg>=threshold, 'Displaysetting contains [minImg, maxImg, threshold, cluster_size] following minImg<=threshold<maxImg \n');

% Check the mongtage setting
rotation = montagesetting{1};
matrixSize = montagesetting{2};
orientation = montagesetting{3};


% Mask the image by applying the intensity threshold
imgMask = abs(img) >= abs(threshold);

% Remove patches in the mask image whose voxel number is smaller than cluster in each slice 
for ii = 1:size(img,3)
    % Label each non-zero individual area
    maskAnnotation = bwlabel(imgMask(:,:,ii), 8);
    for jj = 1:max(maskAnnotation(:))
        if sum(maskAnnotation(:)==jj)<cluster
            maskAnnotation(maskAnnotation==jj)=0;
        end
    end
    imgMask(:,:,ii) = maskAnnotation > 0;
end

% Mask out the img
% img = img.*imgMask;

% Create cancatenated 2D image from 3D (montage). This is the img we will display 
[img2D,imgdim] = makeMontage(img,rotation,matrixSize,orientation);
imgMask2D = makeMontage(imgMask,rotation,matrixSize,orientation);

% How to assign color to img? Generally, there are two display requirement:
% 1. Sequential display to show the contrast of the image. This requirement
% thinks the voxel values are continuous and reflect single meaning. Like
% imagesc(img)
% 2. Bipolar display to emphasize the negative and positive contrast, which
% has distinguished meaning. Like cross-correlation coefficient map

%%% Deal with main image
switch displayType
  case 'sequential'
    % Normalize to [minImg, maxImg]
    imgNormalized = (img2D(:)-minImg)/(maxImg-minImg);

    % Truncate
    imgNormalized(imgNormalized>1)=1;
    imgNormalized(imgNormalized<0)=0;
    
    % Initialize RGB image
    imgRgb = repmat(imgNormalized,1,3);

    % Assign colors to each voxel from the colormap
    cidx = round((size(cmap,1)-1)/(1-0)*imgNormalized)+1; % Linear projection of the cmap
    imgRgb(cidx>0,:) = cmap(cidx(cidx>0),:);

  case 'bipolar'
    % Normalize to [minImg, maxImg]
    imgNormalized = (abs(img2D(:))-minImg)/(maxImg-minImg);

    % Truncate
    imgNormalized(imgNormalized>1)=1;
    imgNormalized(imgNormalized<0)=0;

    % Initialize RGB image
    imgRgb = repmat(imgNormalized,1,3);

    % Assign red to positive values and blue to negative values [1 x 0]
    imgRgb(~isnan(imgNormalized)&(imgNormalized~=0),1)=1;
    imgRgb(~isnan(imgNormalized)&(imgNormalized~=0),3)=0;
    
    % Change to opposite color if intensity is negative
    % imgRgb(img2D(:)<0,:) = imgRgb(img2D(:)<0,[3,2,1]); % Blue [0 x 1]
    imgRgb(img2D(:)<0,:) = imgRgb(img2D(:)<0,[2,3,1]); % Purple [x 0 1]
    
    % Get cmap for colorbar draw
    cmap1 = [linspace(1,0,128), ones(1,128)];
    cmap2 = [zeros(1,128),linspace(0,1,128)];
    cmap3 = [ones(1,128), zeros(1,128)];
    cmap = [cmap1;cmap2;cmap3]';
    
    % Should we change sign of the threshold
    threshold = sign(sum(sign(img2D(:)),'omitnan'))*threshold;
    
end

% Reshape imgRbg and mask it
imgcombined = reshape(imgRgb,[size(img2D),3]).*repmat(imgMask2D,[1,1,3]);


%%% Deal with background image
if ~isempty(imgbkg)

  % color range
  imgbkgMax=prctile(imgbkg(imgbkg>0),99);
  imgbkgMin=prctile(imgbkg(imgbkg>0),1);
  imgbkg=(imgbkg-imgbkgMin)/(imgbkgMax-imgbkgMin);% normalize

  % truncate
  imgbkg(imgbkg>1)=1;
  imgbkg(imgbkg<0)=0;
  
  % Make it 2D
  imgbkg2D = makeMontage(imgbkg,rotation,matrixSize,orientation);

  % Convert it to RGB
  imgbkgRgb=repmat(imgbkg2D.*0.8,[1 1 3]);% to RGB and adjust the brightness
else
  imgbkgRgb = zeros(size(imgcombined));

end

% How to use imgbkgRgb?
switch mode
  case 'inserted'
    % Inversely Mask the background image and combine image
    imgcombined = imgbkgRgb.*repmat(~imgMask2D,[1,1,3]) + imgcombined;
  case 'overlapped'
    % Do nothing
end

%%% Deal with highlight image
if ~isempty(imghgl)

  % Make it 2D, detect the edges, and dilate it
  imghgl2D = makeMontage(imghgl,rotation,matrixSize,orientation);
  labelList = unique(imghgl2D(:)); labelList(1) = []; % remove the 0

  switch imghglMode
    case 'contour'
      imghgl2D = edge(imghgl2D,'Sobel',0.2);
      %imghgl2D = edge(imghgl2D,'Canny');
      %imghgl2D = imdilate(imghgl2D,strel('disk',1));
      %imghgl2D = imerode(imghgl2D,strel('disk',1));
    
      % Convert it to RGB
      imghglRgb=repmat(imghgl2D,[1 1 3]);% to RGB and adjust the brightness
    
      % combine image
      imgcombined(imghglRgb>0) = imghglRgb(imghglRgb>0);
    case 'point'
      nlabel = length(labelList);
      x = cell(nlabel,1);
      y = x;
      for ii = 1:nlabel
        [x{ii},y{ii}] = find(imghgl2D==labelList(ii));
      end


  end


end

% Plot
fig = gcf;
if strcmp(mode,'overlapped') % Background image should be draw first
  ax1 = axes('Parent',fig); set(ax1,'Visible','off');
end
ax2 = axes('Parent',fig); set(ax2,'Visible','off');
h = imshow(imgcombined,'Parent',ax2,'InitialMagnification','fit');

% Draw colorbar
switch displayType
  case 'sequential'
    hc = drawcolorbar2([minImg, maxImg],unique(round([minImg, threshold+eps, maxImg],-floor(log10(abs(minImg+eps))))),cmap,cmapunit,0);
    set(hc, 'YTickLabel', cellstr(num2str(reshape(get(hc, 'YTick'),[],1),'%0.1f')) );
  case 'bipolar'
    hc = drawcolorbar2([-maxImg, maxImg],unique(round([-maxImg, threshold+eps, maxImg],-floor(log10(abs(minImg+eps))))),cmap,cmapunit,0);
    set(hc, 'YTickLabel', cellstr(num2str(reshape(get(hc, 'YTick'),[],1),'%0.1f')) )
end

% Plot the background image
if strcmp(mode,'overlapped') && ~isempty(imgbkg)
  set(h,'AlphaData',0.3); % Make the img transparent
  
  imshow(imgbkgRgb,'Parent',ax1,'InitialMagnification','fit')
  linkprop([ax2,ax1], 'position'); % Link ax2 position to ax1

end

if ~isempty(imghgl) && strcmp(imghglMode,'point') 
  % Plot the highlight markers if the mode is 'point'
  clabel = lines(length(x));
  markerSize = 16; % how to smartly set it?
  for ii = 1:length(x)
    scatter(ax2,y{ii},x{ii},markerSize,clabel(ii,:),'filled');
  end
end
hold off

% Additional figure setting
if any(gridOn)
  % Always use the axis in the bottom layer
  if strcmp(mode,'overlapped')
    ax = ax1;
  else
    ax = ax2;
  end
  if gridOn(1)
    axis(ax,'on'); grid(ax,'on');
    ax.GridColor = [1,1,1];
  end
  
  
  ax.XTick = (1:size(img2D,2))+0.5;
  ax.YTick = (1:size(img2D,1))+0.5;
  if gridOn(2)
    ax.XTickLabel = repmat(1:size(img,2),1,size(img2D,2)/size(img,2));
    ax.XTickLabelRotation = 0;
    ax.YTickLabel = repmat(1:size(img,1),1,size(img2D,1)/size(img,1));
    ax.YTickLabelRotation = 0;
  else
    ax.XTickLabel = [];
    ax.YTickLabel = [];
  end

  ax.TickLength = [0,0]; % Remove tick lines 
  
end

% Draw slice borders
vslice = (1:(size(img2D,2)/imgdim(2)-1))*imgdim(2) + 0.5;
hslice = (1:(size(img2D,1)/imgdim(1)-1))*imgdim(1) + 0.5;
h1 = straightline(hslice,'h','w-'); set(h1, 'LineWidth', 2)
h2 = straightline(vslice,'v','w-'); set(h2, 'LineWidth', 2)


