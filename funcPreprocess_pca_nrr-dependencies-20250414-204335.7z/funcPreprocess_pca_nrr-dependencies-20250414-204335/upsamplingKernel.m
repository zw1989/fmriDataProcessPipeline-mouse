

function K = upsamplingKernel(xs,ys,step,sigL)
% Smoothing width for upsampling gaussian kernels, best between 0.5-1.0?
sigL = 0.85; % kernel width in pixels
%sigL = 1.0;
%sigL = 5;

if length(xs) ~= length(ys)
  warning('xs and ys have different lengths.\n')
  K = [];
  return
end

step = cellfun(@(x) repmat(x,1,length(xs)-length(x)+1), step, 'UniformOutput',0);

% Data dimensions
ndim = length(xs);

% Get index range along each dimension
idxXs = cellfun(@(x,y) -x:y:x, num2cell(xs),num2cell(step{1}),'UniformOutput',0);
idxYs = cellfun(@(x,y) -x:y:x, num2cell(ys),num2cell(step{2}),'UniformOutput',0);

% Get substitutes and convert them to indices. Note meshgrid and ndgrid
% here don't make a difference 
subXs = cell(1,ndim); [subXs{:}] = ndgrid(idxXs{:});
subYs = cell(1,ndim); [subYs{:}] = ndgrid(idxYs{:});

% Get distance
d = meancell(cellfun(@(x,y) (x(:)-y(:).').^2,subXs, subYs,'UniformOutput', false),3);

% Calculate weighting matrix
K = exp(-d/(2*sigL^2));




