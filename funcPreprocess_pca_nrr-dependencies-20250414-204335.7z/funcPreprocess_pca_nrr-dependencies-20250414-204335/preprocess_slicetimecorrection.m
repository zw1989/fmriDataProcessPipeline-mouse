% function epis = preprocess_slicetimecorrection(epiIntermPath, epis)
% 
% Inputs:
% <epis> is a 4D volume or a cell vector of 4D volumes.
%   these volumes should be double format but should be suitable for 
%   interpretation as int16.  there must be at least one EPI run.  
%   the first three dimensions must be consistent across cases.
% <episliceorder> is a vector of positive integers (some permutation
%   of 1:S where S is the number of slices in the EPI volumes).  you can 
%   also specify 'sequential' or 'interleaved' or 'interleavedalt' ---
%   'sequential' translates into 1:S, 'interleaved' translates into 
%   [1:2:S 2:2:S], and 'interleavedalt' translates into [2:2:S 1:2:S]
%   when S is even and [1:2:S 2:2:S] when S is odd. you can also set
%   <episliceorder> to [] which means do not perform slice time correction.

% TO DO: needs to add temporal interpolation!


function epis = preprocess_slicetimecorrection(epis, episliceorder)

% Get epi dimensions
epidim = size(epis{1});

% Convert sliceorder word cases
if ischar(episliceorder)
  switch episliceorder
  case 'sequential'
    episliceorder = 1:epidim(3);
  case 'interleaved'
    episliceorder = [1:2:epidim(3) 2:2:epidim(3)];
  case 'interleavedalt'
    if mod(epidim,2)==0
      episliceorder = [2:2:epidim(3) 1:2:epidim(3)];
    else
      episliceorder = [1:2:epidim(3) 2:2:epidim(3)];
    end
  otherwise
    error('EPI slice order not recognized\n');
  end
end


fprintf('--> Correcting for differences in slice acquisition times... ');

% Slice time correct
epis = cellfun(@(x,y) sincshift(x,repmat(reshape((1-y)/max(y),1,1,[]),[size(x,1) size(x,2)]),4), ...
           epis,repmat({calcposition(episliceorder,1:max(episliceorder))},[1 length(epis)]),'UniformOutput',0);

%cellfun(@(x,y,z) save_nii(make_nii(x, y,[],64),fullfile(z,'epiSTC.nii')), epis, episizes, epiIntermPath, 'UniformOutput',0);        

fprintf('done.\n'); reportmemoryandtime;

















