% function epis = preprocess_temporalfiltering(epiIntermPath, epis)
% 
% Temporal filtering the time series of each voxel with three unwanted
% signal sources: 1) motion and its first derivatives, 2) low frequency
% drifts caused by physiological signal and scanner-related drifts, 3)
% tissue-based averaged signals and their derivatives such as from
% ventricle (CSF), white matter (WM), and global signal (whole brain). As
% CSF and WM have little effect to GM signal while GS is relative effective
% but may remove neuronal signal as well, the default procedure is to not
% remove the third catergory of signal.
% 
% Inputs:
% <epiIntermPath> is the directory to write figures and results to. [] or
%   {} means do not write figures and results. 
% <epi> is a 4D volume with the first three dimensions the space and last
%   dimension the time.
% <mparams> is an N x 6+ matrix with the first 6 columns representing the rigid
%   motion parameter estimate for each volume. Special case is [] which means
%   to omit motion correction. The first dimension of mparams should be the same as
%   the last dimension of epis.
% <cutoffFreq> can be a scaler, meaning the frequency below which we want
%   to remove by either constructing a discrete cosine transform (DCT)
%   basis set or using butter filter. It can also be a two-element array,
%   i.e. bandpass filter. In this case, only butter filter can be used.
%   Default value is 0.
% <epitr> is the repetation time of each sequence. It is used to calculate
%   the cutoff half cycle number.
% <mode> is 0 or 1, indicating whether to use DCT (time domain) or butter
%   filter (frequency domain) to filter the data. 
% <wantGSregress> is 0 or 1, indicating whether to regress out global
%   signal (and its first derivative). Default is 0. 

function epi = preprocess_temporalfiltering(figuredir, epi, mparams, epitr, cutoffFreq, mode, wantGSregress, mparams2D)

% Input default
if ~exist('figuredir','var') || isempty(figuredir)
  figuredir = [];
end
if ~exist('mparams','var') || isempty(mparams)
  mparams = [];
end
if ~exist('cutoffFreq','var') || isempty(cutoffFreq)
  cutoffFreq = []; % Hz
end
if ~exist('epitr','var') || isempty(epitr)
  epitr = 1; % sec
end
if ~exist('mode','var') || isempty(mode)
  mode = 0; % Default is DCT, 1 means butter
end
if ~exist('wantGSregress','var') || isempty(wantGSregress)
  wantGSregress = 0; % Default is don't do global signal regression
end
if ~exist('mparams2D','var') || isempty(mparams2D)
  mparams2D = [];
end

% If want bandpass filter, change mode to 1
if length(cutoffFreq) == 2
    mode = 1;
end


wantfigs = ~isempty(figuredir);
wantmotionregress = ~isempty(mparams); 
wanttfilter = ~isempty(cutoffFreq);
want2Dmotionregress = ~isempty(mparams2D);

if ~wantmotionregress*~wanttfilter==1
    fprintf('No temporal filtering is done.\n');
    return
end


nt = size(epi,ndims(epi));

fprintf('--> Start temporal filtering ...');

if want2Dmotionregress
  for ii = 1:size(epi,3)
  
    % The last dimension of mparams2D is slice 
    Rt2D = detrend((mparams2D(:,:,ii)-repmat(mean(mparams2D(:,:,ii)),nt,1))./repmat(std(mparams2D(:,:,ii)),nt,1));

    % extract the time-series data for the noise pool
    % Flatten the 4D data
    temp = squish(double(epi(:,:,ii,:)),3)';  % time x voxels
    
    % project out polynomials from the data
    temp = projectionmatrix(nanreplace(Rt2D)) * temp;

    % Reshape data to 4D
    epi(:,:,ii,:) = reshape(temp', size(epi(:,:,ii,:)));
  end
end

if wantmotionregress
    % Construct motion regressors by standardize and detrend the first 6
    % estimated motion parameters (x,y,z, pitch,yaw,roll) and then expand the
    % motion regressor matrix to  Volterra expansion (Friston et al., 1996): [R
    % R^2 R_(t-1) R_(t-1)^2]
    
    % Standardize the 6 motion estimates, x' = (x-mean(x))/std(x))
    Rt = (mparams-repmat(mean(mparams),nt,1))./repmat(std(mparams),nt,1);
    
    % Detrend the standardized motion regressors by a OLS fitted straight line
    Rt = detrend(Rt);
    
    % Expand the motion regressors
    Rt0 = [zeros(1,size(Rt,2)); Rt(1:end-1,:)];
    % motionRegressors = [Rt, Rt.^2, Rt0, Rt0.^2]; % It seems the square terms doesn't work well???
    %motionRegressors = [Rt,Rt0];
    motionRegressors = Rt;
    
else
    motionRegressors = [];
end


%%%%%%%%%%%%%%%%%%%%%%%% TO DO ? %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Tissue-based averaged signals and their first derivative: ventricular (V)
% for CSF, white matter (WM), and whole brain mask for the global
% signal(GS)? it seems CSF and WM have little effect to GM signal while GS
% is relative effective but may remove neuronal signal as well

tissueRegressors = [];
if wantGSregress

  % % Get global signal. Note this could introduce a lot of negative
  % % correlations
  epi2D = reshape2D(epi,ndims(epi));
  epi2D = epi2D(:,automask(epi,0.3)>0); % Only get the voxels in the brain mask
  epi2D = (epi2D-repmat(mean(epi2D),nt,1))./repmat(std(epi2D),nt,1); % Standadization
  gs = mean(epi2D,2,'omitnan');
  tissueRegressors = gs; % Global signal and their first derivative
  % tissueRegressors = [gs,[0;diff(gs)]]; % Global signal and their first derivative
  % %figure; plot(tissueRegressors);hold on

  % % Filter it
  % cutoff = 0.25; % Hz
  % tissueRegressors=tsfilter(tissueRegressors',constructbutterfilter1D(nt,cutoff*(nt*epitr)),[1 0])';
  % %plot(tissueRegressors); hold off
end



if wanttfilter && (mode==0)
    % Construct high-pass filter by using discrete cosine transform (DCT) basis
    % set. The highest frequency cosine function that should be included would
    % correspond to the highest frequency that is desired to be removed from
    % the data. For resting state, we want to remove frequencies equal to or
    % lower than 0.01Hz; for task fmri, we try to avoid the frequency of the
    % experimental task. As a general rule of thumb, the longest period of the
    % drift DCT basis should be at least twice the period of an on-off block
    % design. Refer to spm_filter.m and spm_dctmtx.m
    ks = fix(cutoffFreq*epitr*nt*2+1); % The cutoff half cycle number per run
    highpassRegressors = constructdctmatrix2(nt, 1:(ks-1));
    highpassRegressors = (highpassRegressors-repmat(mean(highpassRegressors),nt,1))./repmat(std(highpassRegressors),nt,1); % Standadization
else
    highpassRegressors = [];
end

% Combine motion and high-pass regressors
regressormatrix = [highpassRegressors, motionRegressors, tissueRegressors];

% Regress out motion and low frequency components from the data

% extract the time-series data for the noise pool
% Flatten the 4D data
temp = squish(double(epi),3)';  % time x voxels

% project out polynomials from the data
temp = projectionmatrix(nanreplace(regressormatrix)) * temp;

% unit-length normalize each time-series (ignoring any time-series that are all 0)
%[temp,len] = unitlengthfast(temp,1);
%temp = temp(:,len~=0);

% Reshape data to 4D
epi = reshape(temp', size(epi));



% We can also filter the timecourse from frequency domain
if mode == 1
    if length(cutoffFreq)==1
        cutoffFreq = [cutoffFreq, inf];
    end
    %epi=temporalSmoothing2(epi,automask(epi,0.1),epitr,cutoffFreq);
    epi=temporalSmoothing2(epi,[],epitr,cutoffFreq);
end
        
fprintf('done (Temporal filtering).\n'); 


if wantfigs

    figureprep;
    nr = size(regressormatrix,2);
    for ii = 1:nr
        plot(1:size(regressormatrix,1),regressormatrix(:,ii)+ii*2);
    end
    hold off
    xlim([0,nt]); ylim([0,2*(nr+1)]);
    % yticks([2,(1:6:nr)*2+(ks-1)*2]); yticklabels({'DCT','R','R^2','R_{(t-1)}','R_{(t-1)}^2'})
    title('Regressors')
    figurewrite('TemporalRegressors',[],[],figuredir);
end






%% %%%%%%%%%%%%%%%%%%% Explore frequency distribution of different polynomials 
% test = constructpolynomialmatrix(255, 0:6);
% test = constructdctmatrix2(255, 0:6);
% 
% 
% [pxx, f0] = pwelch(test,[],[],[],1);   % calc PSD with Welch's method
% figure; plot(f0, pow2db(pxx)); xlabel('f (Hz)'); ylabel('PSD (dB/Hz)'); legend('0','1','2','3','4')
% 
% deltaf = 1/(size(test,1)-1); % Hz
% fmax = 1/2; % Hz
% f = (-fmax:deltaf:fmax)- deltaf/2;
% 
% testfreq = abs(fftshift(fft(test),1));
% figure; 
% subplot(121); plot(1:size(test,1), test,'linewidth',2); xlabel('time (s)'); title('Polynormials'); legend('0','1','2','3','4','5','6')
% subplot(122); plot(f, testfreq,'linewidth',2); xlabel('frequency (Hz)'); title('FFT of Polynormials'); xlim([0,0.05]); legend('0','1','2','3','4','5','6')



