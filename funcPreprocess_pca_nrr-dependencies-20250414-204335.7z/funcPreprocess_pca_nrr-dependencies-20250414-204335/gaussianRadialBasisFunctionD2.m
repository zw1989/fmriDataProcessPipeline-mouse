

function R = gaussianRadialBasisFunctionD2(kernelSize)


% Dimension of the kernel
ndim = length(kernelSize);

% Make arrays
xx = cellfun(@(x) 1:x, num2cell(kernelSize),'UniformOutput',0);

% Create N-dimensional meshgrid
yy = cell(1,ndim);
[yy{:}] = ndgrid(xx{:}); 

% Should I do this?
yy = cellfun(@(x) permute(x,[2 1 3:ndims(x)]), yy,'UniformOutput',0);

% Calculate element wise difference along each dimension
dyy = cellfun(@(x) (x(:).'-x(:)).^2, yy,'UniformOutput',0);

% Add matrices for all dimensions
dd = zeros(size(dyy{1}));
for id = 1:ndim
  dd = dd + dyy{id};
end

% Obtain gaussian radial basis function
R = exp(-dd);

% Normalize columns (to get probability distribution)
R = R ./ repmat(sum(R,1),size(R,1),1);

