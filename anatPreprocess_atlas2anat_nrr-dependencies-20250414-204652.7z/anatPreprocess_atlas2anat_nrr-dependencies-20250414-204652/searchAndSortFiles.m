% Description: search data files in a folder and its subfolders and sort
% fiels based on specified key index by users. This function is modified
% based on Yuncong Ma's version, Apr. 16, 2015 

% Usage: fileInfo = searchAndSortFiles(searchPath,searchPattern,keysForSort)
% * eg. fileInfo = searchAndSortFiles('/user/data/','.mat',{{'Rat',-2},{'EPI',-1}})

% Inputs: 
% 1. searchPath - data directory, it should be a string

% 2. searchPattern - should be a regular expression for finding files with
% names that match to some criterions
% ** regular expression tips: 
% * \d is for one digit
% * \d+ is for a number with serveral digits
% * \s is for string
% * eg. '.mat', 'rat_\d+_scan_\d+.mat', '\s_\d+_\s_\d+.mat'

% 3. keysForSort - a cell that contains data structure information in the file
% name (full path) which can be used for sorting data; it could be empty [] or {}
% * eg. {{'Rat',1,-2:-1},{'EPI',-5}} means that use the last two digits of
% * the first number and the last fifth number in the file path for sorting
% * files. These Information will be added into fields with name 'Rat' and 'EPI'

% 4. funcIdx - 

% Outputs:
% 1. fileInfo - a structure with field 'Dir', 'Image', and 'Valid', and
% those defined in keysForSort


%%% to do

% History
% 20191018 --> add keysForSort for strings or keywords, for example: animal
% type (diseased = 1, control = 2). E.g. {'type', {{'control',1}, {'mutant',1}}},
% those whose imgName contains the 1st 'control' will be assigned to
% 'control' and sort by 1 and 1st 'mutant' by 2  


function fileInfo = searchAndSortFiles(searchPath,searchPattern,keysForSort,funcIdx)

if nargin < 4
    funcIdx = 0;
end

%% Search files
% Search files and subfiles in the searchPath and store them in a cell
fileDirCell=searchFiles(searchPath, searchPattern);

% Create a structure
fileDirStruct(1:length(fileDirCell))=struct('fullPath',[],'dir',[],'imgName',[],'ext',[],'Valid',1);
for i=1:length(fileDirCell)
    [pathstr,fileName,ext] = fileparts(fileDirCell{i});
    fileDirStruct(i).fullPath=fileDirCell{i};
    fileDirStruct(i).dir=pathstr;
    fileDirStruct(i).imgName=fileName;
    fileDirStruct(i).ext=ext;
end

% Only search the functional data directory if funcIdx == 1
if funcIdx == 1
    fileDirStruct(~contains({fileDirStruct.dir}, 'func'))=[];
end

%% Sort files
if ~isempty(keysForSort)
    fileInfo=sortFiles(fileDirStruct,keysForSort);
else
    fileInfo=fileDirStruct;
end

end

% Recursive method
function fileDir=searchFiles(searchPath,searchPattern)
fileDir={};
fileList=dir(searchPath); % List all the files in the path
for iFile=1:length(fileList)
    fileName=fileList(iFile).name;
    searchPath2=fullfile(searchPath,fileName);
   
    
    if ~strcmpi(fileName,'.') && ~strcmpi(fileName,'..')
        if fileList(iFile).isdir==1 && isempty(regexp(searchPath2,searchPattern, 'once'))
            temp=searchFiles(searchPath2,searchPattern);
            if ~isempty(temp)
                fileDir(end+1:end+length(temp))=temp;
            end
        else
            if regexp(searchPath2,searchPattern)
                fileDir{end+1}=searchPath2;
            end
        end
    end
end

end


function fileDirStruct=sortFiles(fileDirStruct,keysForSort)
nKeys=length(keysForSort); 

% Create a field for each key
for i=1:nKeys
    fileDirStruct(1).(keysForSort{i}{1})=[];
end

keyIdxInfo=-ones(length(fileDirStruct),nKeys+1);
keyIdxInfo(:,end)=1:length(fileDirStruct);
for i=1:length(fileDirStruct)
    % Extract numbers in the file name
    numExtracted=regexp(fullfile(fileDirStruct(i).fullPath),'\d+|\d+\.\d+','match');
    % Extract strings in the file name
    
    for j=1:nKeys
        if isnumeric(keysForSort{j}{2}) % Sort for number
            if length(numExtracted)<abs(keysForSort{j}{2})
                %fprintf('warning: there are not enough numbers in path %s \n',fullfile(fileDirStruct(i).fullPath));
                continue;
            end

            % Accept normal and reversed order
            if keysForSort{j}{2}<0
                ps=keysForSort{j}{2}+length(numExtracted)+1;
            else
                ps=keysForSort{j}{2};
            end

            if length(keysForSort{j})==2
                keyIdx=str2double(numExtracted{ps});
                fileDirStruct(i).(keysForSort{j}{1})=keyIdx;
            else % For the case where key index is '3-1', '3-2', etc.
                keyIdxStr=numExtracted{ps};
                ps2=keysForSort{j}{3};
                for k=1:length(ps2)
                    if abs(ps2)>length(keyIdxStr)
%                         fprintf('warning, the digits are not long enough for extraction requirement, the path is %s\n',...
%                                 fullfile(fileDirStruct(i).fullPath));
                        return;
                    end
                    if ps2<0
                        ps2=length(keyIdxStr)+ps2+1;
                    end
                end

                keyIdx=str2double(keyIdxStr(ps2));
                fileDirStruct(i).(keysForSort{j}{1})=keyIdx;
            end
             keyIdxInfo(i,j)=keyIdx;
            
        elseif iscell(keysForSort{j}{2}) % Deal with category sort
            flagStr = 0; 
            for k = 1:length(keysForSort{j}{2})
                nStr = length(keysForSort{j}{2}{k}{1});
                tmp = strfind(fileDirStruct(i).fullPath, keysForSort{j}{2}{k}{1});
                if ~isempty(tmp) && length(tmp)>= keysForSort{j}{2}{k}{2}
                    str1Idx = tmp(keysForSort{j}{2}{k}{2}); % The position of the first character of the string
                    fileDirStruct(i).(keysForSort{j}{1})= fileDirStruct(i).fullPath(str1Idx:(str1Idx+nStr-1));
                    flagStr = k;
                    break
                end
            end
            
            if flagStr == 0
                fileDirStruct(i).(keysForSort{j}{1}) = '';
%                 fprintf('Warning, there are no such words %s in the path %s\n',...
%                         keysForSort{j}{2}{k}{1}, fullfile(fileDirStruct(i).fullPath));
                continue
            end
                         
            keyIdxInfo(i,j) = k;
        else
            fprintf('Error: wrong setup for keysForSort\n')
            return
        end
         
    end
end
keyIdxInfo=sortrows(keyIdxInfo);
fileDirStruct=fileDirStruct(keyIdxInfo(:,end));
end