function skullstrip3d(imgPath, outputPath, species, outputSurfaceType, surfacecoil)

% Get the file name and file location
[fpath,file,ext] = fileparts(imgPath);

% inputs
if ~exist('outputPath','var') || isempty(outputPath)
  outputPath = fpath;
end
if ~exist('species','var') || isempty(species)
  species = '';
else
    switch species
        case 'human'
            species = '';
        case {'monkey', 'rat', 'marmoset'}
            species = sprintf(' -%s ', species);
        case 'cat'
            species = 'marmoset';
            species = sprintf(' -%s -init_radius 10 ', species); % Brain radius for cat is about 10mm     
        case 'mouse'
            species = 'rat';
            % What radius should I use? Probably ceil(min(FOV_img)/2)?
            species = sprintf(' -%s -init_radius 5', species); % Brain radius for mouse is about 5mm
        otherwise
            warning('Unknow species. Try default setting.')
            species = '';
    end
end
if ~exist('outputSurfaceType','var') || isempty(outputSurfaceType)
    outputSurfaceFlag = 0;
elseif ismember(outputSurfaceType, {'fs','fsp','sf','vec','stl','mni','gii'})
    outputSurfaceFlag = 1;
else
    error('Unknown surface data type');
end
if ~exist('surfacecoil','var') || isempty(surfacecoil)
    surfacecoil = '';
else
    surfacecoil = '-surface_coil';
end

outputPrefix = fullfile(outputPath, [file,'_bet']);
outputSurfacePrefix = fullfile(outputPath, [file,'_sf']); 


% Check image 
nii = load_untouch_nii(imgPath);
img = nii.img;
imgsize = nii.hdr.dime.pixdim(2:5); 
imgdim = nii.hdr.dime.dim(2:(1+nii.hdr.dime.dim(1))); 

% If a dimension is smaller than 20, we need to pad img to make it large
% enough. Note we choose to use size at least 20x20x20. Is it enough?
paddingsize = ceil(max([0,0,0],[20,20,20]-imgdim)/2);
imgtmp = padarray(img, paddingsize,'replicate');

% Brain radius
% brainradius = ceil(min(imgsize(1:3).*size(imgtmp))/2); % mm

% get temporary filenames
tmp1 = [tempname,'.nii']; tmp2 = tempname; 

% save to tmp1
save_nii(make_nii(imgtmp, imgsize),tmp1);

% Do it. Note that the output is a normalized volume (-norm-vol)
if outputSurfaceFlag
    unix_wrapper(sprintf(['3dSkullStrip %s -norm_vol ', ...
             ' -input %s ', ...
             ' -prefix %s ',...
             ' %s ',...
             ' -o_%s %s'],surfacecoil,tmp1, tmp2, species, outputSurfaceType, outputSurfacePrefix),0,0);


else
    unix_wrapper(sprintf(['3dSkullStrip %s -norm_vol ', ...
             ' -input %s ', ...
             ' -prefix %s ',...
             ' %s '],surfacecoil,tmp1, tmp2, species),0,0);

end

% Change data format
if exist([tmp2,'+orig.HEAD'],'file')
    unix_wrapper(sprintf('3dAFNItoNIFTI -prefix %s.nii %s+orig ', tmp2, tmp2),0,0);
    if  exist(sprintf('%s.nii', tmp2),'file')
        niitmp = load_nii(sprintf('%s.nii', tmp2));
        % Replace the image in nii
        nii.img = niitmp.img(paddingsize(1)+1:end-paddingsize(1), ...
                             paddingsize(2)+1:end-paddingsize(2), ...
                             paddingsize(3)+1:end-paddingsize(3));


        save_untouch_nii(nii,[outputPrefix,ext]); % This is the 3dskullstrip output (normalized volume)

        % Also output the masked original image
        nii.img = (nii.img~=0).*img;
        save_untouch_nii(nii,[outputPrefix,'Orig',ext]);

    end
        
else
    save_untouch_nii(nii,[outputPrefix,ext]); % Save back the original data
    save_untouch_nii(nii,[outputPrefix,'Orig',ext]);
    fprintf(sprintf('3dSkullStrip failed on %s. Please try manual operation.\n', [file,ext]));
end

% Remove temp files
unix_wrapper(sprintf('rm %s* %s*', tmp1, tmp2),0,0);

