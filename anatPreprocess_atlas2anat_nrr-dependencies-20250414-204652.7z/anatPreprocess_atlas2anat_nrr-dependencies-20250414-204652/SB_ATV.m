function u = SB_ATV(g,mu)
% Split Bregman Anisotropic Total Variation Denoising
%
%   u = arg min_u 1/2||u-g||_2^2 + mu*ATV(u)
%   
%   g : noisy image
%   mu: regularisation parameter
%   u : denoised image
%
% Refs:
%  *Goldstein and Osher, The split Bregman method for L1 regularized problems
%   SIAM Journal on Imaging Sciences 2(2) 2009
%  *Micchelli et al, Proximity algorithms for image models: denoising
%   Inverse Problems 27(4) 2011
%
% Benjamin Trémoulhéac
% University College London
% b.tremoulheac@cs.ucl.ac.uk
% April 2012

% zw Modified: Since the original algorithm only works for square images, I
% will zero pad the image if it is not square. In the future, more general
% functions should be used.
imgSize = max(size(g,1), size(g,2));
padSize = round([imgSize-size(g,1), imgSize-size(g,2)]/2);
g = padarray(g,padSize,'symmetric');
resSize = [imgSize, imgSize]-size(g);
g = g(1:end+resSize(1),1:end+resSize(2));

g = g(:);
n = length(g);
[B, Bt, BtB] = DiffOper(sqrt(n));
b = zeros(2*n,1);
d = b;
u = g;
err = 1;k = 1;
tol = 1e-4;
lambda = 1;
while err > tol
    % fprintf('it. %g ',k-1); 
    up = u;
    [u,~] = cgs(speye(n)+BtB, g-lambda*Bt*(b-d),1e-5,100); 
    Bub = B*u+b;
    d = max(abs(Bub)-mu/lambda,0).*sign(Bub);
    b = Bub-d;
    err = norm(up-u)/norm(u);
    %fprintf('err=%g \n',err);
    k = k+1;
end
% fprintf('it. %g ',k-1); fprintf('err=%g \n',err);
% fprintf('Stopped because norm(up-u)/norm(u) <= tol=%.1e\n',tol);


u = reshape(u, [imgSize, imgSize]);
u = u(padSize(1)+1:end-padSize(1)-resSize(1), padSize(2)+1:end-padSize(2)-resSize(2));
end

function [B, Bt, BtB] = DiffOper(N)
D = spdiags([-ones(N,1) ones(N,1)], [0 1], N,N+1);
D(:,1) = [];
D(1,1) = 0;
B = [ kron(speye(N),D) ; kron(D,speye(N)) ];
Bt = B';
BtB = Bt*B;
end
