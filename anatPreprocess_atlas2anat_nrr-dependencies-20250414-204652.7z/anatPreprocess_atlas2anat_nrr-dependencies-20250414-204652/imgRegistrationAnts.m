function imgRegistrationAnts(fixedImgPath, movingImgPath, outputPath, transformType, initialTransform, imgMask,outputPrefix)

% Get the file name and file location
[fpath,file,ext] = fileparts(movingImgPath);

% inputs
if ~exist('outputPath','var') || isempty(outputPath)
  outputPath = fpath;
end
if ~exist('transformType','var') || isempty(transformType)
  transformType = 'Linear';
end
if ~exist('initialTransform','var') || isempty(initialTransform)
  initialTransform = '';
end
if ~exist('imgMask','var') || isempty(imgMask)
  imgMask = '';
end
if ~exist('outputPrefix','var') || isempty(outputPrefix)
  outputPrefix = '';
end
outputPrefix = [fullfile(outputPath,'coreg_'),file,outputPrefix];


if ~iscell(imgMask)
  imgMask = {imgMask};
end
if length(imgMask) == 1
  imgMask = [{''},imgMask]; % The first one is the mask for fixed image and second one is for moving image
end

maskcall = sprintf(' -x [%s, %s] ',imgMask{1},imgMask{2}); % Extract brain rather than using this option.


outputCall = sprintf(' --output [ %s,%s.nii] ',outputPrefix,outputPrefix);

% The use of the initial stage will change the origin of the data or the
% center of rotation when affine matrix is estimated.
% If chosen the third input to be 1, then the first two time points will be
% lost. This could be caused by the intensity origin estimation is slightly
% different for each 3D image.
if isempty(initialTransform)
    initialStage = sprintf(' --initial-moving-transform [ %s, %s, 0] ', fixedImgPath, movingImgPath); % Here 1 means using the intensity and 0 means using geometric center of the images
else
    initialStage = sprintf(' --initial-moving-transform %s ', initialTransform);
end

% Note on shrink-factors: the voxel size in each dimension should not be
% smaller than FOV/32. For example, if FOV = 24x12x6mm and voxsize =
% 0.1x0.1x0.5mm, the minimum voxel size for processing is voxsizemin = 
% [24,12,6]./[32,32,32] = [0.75,0.375,0.1875] mm. If the shrink-factors is
% 8x4x2x1, then the voxel size in each iteration is min(min(voxsize)*shrink-factor,voxsizemin):
% for shrink-factor = 8: min(min([0.1,0.1,0.5])*8,[0.75,0.375,0.1875]) = [0.75,0.375,0.1875]
% for shrink-factor = 4: min(min([0.1,0.1,0.5])*4,[0.75,0.375,0.1875]) = [0.4,0.375,0.1875]
% for shrink-factor = 2: min(min([0.1,0.1,0.5])*2,[0.75,0.375,0.1875]) = [0.2,0.2,0.1875]
% for shrink-factor = 1: min(min([0.1,0.1,0.5])*1,[0.75,0.375,0.1875]) = [0.1,0.1,0.1]

% As to smoothing-sigmas, sigma = (outputVoxsize/voxsize-1)*0.2 (and sigma >= 0)
% for smoothing-sigma = 3: sigma =([0.75,0.375,0.1875]./[0.1,0.1,0.5]-1)*0.2 = [1.3, 0.55, 0]
% for smoothing-sigma = 2: sigma =([0.4,0.375,0.1875]./[0.1,0.1,0.5]-1)*0.2 = [0.6, 0.55, 0]
% for smoothing-sigma = 1: sigma =([0.2,0.2,0.1875]./[0.1,0.1,0.5]-1)*0.2 = [0.2, 0.2, 0]
% for smoothing-sigma = 0: sigma =([0.1,0.1,0.1]./[0.1,0.1,0.5]-1)*0.2 = [0, 0, 0]


% rigidStage = sprintf([' --transform Rigid[0.1] ', ... % The gradient step. Smaller steps can be more accurate but take longer, and may converge prematureally. Optimal range [0.1, 0.25]
%                       ' --metric MI[ %s , %s , 1, 32, Regular, 1 ] ', ... % [fixed, moving, weight, bins, sampling, samplingPercentage]
%                       ' --convergence [1000x500x250x100,1e-6,10] ', ... % 4 levels (multi-resolution steps) with a maximum number of iterations of 1000, 500, 250, 100
%                       ' --shrink-factors 8x4x2x1 ', ... % Srhink the image volume by 8, 4, 2, 1 voxels along all dimensions
%                       ' --smoothing-sigmas 3x2x1x0vox '], fixedImgPath, movingImgPath); % Smoothing the images with a Gaussian kernel std of 3,2,1,0 voxels

rigidStage = sprintf([' --transform Rigid[0.1] ', ... % The gradient step. Smaller steps can be more accurate but take longer, and may converge prematureally. Optimal range [0.1, 0.25]
                      ' --metric CC[ %s , %s , 1, 4, Regular, 1 ] ', ... % [fixed, moving, weight, bins, sampling, samplingPercentage]
                      ' --convergence [100x70x50x20,1e-6,10] ', ... % 4 levels (multi-resolution steps) with a maximum number of iterations of 1000, 500, 250, 100
                      ' --shrink-factors 8x4x2x1 ', ... % Srhink the image volume by 8, 4, 2, 1 voxels along all dimensions, 
                      ' --smoothing-sigmas 3x2x1x0vox '], fixedImgPath, movingImgPath); % Smoothing the images with a Gaussian kernel std of 3,2,1,0 voxels

% affineStage = sprintf([' --transform Affine[0.1] ', ...
%                       ' --metric MI[ %s , %s , 1, 32, Regular, 0.5 ] ', ... % [fixed, moving, weight, bins, sampling, samplingPercentage]
%                       ' --convergence [1000x500x250x100,1e-6,10] ', ... % 4 levels (multi-resolution steps) with a maximum number of iterations of 1000, 500, 250, 100
%                       ' --shrink-factors 8x4x2x1 ', ... % Srhink the image volume by 8, 4, 2, 1 voxels along all dimensions
%                       ' --smoothing-sigmas 3x2x1x0vox '], fixedImgPath, movingImgPath); % Smoothing the images with a Gaussian kernel std of 3,2,1,0 voxels

affineStage = sprintf([' --transform Affine[0.1] ', ...
                      ' --metric CC[ %s , %s , 1, 4, Regular, 1 ] ', ... % [fixed, moving, weight, bins, sampling, samplingPercentage]
                      ' --convergence [100x70x50x20,1e-6,10] ', ... % 4 levels (multi-resolution steps) with a maximum number of iterations of 1000, 500, 250, 100
                      ' --shrink-factors 8x4x2x1 ', ... % Srhink the image volume by 8, 4, 2, 1 voxels along all dimensions
                      ' --smoothing-sigmas 3x2x1x0vox '], fixedImgPath, movingImgPath); % Smoothing the images with a Gaussian kernel std of 3,2,1,0 voxels


synStage = sprintf([' --transform SyN[0.2,0,0] ', ... % [gradientStep, updateFieldVarianceInVoxelSpace, totalFieldVarianceInVoxelSpace]
                      ' --metric CC[ %s , %s , 1, 4, Regular, 1 ] ', ... % [fixed, moving, weight, radius]
                      ' --convergence [100x70x50x20,1e-6,10] ', ... % 4 levels (multi-resolution steps) with a maximum number of iterations of 100, 70, 50, 20
                      ' --shrink-factors 8x4x2x1 ', ... % Srhink the image volume by 8, 4, 2, 1 voxels along all dimensions
                      ' --smoothing-sigmas 3x2x1x0vox '], fixedImgPath, movingImgPath); % Smoothing the images with a Gaussian kernel std of 3,2,1,0 voxels

if strcmpi(transformType, 'Linear')
    stages = [initialStage, rigidStage, affineStage];  % Only affine transformation
elseif strcmpi(transformType, 'Rigid')
    stages = [initialStage, rigidStage];  % Only rigid transformation
elseif strcmpi(transformType, 'RigidSyN')
    stages = [initialStage, rigidStage, synStage];  % Only rigid transformation
elseif strcmpi(transformType, 'Non-linear')
    stages = [initialStage, rigidStage, affineStage, synStage];
elseif strcmpi(transformType, 'Non-linearOnly')
    stages = [initialStage, synStage];
end

%tic
unix_wrapper(['antsRegistration --dimensionality 3 --float 0 ', ...
             ' --interpolation BSpline[5] ', ... % Which interpolation should be used? linear, BSpline[5] or other methods
             ' --use-histogram-matching 0 ', ...
             ' --winsorize-image-intensities [0.005,0.995] ', ...
             ' --random-seed 25 ', ...
             stages, maskcall, outputCall],0);

%toc

% Remove any negative and small numbers caused probably by the BSpline interpolation
nii = load_nii([outputPrefix,'.nii']);
nii.img(nii.img<0) = 0;
nii.img = nii.img.*automask(nii.img,0.01);
save_nii(nii,[outputPrefix,'.nii']);

