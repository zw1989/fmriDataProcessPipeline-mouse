clear; close all; clc;

% Anatomical data preprocess

%% Data path

projectPath = '/home/ibrain-raid2/weizhu-data/data/9-laminarFmriPipeline-mouse-9T';

% Raw anatomical data path
rawDataPath = fullfile(projectPath, 'raw-data');

% Raw data list
rawAnatList = searchAndSortFiles(rawDataPath, ...             % File path
                                 '(fsems|flair|gems)(.+).nii', ...              % File name pattern, regular expression
                                 {{'type', {{'control',1}, {'mutant',1},{'treated',1}}}, {'sex', {{'M',1}, {'F',1}}},...
                                 {'month', 4}, {'mouse',5},{'run',6}, {'seq',{{'fse',1},{'gems',1},{'flair',1}}}}, ... % Data structure information
                                 0);                         % Functional data indicator

% Subject number
subLabelAnat = cellfun(@(x,y,z,k) [x,y,num2str(z),'-m',num2str(k)], {rawAnatList.type}, {rawAnatList.sex}, {rawAnatList.month},{rawAnatList.mouse} ,'UniformOutput',0);
[subIDanat,ia,ic] = unique(subLabelAnat.');

% Count the number of anats for each subject
a_counts = accumarray(ic,1);

% Only keep the fsems anat image for each subject. (Remove 'gems')
rawAnatList(ismember(subLabelAnat, subIDanat(a_counts>1))&ismember({rawAnatList.seq},'gems'))=[];
subLabelAnat = cellfun(@(x,y,z,k) [x,y,num2str(z),'-m',num2str(k)], {rawAnatList.type}, {rawAnatList.sex}, {rawAnatList.month},{rawAnatList.mouse} ,'UniformOutput',0).';

% For testing only
% rawAnatList = rawAnatList([5,6,12,17,18,23]);
% rawAnatList = rawAnatList([12]); % controlF8-m1
% rawAnatList = rawAnatList([8]); subIDanat = length(rawAnatList); % controlF5-m1

%% Preparation 
% Anat image file paths
% Make scan paths in intermediate data directory for each subject and scan
anatIntermPath = cellfun(@(x,y) fullfile(strrep(x,'raw-data',['derivatives-nrr',filesep,'intermediate-data',filesep,'pca']),y), {rawAnatList.dir}.',{rawAnatList.imgName}.','UniformOutput',0);
cellfun(@mkdirquiet, anatIntermPath); % Target folder

anatPath = {rawAnatList.fullPath};
refImgPath = cellfun(@(x) fullfile(stripfile(stripfile(x)),'func','epiRef.nii'),anatIntermPath,'UniformOutput',0);
atlasTemplatePath = fullfile(projectPath, '/derivatives-nrr/preprocessed-data/atlas/atlasTemplate.nii');


%% Do it
% More inputs
initran_atlasPath = '';
atlas2anatorig = 1;
initran_anatPath = '';
anat2func = 1;
atlasRegType = 'Non-linear';
%atlasRegType = 'Rigid';
anatRegType = 'Rigid';
%anatRegType = 'Non-linear';
anatRegType = 'RigidSyN';

% Do it
tStart = tic;
parfor isub = 1:length(rawAnatList)
%for isub = 5%1:length(rawAnatList)
  
  fprintf('*** Processing subject %s: \n',subLabelAnat{isub});
  
  % Note: controlM8-m2 has gems as anatomical image while controlF8-m1 has
  % flair, which has different contrast than fse. The extensive testing
  % shows that these two data have better registration results when only
  % NLM denoising is applied. 
  if ismember(subLabelAnat{isub}, {'controlM8-m1','controlM8-m2','controlF8-m1'})
    wantDenoise = [1,0]; % only NLM denoise 
  else
    wantDenoise = [1,1]; % NLM denoise + image enhancement
  end

  preprocessanat2(anatIntermPath{isub}, anatPath{isub}, '', 'mouse', ...
                  atlasTemplatePath,initran_atlasPath,atlas2anatorig,atlasRegType,[],...
                  refImgPath{isub}, initran_anatPath, anat2func, anatRegType,[],...
                  [],wantDenoise,1)

%     preprocessanat2(anatIntermPath{isub}, anatPath{isub}, '', 'mouse', ...
%                         '',initran_atlasPath,atlas2anatorig,atlasRegType,[],...
%                         refImgPath{isub}, initran_anatPath,anat2func,anatRegType,[],...
%                         [],1,1); % Test anat2func

%     preprocessanat2(anatIntermPath{isub}, anatPath{isub}, '', 'mouse', ...
%                     atlasTemplatePath,initran_atlasPath,atlas2anatorig,atlasRegType,[],...
%                     '', initran_anatPath, anat2func, anatRegType,[],...
%                     [],1,1); % Test atlas2anat


end
toc(tStart);

%% OLD: Deal with some special cases
% % As controlM8-m1 and controlM8-m2, controlF8-m1 seem to have better registration results
% % without brain exactration (BET), we rerun the code here for these data
% % and use the unskullstripped image as the fixed image for atlas to
% % register to. In addition, controlF8-m1 has flair anat image with a
% % relatively low SNR. We used non-local means to denoise it first then do
% % the registration.
% % rawAnatList = rawAnatList([5,6]);
% atlas2anatorig = 1;
% for isub = 12 % [6,12,13]
%     preprocessanat2(anatIntermPath{isub}, anatPath{isub}, '', 'mouse', ...
%                     atlasTemplatePath,initran_atlasPath,atlas2anatorig,atlasRegType,[],...
%                     refImgPath{isub}, initran_anatPath,anat2func,anatRegType,[],...
%                     [],0)
% 
% end

% % Do it
% tic
% preprocessanat(anatIntermPath, anatPath, [], 'mouse', refImgPath, atlasTemplatePath,1,1)
% toc

% rawAnatList = rawAnatList([12]);
% % Do it
% tic
% preprocessanat(anatIntermPath, anatPath, [], 'mouse', refImgPath, atlasTemplatePath,1,1,1)
% toc
