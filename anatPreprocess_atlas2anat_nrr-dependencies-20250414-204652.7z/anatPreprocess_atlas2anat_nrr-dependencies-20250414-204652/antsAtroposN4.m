function antsAtroposN4(imgPath, imgMaskPath, outputPath, numSeg,posteriorLabelForN4Weight,priorSegWeight)

% Get the file name and file location
[fpath,file,ext] = fileparts(imgPath);

if isempty(fpath)
  fpath = pwd;
end

% inputs
if ~exist('imgMaskPath','var') || isempty(imgMaskPath)
  imgMaskPath = '';
end
if ~exist('outputPath','var') || isempty(outputPath)
  outputPath = fpath;
end
if ~exist('numSeg','var') || isempty(numSeg)
  numSeg = 4; % Here we use 4 levels, from low to high, background->csf->GW->WM
end
if ~exist('posteriorLabelForN4Weight','var') || isempty(posteriorLabelForN4Weight)
  posteriorLabelForN4Weight = [numSeg, numSeg-1]; 
end
if ~exist('priorSegWeight','var') || isempty(priorSegWeight)
  priorSegWeight = 0.25;
end

outputPrefix = fullfile(outputPath,file);

yOpt = '';
for ii = 1:length(posteriorLabelForN4Weight)
  yOpt = sprintf('%s -y %s', yOpt, num2str(posteriorLabelForN4Weight(ii)));
end

unix_wrapper(sprintf(['antsAtroposN4.sh -d 3 -a ''%s'' ', ...
             ' -x ''%s'' ', ...
             ' -c %s ', ...
             ' %s ', ...
             ' -w %s ', ...
             ' -o ''%s_'' ', ...
             ' -r ''[ 0.1,1x1x1 ]'' ', ...
             ' -m 2 -n 2 '],imgPath, imgMaskPath, num2str(numSeg), yOpt, num2str(priorSegWeight),outputPrefix),0);

% Get segmentation data list
segList = searchAndSortFiles(outputPath, ...             % File path
                             [outputPrefix,'_Segmentation'], ...              % File name pattern, regular expression
                             { {'type',{{'N4',1},{'Convergence',1},{'Posteriors',1}} } }, ... % Data structure information
                             0);  

% Get useful data
segDataPath = {segList(~ismember({segList.type},{'Convergence','N4'})).fullPath}';

% Load, combine and save data
nii = cellfun(@(x) load_untouch_nii(gunziptemp(x)),segDataPath,'UniformOutput',0);
volsize = nii{1}.hdr.dime.pixdim(2:5); % mm
segdim = nii{1}.hdr.dime.dim(2:5);
segData = catcell(4,cellfun(@(x) single(x.img), nii,'UniformOutput',0));
save_nii(make_nii(segData,volsize,round(segdim(1:3)/2+1)),[outputPrefix,'_seg.nii']); % Save data

% Clean data
cellfun(@delete, {segList.fullPath});
