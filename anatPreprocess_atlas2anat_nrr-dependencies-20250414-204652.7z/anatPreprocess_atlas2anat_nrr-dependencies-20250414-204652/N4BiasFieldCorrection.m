function N4BiasFieldCorrection(imgPath, imgWeightPath, outputPath, intialSpacing, shrinkfactor)

% Get the file name and file location
[fpath,file,ext] = fileparts(imgPath);

% inputs
if ~exist('imgWeightPath','var') || isempty(imgWeightPath)
  imgWeightPath = '';
end
if ~exist('outputPath','var') || isempty(outputPath)
  outputPath = fpath;
end
if ~exist('intialSpacing','var') || isempty(intialSpacing)
  intialSpacing = 8; % mm, Here we use 4 levels, the finest spacing will be 8/2^4 = 0.5 mm
end
if ~exist('shrinkfactor','var') || isempty(shrinkfactor)
  shrinkfactor = 2;
end

outputPrefix = fullfile(outputPath,[file,'_bc']);

unix_wrapper(sprintf(['N4BiasFieldCorrection --image-dimensionality 3 --shrink-factor %s ', ...
             ' -- bspline-fitting [ %s, 3 ] ', ...
             ' --convergence [ 100x100x50x50, 0 ] ', ...
             ' --input-image %s ', ...
             ' --weight-image %s ', ...
             ' --output [%s, %s] '],num2str(shrinkfactor), num2str(intialSpacing), imgPath,imgWeightPath,[outputPrefix,ext],fullfile(outputPath,'biasmap.nii')),0);



