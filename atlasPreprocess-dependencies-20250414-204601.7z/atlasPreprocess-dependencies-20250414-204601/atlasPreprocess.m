clear; close all; clc;

% Mouse brain atlas from Allen institute data preprocess

%% Atlas path

mouseAtlasPath = '/home/ibrain-raid2/weizhu-data/zwDataProc/brainAtlas/AllenMouse2017ConvertedToNifti';
mouseAtlas2022Path = '/home/ibrain-raid2/weizhu-data/zwDataProc/brainAtlas/AllenMouse2022'; % New release in 2023 with updated annotation in 10 um resolution

preprocessedPath = '/home/ibrain-raid2/weizhu-data/data/9-laminarFmriPipeline-mouse-9T/derivatives-nrr/preprocessed-data/atlas';
preprocessedPath = '/home/ibrain-raid2/weizhu-data/data/9-laminarFmriPipeline-mouse-9T/derivatives-rr/preprocessed-data/atlas';
mkdirquiet(preprocessedPath);

% Mouse brain average template path. $ resolutions are available: 10um,
% 25,50,100um isotropic. Here we choose 100um one
brainTemplatePath = fullfile(mouseAtlasPath,'averageTemplate','average_template_100.nii.gz');

% Mouse brain annotation or atlas
% brainAnnotationPath = fullfile(mouseAtlasPath,'annotation2017','annotation_100_modified_csfWMcerebellumUncombined.nii');
brainAnnotationPath = fullfile(mouseAtlas2022Path,'annotation_100_modified.nii');

% Structure ID of the annotation images
% structureFilePath = fullfile(mouseAtlasPath,'annotation2017','structures_modified_csfWMcerebellumUncombined.csv');
structureFilePath = fullfile(mouseAtlas2022Path,'structures_modified.csv');
copyfile(structureFilePath,preprocessedPath);

%% Load template image data
nii = load_nii(gunziptemp(brainTemplatePath));
voxsize = nii.hdr.dime.pixdim(2:4); % mm
brainTemplate = nii.img;
brainTemplate = rot90(permute(brainTemplate,[3,1,2]),1); % Orientaion correction

% Get atlas mask
templateMask = uint16(automask(brainTemplate,0.1));
figure;imshow(makeMontage(templateMask,0,0,'xy'),[])

% Mask out the template
brainTemplateMasked = brainTemplate .* templateMask;
figure;imshow(makeMontage(brainTemplateMasked,0,0,'xy'),[]);

% We only need part of the brain for registration. If the whole brain is
% used, the registration may fail.
% sliceSelect = 61:225; % For voxel size 50 um
sliceSelect = 31:105; % For voxel size 100 um
%sliceSelect = 51:105; % For voxel size 100 um
brainTemplateMaskedSS = brainTemplateMasked(:,:,sliceSelect);

% Save the atlas template, put the origin of the image to be the geomatric center
if ~exist(fullfile(preprocessedPath,'atlasTemplate.nii'),'file')
save_nii(make_nii(brainTemplateMaskedSS, voxsize,size(brainTemplateMaskedSS)/2+1),fullfile(preprocessedPath,'atlasTemplate.nii'));
end

%% Load annotation data

nii = load_nii(gunziptemp(brainAnnotationPath));
voxsize = nii.hdr.dime.pixdim(2:4); % mm
brainAnnotation = nii.img;
brainAnnotation = rot90(permute(brainAnnotation,[3,1,2]),1); % Orientaion correction

figure;imshow(makeMontage(brainAnnotation,0,0,'xy'),[0,1000]);

brainAnnotationSS = brainAnnotation(:,:,sliceSelect);

% Save the atlas annotation, put the origin of the image to be the geomatric center
if ~exist(fullfile(preprocessedPath,'atlasAnnotation.nii'),'file')
save_nii(make_nii(brainAnnotationSS, voxsize,size(brainAnnotationSS)/2+1),fullfile(preprocessedPath,'atlasAnnotation.nii'));
end

%% Get brain masks based on the brain annotation 

% Read stucture info
%roiList = readtable(fullfile(preprocessedPath,"structures_modified_csfWMcerebellumUncombined.csv"));
roiList = readtable(fullfile(preprocessedPath,"structures_modified.csv"));

% Find the top hierarchical structures. These include the grey matter,
% ventricular system, and the fiber tracts
idxS1 = find(roiList.depth==1);
s1 = roiList(idxS1,:);

gmMask = ismember(brainAnnotationSS,roiList.id(idxS1(1):idxS1(2)-1));
wmMask = ismember(brainAnnotationSS,roiList.id(idxS1(2):idxS1(3)-1));
csfMask = ismember(brainAnnotationSS,roiList.id(idxS1(3):end));

figure;imshow(makeMontage(csfMask,0,0,'xy'),[]);

% Save the tissue masks
% if ~exist(fullfile(preprocessedPath,'atlasTissueMasks.nii'),'file')
% save_nii(make_nii(uint16(cat(4,gmMask,wmMask,csfMask)), voxsize,size(brainAnnotationSS)/2+1),fullfile(preprocessedPath,'atlasTissueMasks.nii'));
% end
if ~exist(fullfile(preprocessedPath,'atlasTissueMasks.nii'),'file')
save_nii(make_nii(uint16(cat(4,gmMask,wmMask,csfMask)), voxsize,size(brainAnnotationSS)/2+1),fullfile(preprocessedPath,'atlasTissueMasks.nii'));
end


%% Divide the atlas annotation to left and right brain (for all structures?)
% To divide atlas to left and right brain, we need to reassign a value to
% each brain region.
rng('default')
rng(25) % Fix the random generator seed

% New roi lists for right brain: change each column accordingly
roiListRight = roiList; 
roiListRight.id = 2*randperm(size(roiListRight,1))'-1; % Introduce some randomness
roiListRight.name = cellfun(@(x) [x,', right'], roiListRight.name,'UniformOutput',0);
roiListRight.acronym = cellfun(@(x) [x,'r'], roiListRight.acronym,'UniformOutput',0);
% Change the structure_id_path, this is a bit complicated
[~,idIdx] = cellfun(@(x) ismember(str2double(regexp(x,'\d+','match')),roiList.id), roiListRight.structure_id_path,'UniformOutput',0);
roiListRight.structure_id_path = cellfun(@(x) char(fullfile('/997/',join(string(roiListRight.id(x(x~=0))),'/'),'/')), idIdx,'UniformOutput',0);

% Do the same for left brain
roiListLeft = roiList; 
roiListLeft.id = roiListRight.id+1;
roiListLeft.name = cellfun(@(x) [x,', left'], roiListLeft.name,'UniformOutput',0);
roiListLeft.acronym = cellfun(@(x) [x,'l'], roiListLeft.acronym,'UniformOutput',0);
% Change the structure_id_path, this is a bit complicated
[~,idIdx] = cellfun(@(x) ismember(str2double(regexp(x,'\d+','match')),roiList.id), roiListLeft.structure_id_path,'UniformOutput',0);
roiListLeft.structure_id_path = cellfun(@(x) char(fullfile('/997/',join(string(roiListLeft.id(x(x~=0))),'/'),'/')), idIdx,'UniformOutput',0);

% Combine Right and left brain roi list and sort rows based on the first
% column (id)
roiRightLeftList = [roiList;roiList]; % Just initialize
roiRightLeftList(1:2:size(roiRightLeftList,1),:) = roiListRight;
roiRightLeftList(2:2:size(roiRightLeftList,1),:) = roiListLeft;

% Now assign id to the corresponding brain area in annotation image
atlasRightLeft = brainAnnotationSS; dimatlas = size(atlasRightLeft);
roiListImg = unique(atlasRightLeft);
for iroi=1:size(roiListImg,1)
    % Get the roi name from the new list containing the same name
    tmpIdx = find(matches(strrep(roiRightLeftList.name,', right',''), roiList.name(roiList.id==roiListImg(iroi))));
    
    if isempty(tmpIdx)
        continue
    end

    % Get the substitutes of the area with the same roi ID
    [x, y, z] = ind2sub(dimatlas, find(brainAnnotationSS==roiListImg(iroi)));
    
    % Divide some areas to left and right parts based on the column which the middle is x=57.
    midlineIdx = fix(dimatlas(1)/2);
    atlasRightLeft(sub2ind(dimatlas,x(x<=midlineIdx),y(x<=midlineIdx),z(x<=midlineIdx))) = roiRightLeftList.id(tmpIdx); % right? Here assume the front of mouse brain is near us.
    atlasRightLeft(sub2ind(dimatlas,x(x>midlineIdx),y(x>midlineIdx),z(x>midlineIdx))) = roiRightLeftList.id(tmpIdx+1);

end
figure;imshow(makeMontage(atlasRightLeft,1,0,'xy'),[0,2000]);

% Save the new atlas annotation, put the origin of the image to be the geomatric center
% if ~exist(fullfile(preprocessedPath,'atlasAnnotationRightLeft_csfWMcerebellumUncombined.nii'),'file')
% save_nii(make_nii(atlasRightLeft, voxsize,size(atlasRightLeft)/2+1),fullfile(preprocessedPath,'atlasAnnotationRightLeft_csfWMcerebellumUncombined.nii'));
% writetable(roiRightLeftList, fullfile(preprocessedPath, 'structures_modifiedRightLeft_csfWMcerebellumUncombined.csv'))
% end
if ~exist(fullfile(preprocessedPath,'atlasAnnotationRightLeft.nii'),'file')
save_nii(make_nii(atlasRightLeft, voxsize,size(atlasRightLeft)/2+1),fullfile(preprocessedPath,'atlasAnnotationRightLeft.nii'));
writetable(roiRightLeftList, fullfile(preprocessedPath, 'structures_modifiedRightLeft.csv'))
end
