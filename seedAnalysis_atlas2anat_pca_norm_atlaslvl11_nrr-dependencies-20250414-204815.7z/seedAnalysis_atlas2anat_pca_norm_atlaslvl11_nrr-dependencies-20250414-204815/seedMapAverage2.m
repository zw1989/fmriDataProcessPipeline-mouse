function averagedMap = seedMapAverage2(seedMap)

averagedMap = seedMap{1};
ndata = length(seedMap);
ndim = length(size(seedMap{1}(1).seedmapAvg));

for iSeed = 1:length(seedMap{1})
    averagedMap(iSeed).seedmapAvg = 0;
    averagedMap(iSeed).seedmapStd = 0;

    tmpData = [];

    for iData = 1:ndata

        tmpData = cat(ndim+1, tmpData, seedMap{iData}(iSeed).seedmapAvg);
        averagedMap(iSeed).seedmapAvg = averagedMap(iSeed).seedmapAvg + seedMap{iData}(iSeed).seedmapAvg;       
    end
    
    averagedMap(iSeed).seedmapAvg = averagedMap(iSeed).seedmapAvg ./ndata;
    averagedMap(iSeed).seedmapStd = std(tmpData,0,ndim+1);

    % One-sample t-test
    tmap = (averagedMap(iSeed).seedmapAvg-0)./(averagedMap(iSeed).seedmapStd/sqrt(ndata)); 
    averagedMap(iSeed).pmap = 1-tcdf(tmap,ndata-1);
end