classdef circularGraph < handle
% CIRCULARGRAPH Plot an interactive circular graph to illustrate connections in a network.
%
%% Syntax
% circularGraph(X)
% circularGraph(X,'PropertyName',propertyvalue,...)
% h = circularGraph(...)
%
%% Description
% A 'circular graph' is a visualization of a network of nodes and their
% connections. The nodes are laid out along a circle, and the connections
% are drawn within the circle. Click on a node to make the connections that
% emanate from it more visible or less visible. Click on the 'Show All'
% button to make all nodes and their connections visible. Click on the
% 'Hide All' button to make all nodes and their connections less visible.
%
% Required input arguments.
% X : A symmetric matrix of numeric or logical values. It can also be any
% size of matrix. 
%
% Optional properties.
% Colormap : A N by 3 matrix of [r g b] triples, where N is the 
%            length(adjacenyMatrix).
% Label    : A cell array of N strings.
% NormValue: A numeric used to normalize adjacency matrix. Default is [],
%            meaning normalize input matrix by its absolute maximum.
%            Setting a value is useful when you do comparison between two
%            matrices where their maximum values are different.
%
% Examples:
% myColorMap = brewermap(length(AavgSub),"-Spectral");
% myColorMap = [1 0.5 0.1]; % Orange
% figure; circularGraph([1:20],'Colormap',myColorMap);
%
%%
% Copyright 2016 The MathWorks, Inc.
  properties
    Node = node(0,0); % Array of nodes
    ColorMap;         % Colormap
    Label;            % Cell array of strings
    NormValue;        % A numberic used to normalize adjacency matrix, which changes the width of the connection lines (or edges)
%     ShowButton;       % Turn all nodes on
%     HideButton;       % Turn all nodes off
  end
  
  methods
    function this = circularGraph(adjacencyMatrix,varargin)
      % Constructor
      p = inputParser;
      
      % Set input default values
      defaultColorMap = parula(length(adjacencyMatrix));
      defaultLabel = cell(length(adjacencyMatrix));
      for ii = 1:length(defaultLabel)
        defaultLabel{ii} = num2str(ii);
      end
      defaultNormValue = [];
      
      % Add them to the constructor
      addRequired(p,'adjacencyMatrix',@(x)(isnumeric(x) || islogical(x)));
      addParameter(p,'ColorMap',defaultColorMap,@(colormap) size(colormap,1) == length(adjacencyMatrix)||size(colormap,1)==1);
      addParameter(p,'Label'   ,defaultLabel   ,@iscell);
      addParameter(p,'NormValue',defaultNormValue,@isnumeric);
      
      % Get user inputs or default values
      parse(p,adjacencyMatrix,varargin{:});
      this.ColorMap = p.Results.ColorMap;
      this.Label    = p.Results.Label;
      this.NormValue= p.Results.NormValue;
      
%       this.ShowButton = uicontrol(...
%         'Style','pushbutton',...
%         'Position',[0 40 80 40],...
%         'String','Show All',...
%         'Callback',@circularGraph.showNodes,...
%         'UserData',this);
%       
%       this.HideButton = uicontrol(...
%         'Style','pushbutton',...
%         'Position',[0 0 80 40],...
%         'String','Hide All',...
%         'Callback',@circularGraph.hideNodes,...3
%         'UserData',this);
      
      % Find non-zero values of s and their indices
      [row,col,v] = find(adjacencyMatrix);
      u = abs(v); % Get absolute value, indicating correlation strength
      if isempty(this.NormValue)
          this.NormValue = max(u);
      else
          this.NormValue = max(this.NormValue,max(u));
      end

      % Sort the results. This will ensure plotting lines from weakest to
      % strongest, keeping the weak connections at the bottom layers
      [u,idx] = sort(u);
      row = row(idx);
      col = col(idx);
      v = v(idx);

      % Calculate line widths based on values of s (stored in v).
      minLineWidth  = 0.5;
      lineWidthCoef = 5;
      lineWidth = u./this.NormValue;
      lineWidth = lineWidth.^2; % Use powers to make the linewidth range larger
      if sum(lineWidth) == numel(lineWidth) % all lines are the same width.
        lineWidth = repmat(minLineWidth,numel(lineWidth),1);
      else % lines of variable width.
        lineWidth = lineWidthCoef*lineWidth + minLineWidth;
      end

      % Check the length of the colormap
      if size(this.ColorMap,1) == 1 
          colormapTmp = zeros(length(v),3);

          for ic = 1:length(v)
              if v(ic) > 0
                  colormapTmp(ic,:) = this.ColorMap + (1-this.ColorMap)*(1-v(ic)/this.NormValue);
              else
                  colormapTmp(ic,:) = flip(this.ColorMap) + (1-flip(this.ColorMap))*(1+v(ic)/this.NormValue);
              end
          end
          %this.ColorMap = colormapTmp;
      end


      
      % Draw it
      fig = gcf;
      set(fig,...
        'UserData',this,...
        'CloseRequestFcn',@circularGraph.CloseRequestFcn);
      
      % Draw the nodes3
      delete(this.Node);
      t = linspace(-pi,pi,length(adjacencyMatrix) + 1).'; % theta for each node
      extent = zeros(length(adjacencyMatrix),1);
      nodeSelected = sum(adjacencyMatrix,2)~=0; % Selected node if all zeros happen in some rows
      if sum(nodeSelected) == length(adjacencyMatrix)
        nodeSelected = ones(size(nodeSelected));
      end
      for ii = 1:length(adjacencyMatrix)
        this.Node(ii) = node(cos(t(ii)),sin(t(ii))); % Function to draw node. Note node marker is a private property.
        if size(this.ColorMap,1) == 1 
            % this.Node(ii).Color = this.ColorMap;
            if nodeSelected(ii)==1
              this.Node(ii).Color = this.ColorMap;
            else
              this.Node(ii).Color = [0.6 0.6 0.6];
            end
        else
            this.Node(ii).Color = this.ColorMap(ii,:);
        end
        this.Node(ii).Label = this.Label{ii};
      end
      
      % Draw connections on the Poincare hyperbolic disk.
      %
      % Equation of the circles on the disk:
      % x^2 + y^2 
      % + 2*(u(2)-v(2))/(u(1)*v(2)-u(2)*v(1))*x 
      % - 2*(u(1)-v(1))/(u(1)*v(2)-u(2)*v(1))*y + 1 = 0,
      % where u and v are points on the boundary.
      %
      % Standard form of equation of a circle
      % (x - x0)^2 + (y - y0)^2 = r^2
      %
      % Therefore we can identify
      % x0 = -(u(2)-v(2))/(u(1)*v(2)-u(2)*v(1));
      % y0 = (u(1)-v(1))/(u(1)*v(2)-u(2)*v(1));
      % r^2 = x0^2 + y0^2 - 1
      
      for ii = 1:length(v)
        if row(ii) ~= col(ii)
          if size(this.ColorMap,1) == 1 
              edgeColor = colormapTmp(ii,:);
          else
              edgeColor = this.ColorMap(row(ii),:);
          end
          if abs(row(ii) - col(ii)) - length(adjacencyMatrix)/2 == 0 
            % points are diametric, so draw a straight line
            u = [cos(t(row(ii)));sin(t(row(ii)))];
            v = [cos(t(col(ii)));sin(t(col(ii)))];
            this.Node(row(ii)).Connection(end+1) = line(...
              [u(1);v(1)],...
              [u(2);v(2)],...
              'LineWidth', lineWidth(ii),...
              'Color', edgeColor,...
              'PickableParts','none');
          else % points are not diametric, so draw an arc
            u  = [cos(t(row(ii)));sin(t(row(ii)))];
            v  = [cos(t(col(ii)));sin(t(col(ii)))];
            x0 = -(u(2)-v(2))/(u(1)*v(2)-u(2)*v(1));
            y0 =  (u(1)-v(1))/(u(1)*v(2)-u(2)*v(1));
            r  = sqrt(x0^2 + y0^2 - 1);
            thetaLim(1) = atan2(u(2)-y0,u(1)-x0);
            thetaLim(2) = atan2(v(2)-y0,v(1)-x0);
            
            % Border
            thetaLimSorted = sort(thetaLim);
            if thetaLimSorted(2) - thetaLimSorted(1)>pi
                thetaLim(1) = thetaLimSorted(2)-2*pi;
                thetaLim(2) = thetaLimSorted(1);
            end
            theta = linspace(thetaLim(1),thetaLim(2)).';
            
%             if u(1) >= 0 && v(1) >= 0 
%               % ensure the arc is within the unit disk
%               theta = [linspace(max(thetaLim),pi,50),...
%                        linspace(-pi,min(thetaLim),50)].';
%             else
%               theta = linspace(thetaLim(1),thetaLim(2)).';
%             end

            

            this.Node(row(ii)).Connection(end+1) = line(...
              r*cos(theta)+x0,...
              r*sin(theta)+y0,...
              'LineWidth', lineWidth(ii),...
              'Color', edgeColor,...
              'PickableParts','none');
          end
        end
      end
      
      axis image;
      ax = gca;
      for ii = 1:length(adjacencyMatrix)
        extent(ii) = this.Node(ii).Extent;
      end
      extent = max(extent(:));
      ax.XLim = ax.XLim + extent*[-1 1];
      fudgeFactor = 1.75; % Not sure why this is necessary. Eyeballed it.
      ax.YLim = ax.YLim + fudgeFactor*extent*[-1 1];
      ax.Visible = 'off';
      ax.SortMethod = 'depth';
      
      fig = gcf;
      fig.Color = [1 1 1];
    end
    
  end
  
  methods (Static = true)
%     function showNodes(this,~)
%       % Callback for 'Show All' button
%       n = this.UserData.Node;
%       for i = 1:length(n)
%         n(i).Visible = true;
%       end
%     end
%     
%     function hideNodes(this,~)
%       % Callback for 'Hide All' button
%       n = this.UserData.Node;
%       for i = 1:length(n)
%         n(i).Visible = false;
%       end
%     end
    
    function CloseRequestFcn(this,~)
      % Callback for figure CloseRequestFcn
      c = this.UserData;
      for i = 1:length(c.Node)
        delete(c.Node(i));
      end
      delete(gcf);
    end
    
  end
  
end