function [sbc, A] = calculateSeedBasedConnectivity(data, atlas, roiList, externalSeed)

% <data> is the timeseries data where we will calculate the voxel-to-voxel
%   or ROI-to-voxel, or ROI-ROI correlation. It can be 2D, 3D, or 4D, with
%   the last dimension the time. 
% <atlas> is the atlas annotation image with an ID for each brain region.
%   It should have been coregisterred and have the same dimension to the
%   data. [] means only voxel-to-voxel correlations will be calculated. 
% <roiList> (optional) is a column of the roi numbers in the atlas that we are
%   interested or a table containing the roi information, such as name,
%   acronym, voxCounts

if ~exist('atlas','var') || isempty(atlas)
    atlas = ones(sizefull(data,ndims(data)-1));
end
if ~exist('roiList','var') || isempty(roiList)
    roiList = round(unique(atlas(:))); roiList(roiList==0) = [];
end
if ~exist('externalSeed','var') || isempty(externalSeed)
    externalSeed = [];
end
nroi = size(roiList,1);

wantExternalSeed = ~isempty(externalSeed);

% Make a table if roiList is not a table
if ~istable(roiList)
    id = roiList;
    name = string(1:nroi)';
    acronym = string(1:nroi)';
    voxCounts = nan(nroi,1);
    roiList = table(id,name,acronym,voxCounts);
end

% Remove nan voxels
data = nanreplace(data);

% Data mask based on both the data and the atlas
datamask = logical((atlas~=0).*(mean(data,ndims(data))~=0));

% Reshape the data to a 2D matrix, time x voxels
data2D = reshape2D(data,ndims(data)); data2D = nanreplace(data2D(:,datamask));
atlas2D = atlas(datamask); % Rearrange the atlas in the same way

if ~wantExternalSeed
% Get roi signals, will eroding roi help? Note that for some rois, there
% are no voxels and the mean of an empty matrix will be nan.
roiSignal = cellfun(@(x) mean(data2D(:,atlas2D==x),2,'omitnan'), num2cell(roiList.id),'UniformOutput',0);

% Calculate seed maps
sbc(1:nroi)=struct('roiID',[],'name','','acronym','','voxCounts',[],'timecourse',[],'seedmap',zeros(sizefull(data,3)));
for iroi=1:nroi
    % Save roi info
    sbc(iroi).roiID = roiList.id(iroi);
    sbc(iroi).name = roiList.name(iroi);
    sbc(iroi).acronym = roiList.acronym(iroi);
    sbc(iroi).voxCounts = roiList.voxCounts(iroi);

    % Save averaged timecourse in percentage 
    sbc(iroi).timecourse = roiSignal{iroi}/mean(roiSignal{iroi})-1; % Percent change

    % Caclulate the Pearson's correlation between the averaged roi signal
    % and each voxel signal
    tmp = corr(roiSignal{iroi},data2D);
    
    % Fisher-transformed correlation coefficient. Now the correlation
    % coefficient follows the normal distribution
    tmp = 0.5*log((1+tmp)./max(eps,(1-tmp))); %* standard error = 1/sqrt(length(roiSignal(:,iroi))-3);

    % Remove the nan voxels
    tmp(isnan(tmp)) = 0;
    
    sbc(iroi).seedmap(datamask) = tmp;


end

% Remove the rows whose timecourse are nan. Note this could lead to
% different number of rows among runs
% sbc(any(isnan([sbc.Timecourse]))) = [];

% Calculate correlation coefficient between roiSignals
A = getAdjacencyMatrix(catcell(2,roiSignal), 'Pearson', 'none', 1, []);

% Convert the matrix to a table
A = array2table(A, 'VariableNames',roiList.acronym,'RowNames',roiList.acronym);

else

    roiSignal = externalSeed;
    nroi = length(roiSignal);

    % Calculate seed maps
    sbc(1:nroi)=struct('roiID',[],'name','','acronym','','voxCounts',[],'timecourse',[],'seedmap',zeros(sizefull(data,3)));

    for iroi=1:nroi
    % Save roi info
    sbc(iroi).roiID = iroi;
    sbc(iroi).name = ['external',num2str(iroi)];
    sbc(iroi).acronym = ['ex',num2str(iroi)];
    sbc(iroi).voxCounts = '';

    % Save averaged timecourse in percentage 
    sbc(iroi).timecourse = roiSignal{iroi}/mean(roiSignal{iroi})-1; % Percent change

    % Caclulate the Pearson's correlation between the averaged roi signal
    % and each voxel signal
    tmp = corr(roiSignal{iroi},data2D);
    
    % Fisher-transformed correlation coefficient. Now the correlation
    % coefficient follows the normal distribution
    tmp = 0.5*log((1+tmp)./max(eps,(1-tmp))); %* standard error = 1/sqrt(length(roiSignal(:,iroi))-3);

    % Remove the nan voxels
    tmp(isnan(tmp)) = 0;
    
    sbc(iroi).seedmap(datamask) = tmp;

    % Calculate correlation coefficient between roiSignals
    A = getAdjacencyMatrix(catcell(2,roiSignal), 'Pearson', 'none', 1, []);

    % Convert the matrix to a table
    %A = array2table(A, 'VariableNames',sbc.acronym,'RowNames',sbc.acronym);


    end
end

