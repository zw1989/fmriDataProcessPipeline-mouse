

function h = fVoxel_Map(Anatomy, CC_map, CC_Settings,rotation,matrix,orientation,varargin)
% h = fVoxel_Map(Anatomy, CC_map, CC_Settings)
% CC_Settings contains [min_CC, Threshold, max_CC, cluster_size]
% h = fVoxel_Map(Anatomy, CC_map, CC_Settings,'Atlas',Atlas,ROI)

% Check the resolution of Anatomy and CC_map
if ~isequal(size(Anatomy),size(CC_map))
    fprintf('Error in fVoxel_Map: Anatomy and CC_map should have the same size\n');
    return;
end


% Check the settings for the display range of CC_map
min_CC=CC_Settings(1);
Threshold=CC_Settings(2);
max_CC=CC_Settings(3);
cluster=CC_Settings(4);
if min_CC>Threshold || max_CC<Threshold
    fprintf(['Error in map_show_zoom: inappropriate settings for the CC_Settings\n', ...
        'CC_Settings contains [min_CC, Threshold, max_CC, cluster_size]\n']);
    return;
end

% Check the optional input
if length(varargin)==2 || length(varargin)==3
    if ischar(varargin{1}) && strcmpi(varargin{1},'Atlas') && ~isequal(Anatomy,varargin{2})
        Atlas=varargin{2};
        if length(varargin)==3
            ROI=varargin{3};
        else
            ROI=unique(Atlas);
            ROI(ROI==0)=[];
        end
    else
        fprintf('Error in map_show_zoom: inappropriate settings for Atlas\n');
        return;
    end
else
    Atlas=[];
end

% binary the image
[~ , ~, ImgZ] = size(CC_map);
CC_map_threshold = double(abs(CC_map)>=abs(Threshold));

% apply the cluster size
for z = 1:ImgZ
    mask = CC_map_threshold(:,:,z);
    mask_map = bwlabel(mask, 8);
    for i = 1:max(mask_map(:))
        if sum(mask_map(:)==i)<cluster
            mask_map(mask_map==i)=0;
        end
    end
    mask_map(mask_map > 0) = 1;
    CC_map_threshold(:,:,z) = mask_map.*CC_map(:,:,z);
end


% Cropping
Ana_2D=fSlice_Display_3D_Matrix(Anatomy,rotation,matrix,orientation);
CC_map_threshold_2D=fSlice_Display_3D_Matrix(CC_map_threshold,rotation,matrix,orientation);
CC_map_threshold_2D_Positive=fSlice_Display_3D_Matrix(CC_map_threshold>0,rotation,matrix,orientation);
CC_map_2D_postive=fSlice_Display_3D_Matrix(CC_map.*(CC_map>0),rotation,matrix,orientation);
CC_map_threshold_2D_Negative=fSlice_Display_3D_Matrix(CC_map_threshold<0,rotation,matrix,orientation);
CC_map_2D_negative=fSlice_Display_3D_Matrix(CC_map.*(CC_map<0),rotation,matrix,orientation);



% colorize the background
Background=Ana_2D.*(CC_map_threshold_2D==0);% crop
% color range
Max=prctile(Background(Background>0),99);
Min=prctile(Background(Background>0),1);
Background=(Background-Min)/(Max-Min);% normalize
% truncate
Background(Background>1)=1;
Background(Background<0)=0;
Background=repmat(Background.*0.8,[1 1 3]);% to RGB and adjust the brightness


% colorize postive seed map

Seed_Map_Positive=repmat(CC_map_2D_postive,[1 1 3]);
% color range
Seed_Map_Positive=(Seed_Map_Positive-min_CC)/(max_CC-min_CC);% normalize
Seed_Map_Positive(:,:,1)=1;
Seed_Map_Positive(:,:,2)=Seed_Map_Positive(:,:,2);
Seed_Map_Positive(:,:,3)=0;
% truncate
Seed_Map_Positive(Seed_Map_Positive>1)=1;
Seed_Map_Positive(Seed_Map_Positive<0)=0;
Seed_Map_Positive=Seed_Map_Positive.*repmat(CC_map_threshold_2D_Positive,[1 1 3]);

% colorize negative seed map

Seed_Map_Negative=repmat(CC_map_2D_negative,[1 1 3]);
% color range
Seed_Map_Negative=(abs(Seed_Map_Negative)-min_CC)/(max_CC-min_CC);% normalize
Seed_Map_Negative(:,:,1)=0;
Seed_Map_Negative(:,:,2)=Seed_Map_Negative(:,:,2);
Seed_Map_Negative(:,:,3)=1;
% truncate
Seed_Map_Negative(Seed_Map_Negative>1)=1;
Seed_Map_Negative(Seed_Map_Negative<0)=0;
Seed_Map_Negative=Seed_Map_Negative.*repmat(CC_map_threshold_2D_Negative,[1 1 3]);


% Atlas
if ~isempty(Atlas)
    if isempty(ROI)
        ROI=unique(Atlas);
        ROI(ROI==0)=[];
    end
    Atlas_New=Atlas*0;
    for i=1:length(ROI)
        Atlas_New=Atlas_New+ROI(i)*(Atlas==ROI(i));
    end
    Atlas_2D = fSlice_Display_3D_Matrix(Atlas_New,rotation,matrix,orientation);
    Atlas_2D = edge(Atlas_2D,'Sobel',0.2);
    %Atlas_2D = detectedges(Atlas_2D,0.2);
    %Atlas_2D = imdilate(Atlas_2D,strel('disk',1));
end


% combine image
h=Background+Seed_Map_Positive+Seed_Map_Negative;

% Apply atlas
if ~isempty(Atlas)
    for x=1:1:size(Atlas_2D,1)
        for y=1:1:size(Atlas_2D,2)
            if Atlas_2D(x,y)==1
                if sum(h(x,y,:))>3
                    h(x,y,:)=[0 0 0];
                else
                    h(x,y,:)=[1 1 1];
                end
            end
        end
    end
end

% Make it higher inplane resolution


end