function [A, P] = getAdjacencyMatrix(data, corrType, negativeCorrRule, fisherZ, covariates)
%
% <data> is a n x p 2D matrix with rows representing the observations and columns
%   representing the variables.
% <corrType> is a string indicating the type of the correlation. Can be
%   'Pearson' (default), 'Spearman', or 'Kendall'.
% <negativeCorrRule> is a string indicating how to treat negative
%   correlation coefficients. Can be 'none' (default) or 'abs', 'zero'. 
% <fisherZ> is either 0 or 1 (default), indicating whether to transform the cc values
%   to Fisher's Z value, which follows the Gaussian distribution. 
% <covariates> is a nxp0 matrix with rows representing the observations and
%   columns representing the variables, such as age, sex, which covariates
%   with the data variables. Defaults is []; otherwise, paprtial
%   correlation will be used.


if ~exist('corrType','var') || isempty(corrType)
    corrType = 'Pearson';
end
if ~exist('negativeCorrRule','var') || isempty(negativeCorrRule)
    negativeCorrRule = 'none';
end
if ~exist('fisherZ','var') || isempty(fisherZ)
    fisherZ = 1;
end
if ~exist('covariates','var') || isempty(covariates)
    covariates = [];
end

wantPartialCorr = ~isempty(covariates);

% Calculate the autocorrelation of the matrix (adjacency matrix)
if ~wantPartialCorr
    [A, P] = corr(data, 'Type', corrType);
else
    [A, P] = partialcorr(data, covariates, 'Type', corrType);
end

% Deal with negative correlations
switch negativeCorrRule
    case 'none'

    case 'abs'
        A = abs(A);
    case 'zero'  % Correlation.ZERO default
        A(A < 0) = 0;
    otherwise

end

% Change diagonals to zeros
A = A - diag(diag(A));

% Fisher's Z transformation
if fisherZ
    A = 0.5*log((1+A)./max(eps,(1-A)));
end





