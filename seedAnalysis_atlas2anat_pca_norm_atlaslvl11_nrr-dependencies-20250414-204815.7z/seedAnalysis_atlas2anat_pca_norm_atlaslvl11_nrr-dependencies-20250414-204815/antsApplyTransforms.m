function antsApplyTransforms(transformChain, inputImgPath, refImgPath, outputPath,interpMethod,resamplingSpacing,dimensionality,outputPrefix)

% Get the file name and file location
[fpath,file,ext] = fileparts(inputImgPath);

% inputs
if ~exist('refImgPath','var') || isempty(refImgPath)
  refImgPath = inputImgPath;
end
if ~exist('outputPath','var') || isempty(outputPath)
  outputPath = fpath;
end
if ~exist('interpMethod','var') || isempty(interpMethod)
  interpMethod = 'BSpline[5]';
end
if ~exist('resamplingSpacing','var') || isempty(resamplingSpacing)
  resamplingSpacing = [];
end
if ~exist('dimensionality','var') || isempty(dimensionality)
  dimensionality = 3;
end

if length(resamplingSpacing)==1
    resamplingSpacing = repmat(resamplingSpacing,1,3);
end

if contains(ext,'tif')
    datatype = ' --float ';
else
    datatype = '';
end
if ~exist('outputPrefix','var') || isempty(outputPrefix)
  outputPrefix = '';
end

% What is the output file absolute path?
outputPrefix = [fullfile(outputPath,'coreg_'),file,outputPrefix];

% Resampling flag
wantResampling = ~isempty(resamplingSpacing);

% Here the resampling is done on reference image, which defined the origin,
% spacing, and matrix size of the final image.
if wantResampling
    unix_wrapper(sprintf(['ResampleImageBySpacing 3 ', ... % 3D image
             ' %s ', ... % Inoput image fullpath
             ' %s ',... % output image fullpath
             ' %f %f %f 0 '], ... % New spacings
             refImgPath, strrep(refImgPath,'.nii','_resampled.nii'), resamplingSpacing(1),resamplingSpacing(2),resamplingSpacing(3)),0);


      refImgPath = strrep(refImgPath,'.nii','_resampled.nii');

end

% Do it

unix_wrapper(sprintf(['antsApplyTransforms -d %d -e 3 ', ... % 3D image, time series
             ' %s ', ...
             ' -i %s -r %s -o %s%s ',...
             ' --interpolation %s ',...
             ' %s '], ...
             dimensionality,transformChain, inputImgPath, refImgPath, outputPrefix,ext, ...
             interpMethod, datatype),0);





