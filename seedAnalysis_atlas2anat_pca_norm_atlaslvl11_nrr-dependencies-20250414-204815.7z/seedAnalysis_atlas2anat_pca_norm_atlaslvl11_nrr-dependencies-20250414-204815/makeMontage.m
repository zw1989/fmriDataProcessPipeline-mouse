function [img2D,dim] = makeMontage(img,rotation,matrixSize,view)
% matrixSize=0 do automatic organization
% matrixSize=5 means 5 rows
% matrixSize=[0 5] means 5 columns
% matrixSize=[5 5] means 5 by 5 organization
% view is 'xy' 'yz' 'xz', 
% img is [x,y,z]

if strcmp(view,'xy')
elseif strcmp(view,'yz')
    img=permute(img,[2 3 1]);
elseif strcmp(view,'xz')
    img=permute(img,[1 3 2]);
else
    fprintf('makeMontage: Wrong setups in view: %s\n',view);
    return;
end


nz=size(img,3);

if length(matrixSize)==1 && matrixSize==0
    nRow=floor(sqrt(nz));
    nColumn=ceil(nz/nRow);
elseif length(matrixSize)==1 && matrixSize>0
    nRow=round(matrixSize);
    nColumn=ceil(nz/nRow);
elseif length(matrixSize)==2 && matrixSize(1)==0
    nColumn=round(matrixSize(2));
    nRow=ceil(nz/nColumn);
elseif length(matrixSize)==2 && matrixSize(1)>0 && matrixSize(2)>0
    nRow=round(matrixSize(1));
    nColumn=round(matrixSize(2));
else
    fprintf('fDisplay_EPI: Wrong Setups in Matrix_Size: %f\n',matrixSize);
    return;
end
if nRow<=0||nColumn<=0
    fprintf('fDisplay_EPI: Wrong Setups in Matrix_Size: %f\n',matrixSize);
    return;
end


imgOrientation=rot90(img,rotation);
dim=size(imgOrientation);

if length(dim) == 2
    dim(3) = 1;
end

img2D=zeros(nRow*dim(1),nColumn*dim(2));

count=1;
for x=1:nRow
    for y=1:nColumn
        if count>dim(3)
            break;
        end
        img2D(dim(1)*(x-1)+1:dim(1)*x,dim(2)*(y-1)+1:dim(2)*y) = imgOrientation(:,:,count);
        count=count+1;
    end
end
% imshow(Image,[]);


end