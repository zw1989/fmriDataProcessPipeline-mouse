clear; close all; clc


%% Load preprocessed fmri Data which are copied from male and female seedAnalysis folder
% Essential data paths
preprocessedPath = '/home/ibrain-raid2/weizhu-data/data/9-laminarFmriPipeline-mouse-9T/derivatives-nrr/preprocessed-data';
preprocessedPCApath = fullfile(preprocessedPath,'pca');
atlasPath = fullfile(preprocessedPath,'atlas');
seedAnalysisPath = strrep(preprocessedPCApath, 'preprocessed-data/pca', 'seedAnalysis/pca-norm-atlaslvl11'); % target path
mkdirquiet(seedAnalysisPath)
figuredir = fullfile(seedAnalysisPath,'figures');
mkdirquiet(figuredir)

% func data list
funcList = searchAndSortFiles(preprocessedPCApath, ...             % File path
                                 '.+.nii', ...              % File name pattern, regular expression
                                 {{'type', {{'control',1}, {'mutant',1},{'treated',1}}}, {'sex', {{'M',1}, {'F',1}}},...
                                 {'month', 4}, {'mouse',5},{'run',8}}, ... % Data structure information
                                 1);                         % Functional data indicator

% Subject func number
subLabelFunc = cellfun(@(x,y,z,k) [x,y,num2str(z),'-m',num2str(k)], {funcList.type}, {funcList.sex}, {funcList.month},{funcList.mouse} ,'UniformOutput',0);
subIDfunc = unique(subLabelFunc,'stable')';
nSub = length(subIDfunc);

%% Register func to atlas space
if ~exist(fullfile(strrep(funcList(1).dir,'pca','pca-norm'),['coreg_',stripfile(funcList(1).fullPath,1)]),"file")

% atlas2func transformation file list
tList = searchAndSortFiles(preprocessedPCApath, ...             % File path
                                 'atlas2func.mat', ...              % File name pattern, regular expression
                                 {{'type', {{'control',1}, {'mutant',1},{'treated',1}}}, {'sex', {{'M',1}, {'F',1}}},...
                                 {'month', 4}, {'mouse',5}}, ... % Data structure information
                                 0);  

% Get subject label
subLabel = cellfun(@(x,y,z,k) [x,y,num2str(z),'-m',num2str(k)], {tList.type}, {tList.sex}, {tList.month},{tList.mouse} ,'UniformOutput',0).';

% Get mat file object
atlas2funcFile = cellfun(@(x) matfile(x), {tList.fullPath}.','UniformOutput',0);

% Get inverseTransformChain (func2atlas)
Tfunc2atlas = cellfun(@(x) x.inverseTransformChain, atlas2funcFile,'UniformOutput',0);

% Get resampled atlas template path. Here it will be used as a reference
atlasTemplateResampledPath = atlas2funcFile{1}.atlasResampledPath;

% Transform the func to the original atlas space but keep the func
% resolution. Pay attention to the order of the subIDfunc and tList subject
% order
for isub = 1:nSub 
    fprintf(sprintf('Func2atlas of the %dth subject ... ',isub))
    % Get runs of this subject
    tmpList = funcList(ismember(subLabelFunc,subIDfunc(isub)));

    % Path to save the registered func data
    preprocessedNormPath = strrep(tmpList(1).dir,'pca','pca-norm'); mkdirquiet(preprocessedNormPath);
    
    % Get index of the transform list
    idxtmp = find(ismember(subLabel,subIDfunc(isub)));

    % Apply all the transforms to the func data. 
    cellfun(@(x) antsApplyTransforms(Tfunc2atlas{idxtmp}, x, atlasTemplateResampledPath, preprocessedNormPath,'BSpline[5]'), {tmpList.fullPath}, 'UniformOutput',0);

    fprintf('done! \n');
end

% Resample the atlas annotation file. Note that here we did an identity
% transform but with a resampled reference image.
if ~exist(fullfile(atlasPath,'coreg_atlasAnnotationRightLeft.nii'),"file")
atlasAnnotationPath = fullfile(atlasPath,'atlasAnnotationRightLeft.nii');
antsApplyTransforms('', atlasAnnotationPath, atlasTemplateResampledPath, atlasPath,'GenericLabel');
end

end

%% Quality check   

% Get registered func data list
funcNormList = searchAndSortFiles(strrep(preprocessedPCApath, 'pca','pca-norm'), ...             % File path
                                 '.+.nii', ...              % File name pattern, regular expression
                                 {{'type', {{'control',1}, {'mutant',1},{'treated',1}}}, {'sex', {{'M',1}, {'F',1}}},...
                                 {'month', 4}, {'mouse',5},{'run',8}}, ... % Data structure information
                                 1);  
subLabelFunc = cellfun(@(x,y,z,k) [x,y,num2str(z),'-m',num2str(k)], {funcNormList.type}, {funcNormList.sex}, {funcNormList.month},{funcNormList.mouse} ,'UniformOutput',0)';
[subIDfunc,ia,ic] = unique(subLabelFunc,'stable');
nSub = length(subIDfunc);

% Randomly select 6 subject data
%subidx = randi(length(subIDfunc),10,1);
%subidx = contains(subIDfunc,{'controlF8','mutantF8','controlM8','mutantM8'});
%subidx = contains(subIDfunc,{'M5','F5'});

% Get registered anat images
sliceSelect = 9;
funcSelected = cell(nSub,1);
for isub = 1:nSub
    nii = load_nii(funcNormList(ia(isub)).fullPath);
    funcSelected{isub} = nii.img(:,:,sliceSelect,1); % Only take the image at the first time point
end

% Get resampled atlas template images
nii = load_nii(fullfile(atlasPath,'atlasTemplate_enhanced_resampled.nii'));
atlastemplateResampled = nii.img;

% Get resampled atlas annotation images
nii = load_nii(fullfile(atlasPath,'coreg_atlasAnnotationRightLeft.nii'));
atlasAnnotationResampled = nii.img;                      

% Put all the image together
imgSet = [{atlastemplateResampled(:,:,sliceSelect)};{atlasAnnotationResampled(:,:,sliceSelect)};funcSelected];
imgSet = catcell(3,cellfun(@(x) normalizerange(x,0,1), imgSet, 'UniformOutput',0));

% Draw them together
figure;imshow(makeMontage(imgSet,1,0,'xy'),[]);

% Should we also draw the func quality maps???

%% Seed analysis--level 11, layer level (smallest region level)
% Read stucture info
roiList = readtable(fullfile(atlasPath,"structures_modifiedRightLeft.csv"));

% Scub the atlas (combine some level of structures)
st_levelCut = 11;
voxCountCut = 7; % Original voxel size 0.25x0.25, after interpolation, 0.1x0.1. Ratio=6.25
layerFlag = 1; % Has no effect if level cut is set to 11.
[atlasScrubbed, roiCombinedList] = scrubAtlas(atlasAnnotationResampled, roiList, st_levelCut, voxCountCut,layerFlag);
 
% First-level analysis
seedmapavg = cell(nSub,1);
Aavg = seedmapavg;
for isub = 1:nSub 
  fprintf(sprintf('Calculating seedmaps of the %dth subject ... ',isub))

    tmpList = funcNormList(ismember(subLabelFunc,subIDfunc(isub)));

    % Get func data for this subject
    temp = cellfun(@(x) load_nii(x), {tmpList.fullPath}, 'UniformOutput',0);
    subfunc = cellfun(@(x) x.img, temp, 'UniformOutput',0); 
    nrun = length(subfunc);

    % Calculate seed maps. Note some maps may be zeros and the timecourse
    % is nan
    [sbc,A] = cellfun(@(x) calculateSeedBasedConnectivity(x,atlasScrubbed,roiCombinedList),subfunc,'UniformOutput',0);
    %load(fullfile(seedAnalysisPath, [stripfile(stripfile(tmpList(1).dir),1),'.mat']));
    
    % Calculate mean seed map for each subject and each roi
    seedmapavg{isub} = rmfield(sbc{1},{'timecourse','seedmap'}); % Initialization
    for iroi = 1:length(sbc{1})
        % Get seed maps for seed iroi
        tmp = catcell(4,cellfun(@(x) x(iroi).seedmap, sbc, 'UniformOutput',0));

        % Get the mean and std seed maps
        seedmapavg{isub}(iroi).seedmapAvg = mean(tmp,4); 
        seedmapavg{isub}(iroi).seedmapStd = std(tmp,0,4); 

        % One-sample t-test
        tmap = (seedmapavg{isub}(iroi).seedmapAvg-0)./(seedmapavg{isub}(iroi).seedmapStd/sqrt(nrun)); 
        seedmapavg{isub}(iroi).pmap = 1-tcdf(tmap,nrun-1);
    end

    % Calculate the mean ajacency matrix
    vname = A{1}.Properties.VariableNames;  
    tmp = catcell(3,cellfun(@(x) table2array(x),A,'uniformoutput',0));
    Aavg{isub}.Aavg = mean(tmp,3);
    Aavg{isub}.Astd = std(tmp,0,3);
    tmap = (Aavg{isub}.Aavg-0)./(Aavg{isub}.Astd/sqrt(nrun)); 
    Aavg{isub}.Apmap = 1-tcdf(tmap,nrun-1);
    Aavg{isub}.vname = vname; %array2table(mean(tmp,0,3),'VariableNames',vname,'RowNames',vname);
    
    % Save seedMap
    %save(fullfile(seedAnalysisPath, [stripfile(stripfile(tmpList(1).dir),1),'.mat']), 'sbc','A','-v7.3')

    fprintf('done! \n');
end

% Save averaged seedMap. It has the roi information
save(fullfile(seedAnalysisPath, 'seedMapAvg.mat'), 'subIDfunc','subLabelFunc','seedmapavg','Aavg','atlasScrubbed','roiCombinedList','atlastemplateResampled','-v7.3');

% Plot timecourse and power spectrum density
% figure; plot(1:286,[sbc{1}.Timecourse])
% figure;
% pxx = pwelch([sbc{1}.Timecourse],[],[],[],1);   % calc PSD with Welch's method
% omega = linspace(0,0.5,size(pxx,1));
% semilogy(omega,pxx)
% ylabel('log PSD')
% xlabel('f (Hz)')


% temp = cellfun(@(x) load_nii(fullfile(strrep(x,'func','anat'),'coreg_atlasTissueMasks.nii')), {tmpList.dir}, 'UniformOutput',0);
% tissueMasks = cellfun(@(x) x.img, temp, 'UniformOutput',0);
% preprocess_funcQC([], subfunc, tissueMasks, [], 'mouse', 1, 1);

%% Check seedmaps of each run for each subject
% Select a subject
isub = 7;
% Load mat file for each subject
load(fullfile(seedAnalysisPath,[subIDfunc{isub},'.mat']));

roiSelection = {'SS','ACA','RSP','CA','DG','ENT','CP','LS'};
roiSelection = {'SSp-bfd'};
acronymList = [sbc{1}(contains([sbc{1}.acronym],roiSelection)).acronym];

sliceSelect = 5:14;
for ir = 1:length(sbc)
  close all
  sbcTmp = sbc{ir};
  fprintf('Displaying seedmaps for run %d \n',ir);
  for ii = 1:size(sbcTmp,2)
  
      if ismember(sbcTmp(ii).acronym,acronymList)
              
          figure; subplot('Position',[0 0 1 1]); 
          imshow(fVoxel_Map(atlastemplateResampled(:,:,sliceSelect),...
                            sbcTmp(ii).seedmap(:,:,sliceSelect),...
                            [0, 0.2, 0.6, 4], ... %cc setting
                            1,1,'xy',... % Rotation, matrix, orientation
                            'Atlas',atlasScrubbed(:,:,sliceSelect), ...
                            sbcTmp(ii).roiID));
          
          
          title([%'Label:',num2str(seedLabel.label(iSeed)), ...
                 'Acronym: ',sbcTmp(ii).acronym, ...
                 ' | Name: ', sbcTmp(ii).name]);
          truesize([100 1400]);
          %truesize([500 1000]);
      end
  end
  
  pause;
end

fprintf('Done. \n')

%% Check individual seedmaps
isub = 5; close all;

roiSelection = {'SS','ACA','RSP','CA','DG','ENT','CP','LS'};
roiSelection = {'SSp-bfd'};
acronymList = [seedmapavg{isub}(contains([seedmapavg{isub}.acronym],roiSelection)).acronym];

sliceSelect = 5:14;
for ii = 1:size(seedmapavg{isub},2)

    if ismember(seedmapavg{isub}(ii).acronym,acronymList)
            

        figure('Name',seedmapavg{isub}(ii).acronym{1}); 
        subplot('Position',[0 0 1 1]); 
        imshow(fVoxel_Map(atlastemplateResampled(:,:,sliceSelect),...
                          seedmapavg{isub}(ii).seedmapAvg(:,:,sliceSelect),...
                          [0, 0.2, 0.6, 4], ... %cc setting
                          1,1,'xy',... % Rotation, matrix, orientation
                          'Atlas',atlasScrubbed(:,:,sliceSelect), ...
                          seedmapavg{isub}(ii).roiID));
        
        
        title([%'Label:',num2str(seedLabel.label(iSeed)), ...
               'Acronym: ',seedmapavg{isub}(ii).acronym, ...
               ' | Name: ', seedmapavg{isub}(ii).name]);
        truesize([100 1400]);
        %truesize([500 1000]);
    end
end

%% Plot averaged map
close all
% Set label
setlabel = {'controlM8','controlF8'}; 
setlabel = {'controlM5','controlF5'}; 
%setlabel = {'controlF5'};
setlabel = {'controlM8','controlF8','controlM5','controlF5'}; 
seedmapAvg = seedMapAverage2(seedmapavg(contains(subIDfunc,setlabel)));

% Select rois
roiSelection = {'SS','ACA','RSP','CA','DG','ENT','CP','LS'};
roiSelection = {'SSp-bfd'};
roiSelection = {'SSp-ll'};
%roiSelection = {'CA'};
%roiSelection = {'ENTl'};
roiSelection = {'cc'};
acronymList = [seedmapAvg(contains([seedmapAvg.acronym],roiSelection)).acronym];
%acronymList = [seedmapAvg(742:end).acronym];

sliceSelect = 5:14;
close all;
for ii = 1:size(seedmapAvg,2)
    if ismember(seedmapAvg(ii).acronym,acronymList)
            
        figure('Name',seedmapAvg(ii).acronym{1}); 
        subplot('Position',[0 0 1 1]); 
        imshow(fVoxel_Map(atlastemplateResampled(:,:,sliceSelect),...
                          seedmapAvg(ii).seedmapAvg(:,:,sliceSelect).*(seedmapAvg(ii).pmap(:,:,sliceSelect)<0.01),...
                          [0, 0.22, 0.6, 4], ... %cc setting
                          1,1,'xy',... % Rotation, matrix, orientation
                          'Atlas',atlasScrubbed(:,:,sliceSelect), ...
                          seedmapAvg(ii).roiID));

        title(['Acronym: ',seedmapAvg(ii).acronym{1},' | Name: ', seedmapAvg(ii).name{1}]);
        truesize([100 1400]);
        %truesize([500 1000]);
    end
end


%% Plot Averaged CC maps
close all
% Set label
% setlabel = {'controlM8','controlF8'}; 
% setlabel = {'mutantM8','mutantF8'}; 
% setlabel = {'treatedM8','treatedF8'}; 
setlabel = {'controlM8','controlF8','controlM5','controlF5'}; 
AavgSub = mean(catcell(3,cellfun(@(x) x.Aavg,Aavg(contains(subIDfunc,setlabel)),'UniformOutput',0)),3,'omitnan');

% Get missing idx
missingIdx = ismissing(AavgSub(:,1));

% Remove nan or missing data
AavgSub(missingIdx,:) = [];
AavgSub(:,missingIdx) = [];

% Get rois
% rois = Aavg{1}.Properties.VariableNames(~missingIdx);
rois = Aavg{1}.vname(~missingIdx);

% Plot, note we display the adjacency matrix in the same range [0,1] for
% comparison
afigure( aconfig('Width',800,'Height',800,'Grid',0,'Colormap',brewermap(length(AavgSub),"-Spectral")) );
imagesc(AavgSub,[0,1]); axis equal; colorbar;
h = findobj(gcf); % Get the handles associated with the current figure
%allLines = findall(h, 'Type', 'line'); set(allLines, 'Linewidth',2.5)
allAxes = findall(h, 'Type', 'axes'); 
set(allAxes, 'Linewidth',1, 'FontWeight','normal', 'FontSize',10, 'Box', 'off',...
             'xlim',[1,size(AavgSub,1)],'xtick',1:2:size(AavgSub,1),'xticklabel',rois(1:2:size(AavgSub,1)),...
             'ylim',[1,size(AavgSub,1)],'ytick',1:2:size(AavgSub,1),'yticklabel',rois(1:2:size(AavgSub,1)),...
             'ticklength',[0,0])
%allText = findall(h, 'Type', 'text'); set(allText, 'FontWeight','normal', 'FontSize',24)
figurewrite('%d-ccMatrixControl',1,{0 [1 300]},figuredir);


%% Plot circular graph
myColorMap = brewermap(length(AavgSub),"-Spectral");
myColorMap = [1 0.5 0.1]; % Orange
afigure( aconfig('Width',800,'Height',800,'Grid',0) );
circularGraph(AavgSub.*double(AavgSub>0.2),'Colormap',myColorMap,'Label',rois,'NormValue',1);
figurewrite('%d-ccCircleControl',2,{0 [1 300]},figuredir);


%% Plot circular graph on selected rois
% Select rois
roiSelection = {'SS','ACA','RSP','CA','DG','ENT','CP','LS'};
roiSelection = {'SS'};
idx = contains(rois,roiSelection);

% Select rows of adjacency matrix
AavgSubSelected = AavgSub;
AavgSubSelected(~idx,:) = 0;
AavgSubSelected = AavgSubSelected.*double(AavgSubSelected>0.3);

% column idx if the columns are all 0
idx2 = all(AavgSubSelected==0,1);

AavgSubSelected(idx2,:) = [];
AavgSubSelected(:,idx2) = [];

myColorMap = [1 0.5 0.1]; % Orange
afigure( aconfig('Width',800,'Height',800,'Grid',0) );
circularGraph(AavgSubSelected,'Colormap',myColorMap,'Label',rois(~idx2),'NormValue',1);
% figurewrite('%d-ccCircleControl-SS',3,{0 [1 300]},figuredir);
