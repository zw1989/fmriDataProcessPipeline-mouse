function Image=fSlice_Display_3D_Matrix(Matrix_3D,Rotation,Matrix_Size,View)
% Matrix_Size=0 do automatic organization
% Matrix_Size=5 means 5 rows
% Matrix_Size=[0 5] means 5 columns
% Matrix_Size=[5 5] means 5 by 5 organization
% View is 'xy' 'yz' 'xz', Matrix_3D is [x,y,z]
if strcmp(View,'xy')
elseif strcmp(View,'yz')
    Matrix_3D=permute(Matrix_3D,[2 3 1]);
elseif strcmp(View,'xz')
    Matrix_3D=permute(Matrix_3D,[1 3 2]);
else
    fprintf('fDisplay_Matrix_3D: Wrong Setups in View: %s\n',View);
    return;
end



Nz=size(Matrix_3D,3);
N_Row=0;
N_Column=0;
if length(Matrix_Size)==1 && Matrix_Size==0
    N_Row=floor(sqrt(Nz));
    N_Column=ceil(Nz/N_Row);
elseif length(Matrix_Size)==1 && Matrix_Size>0
    N_Row=round(Matrix_Size);
    N_Column=ceil(Nz/N_Row);
elseif length(Matrix_Size)==2 && Matrix_Size(1)==0
    N_Column=round(Matrix_Size(2));
    N_Row=ceil(Nz/N_Column);
elseif length(Matrix_Size)==2 && Matrix_Size(1)>0 && Matrix_Size(2)>0
    N_Row=round(Matrix_Size(1));
    N_Column=round(Matrix_Size(2));
else
    fprintf('fDisplay_Matrix_3D: Wrong Setups in Matrix_Size: %f\n',Matrix_Size);
    return;
end
if N_Row<=0||N_Column<=0
    fprintf('fDisplay_Matrix_3D: Wrong Setups in Matrix_Size: %f\n',Matrix_Size);
    return;
end


Mean_Echo1_Isotropic_90=rot90(Matrix_3D,Rotation);
Dim=size(Mean_Echo1_Isotropic_90);

Image=zeros(N_Row*Dim(1),N_Column*Dim(2));

count=1;
for x=1:N_Row
    for y=1:N_Column
        if count>Dim(3)
            break;
        end
        Image(Dim(1)*(x-1)+1:Dim(1)*x,Dim(2)*(y-1)+1:Dim(2)*y)=...
            Mean_Echo1_Isotropic_90(:,:,count);
        count=count+1;
    end
end
% imshow(Image,[]);


end